"""Prepare unchanged-level listening copies and a silent-start noise control."""
from pathlib import Path
from math import gcd
import ctypes as C
import hashlib
import json
import subprocess
import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

repo=Path('/home/moyamryia/Mozart');root=Path(__file__).resolve().parent
out=root/'fixed-audition';out.mkdir(exist_ok=True)
for name,path in [('01-original.wav',root/'01-original.wav'),('02-before-fix.wav',root/'before-fix/02-preprocessed.wav'),('03-after-fix.wav',root/'after-fix/02-preprocessed.wav')]:
    (out/name).write_bytes(path.read_bytes())
assert hashlib.sha256((out/'01-original.wav').read_bytes()).hexdigest()=='d7dafb12f8d444b2270f2d06158f47c235ca7892aaca1513561dc9971f2a8654'
ptr=C.POINTER(C.c_float)
def suppress(path,x):
    lib=C.CDLL(str(path))
    lib.mozart_ns_new.argtypes=[C.c_void_p];lib.mozart_ns_new.restype=C.c_void_p
    lib.mozart_ns_push.argtypes=[C.c_void_p,ptr,C.c_size_t,ptr,C.c_size_t];lib.mozart_ns_push.restype=C.c_size_t
    lib.mozart_ns_flush.argtypes=[C.c_void_p,ptr,C.c_size_t];lib.mozart_ns_flush.restype=C.c_size_t
    lib.mozart_ns_free.argtypes=[C.c_void_p]
    ns=lib.mozart_ns_new(None)
    if not ns:raise RuntimeError('WOLA initialization failed')
    buf=np.empty(4096,np.float32);chunks=[]
    try:
        for start in range(0,len(x),64):
            part=x[start:start+64]
            n=lib.mozart_ns_push(ns,part.ctypes.data_as(ptr),len(part),buf.ctypes.data_as(ptr),len(buf))
            if n>len(buf):raise RuntimeError('WOLA push failed')
            if n:chunks.append(buf[:n].copy())
        n=lib.mozart_ns_flush(ns,buf.ctypes.data_as(ptr),len(buf))
        if n>len(buf):raise RuntimeError('WOLA flush failed')
        chunks.append(buf[:n].copy())
    finally:lib.mozart_ns_free(ns)
    y=np.concatenate(chunks)[:len(x)]
    if len(y)!=len(x) or not np.isfinite(y).all():raise ValueError('Invalid WOLA output')
    return y
rng=np.random.default_rng(20261026)
noise=(rng.standard_normal(6*48000)*.02).astype(np.float32)
x=np.concatenate([np.zeros(4800,np.float32),noise])
a=suppress(root/'before-fix/libmozart_pre_reference.so',x)
b=suppress(repo/'build/usb-pre/libmozart_pre_reference.so',x)
for name,y in [('21-noise-input.wav',x),('22-noise-before-fix.wav',a),('23-noise-after-fix.wav',b)]:
    sf.write(out/name,y,48000,subtype='FLOAT')
begin=4800+48000
power=lambda y:float(np.mean(y[begin:].astype(np.float64)**2))
report=dict(noise_seed=20261026,noise_seconds=6,zero_prefix_seconds=.1,settle_after_noise_start_seconds=1,
    before_attenuation_db=float(10*np.log10(power(x)/power(a))),
    after_attenuation_db=float(10*np.log10(power(x)/power(b))),
    old_library_sha256=hashlib.sha256((root/'before-fix/libmozart_pre_reference.so').read_bytes()).hexdigest(),
    new_library_sha256=hashlib.sha256((repo/'build/usb-pre/libmozart_pre_reference.so').read_bytes()).hexdigest())
assert abs(report['before_attenuation_db'])<1e-6
assert report['after_attenuation_db']>=12
(out/'noise-check.json').write_text(json.dumps(report,indent=2)+'\n')
def load(path):
    a,s=sf.read(path,dtype='float32',always_2d=True);a=a.mean(axis=1)
    if s!=48000:
        g=gcd(s,48000);a=resample_poly(a,48000//g,s//g)
    if not np.isfinite(a).all() or np.max(np.abs(a))>=1:raise ValueError('Invalid listening samples')
    return a

def combine(name,items):
    chunks=[]
    for index,(label,file) in enumerate(items):
        p=out/f'{name}-label-{index}.wav'
        subprocess.run(['espeak-ng','-v','en-us','-a','20','-s','145','-w',str(p),label],check=True)
        chunks.extend([load(p),np.zeros(48000,np.float32),load(out/file),np.zeros(96000,np.float32)])
    y=np.concatenate(chunks)
    sf.write(out/name,np.repeat(y[:,None],2,axis=1),48000,subtype='PCM_16')
combine('00-comparison.wav',[('Original input.','01-original.wav'),('Before the fix.','02-before-fix.wav'),('After the fix.','03-after-fix.wav')])
combine('20-noise-comparison.wav',[('Test noise with initial silence.','21-noise-input.wav'),('Before the fix.','22-noise-before-fix.wav'),('After the fix.','23-noise-after-fix.wav')])
print(json.dumps(report,indent=2))
