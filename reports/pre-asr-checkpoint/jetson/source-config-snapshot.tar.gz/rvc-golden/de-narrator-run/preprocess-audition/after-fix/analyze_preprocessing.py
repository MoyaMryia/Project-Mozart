"""Compare preprocessing with the same native DSP and WOLA bypass control."""
from pathlib import Path
import ctypes as C
import json
import re
import numpy as np
import soundfile as sf
from scipy import signal

root=Path('/home/moyamryia/Mozart');out=Path(__file__).resolve().parent
lib=C.CDLL(str(root/'build/usb-pre/libmozart_pre_reference.so'))
class Config(C.Structure):
    _fields_=[('denoise',C.c_bool),('gate',C.c_bool),('agc',C.c_bool),('limiter',C.c_bool)]
class Telemetry(C.Structure):
    _fields_=[(n,C.c_int) for n in ['denoise','gate','agc','limiter']]+[(n,C.c_float) for n in ['gate_in_db','gate_out_db']]+[(n,C.c_long) for n in ['gate_open','gate_close']]+[(n,C.c_float) for n in ['agc_gain_db','agc_in_db','agc_out_db','limiter_in_db','limiter_out_db','ns_last_gain']]+[('ns_confidence',C.c_double)]
ptr=C.POINTER(C.c_float)
lib.mozart_dsp_new.argtypes=[C.POINTER(Config)];lib.mozart_dsp_new.restype=C.c_void_p
lib.mozart_dsp_enhance.argtypes=[C.c_void_p,ptr,C.c_size_t,ptr,C.c_size_t];lib.mozart_dsp_enhance.restype=C.c_size_t
lib.mozart_dsp_telemetry.argtypes=[C.c_void_p,C.POINTER(Telemetry)]
lib.mozart_dsp_free.argtypes=[C.c_void_p]
x48,sr=sf.read(out/'native-input-48k-stereo.wav',dtype='float32',always_2d=True);x48=np.ascontiguousarray(x48[:,0]);assert sr==48000

def run(denoise):
    dsp=lib.mozart_dsp_new(C.byref(Config(denoise,False,False,False)))
    if not dsp:raise RuntimeError('Native DSP initialization failed')
    chunks=[];gains=[];buf=np.empty(4096,np.float32)
    try:
        for start in range(0,len(x48),64):
            block=x48[start:start+64]
            count=lib.mozart_dsp_enhance(dsp,block.ctypes.data_as(ptr),len(block),buf.ctypes.data_as(ptr),len(buf))
            if count>len(buf):raise RuntimeError('Native enhance failed')
            if count:
                chunks.append(buf[:count].copy())
                t=Telemetry();lib.mozart_dsp_telemetry(dsp,C.byref(t));gains.append(float(t.ns_last_gain))
    finally:lib.mozart_dsp_free(dsp)
    return np.concatenate(chunks),np.array(gains)
a,g=run(True);b,_=run(False);n=min(len(a),len(b));a=a[:n];b=b[:n]
report={'native_wola_vs_bypass':dict(samples=n,relative_rmse=float(np.linalg.norm(a-b)/np.linalg.norm(b)),max_abs=float(np.max(np.abs(a-b))),correlation=float(np.corrcoef(a,b)[0,1]),rms_ratio_db=float(20*np.log10(np.linalg.norm(a)/np.linalg.norm(b))))}
report['wola_gain_trace']=dict(count=len(g),min=float(g.min()),median=float(np.median(g)),p99=float(np.percentile(g,99)),last=float(g[-1]),fraction_at_least_0_999=float(np.mean(g>=.999)))
nonzero=np.flatnonzero(x48);report['input_start']=dict(first_nonzero_sample_48k=int(nonzero[0]),first_nonzero_ms=float(nonzero[0]/48),initialization_span_samples_48k=576,initialization_peak=float(np.max(np.abs(x48[:576]))),first_100ms_peak=float(np.max(np.abs(x48[:4800]))))
x,s=sf.read(out/'01-original.wav',dtype='float64');y,t=sf.read(out/'02-preprocessed.wav',dtype='float64');assert s==t==16000 and x.shape==y.shape
c=signal.correlate(y,x,method='fft');mid=len(x)-1;lag=int(np.argmax(c[mid-80:mid+81]))-80
if lag>=0:xa=x[:len(x)-lag];ya=y[lag:]
else:xa=x[-lag:];ya=y[:len(y)+lag]
ratio=float(20*np.log10(np.linalg.norm(ya)/np.linalg.norm(xa)))
report['original_vs_preprocessed']=dict(samples=len(x),duration_seconds=len(x)/16000,best_lag_samples=lag,best_lag_ms=lag/16,correlation=float(np.corrcoef(xa,ya)[0,1]),rms_ratio_db=ratio,input_rms=float(np.sqrt(np.mean(x*x))),output_rms=float(np.sqrt(np.mean(y*y))))
f,px=signal.welch(xa,16000,nperseg=4096);_,py=signal.welch(ya,16000,nperseg=4096)
bands=[]
for lo,hi in [(0,80),(80,300),(300,1000),(1000,4000),(4000,7200),(7200,8001)]:
 mask=(f>=lo)&(f<hi);bands.append(dict(low_hz=lo,high_hz=hi,power_change_db=float(10*np.log10(py[mask].sum()/max(px[mask].sum(),1e-30)))))
report['frequency_bands']=bands
# The native main loop uses this FIR after enhancement.
source=(root/'preprocessor/src/dsp.c').read_text()
values=re.search(r'decimator_coeffs\[DECIMATOR_TAPS\]\s*=\s*\{([^}]+)\}',source,re.S).group(1)
coeff=np.array([float(v.strip().removesuffix('f')) for v in values.split(',') if v.strip()])
control=signal.lfilter(coeff,[1],b)[2::3][:len(x)].astype(np.float32)
sf.write(out/'03-highpass-only-control.wav',control,16000,subtype='FLOAT')
(out/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
