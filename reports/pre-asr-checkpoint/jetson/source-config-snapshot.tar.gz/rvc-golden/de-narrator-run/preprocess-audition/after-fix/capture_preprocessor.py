"""Capture the native preprocessor output without running RVC."""
from pathlib import Path
import hashlib
import json
import math
import socket
import struct
import subprocess
import time
import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

repo = Path('/home/moyamryia/Mozart')
out = Path(__file__).resolve().parent
source = repo/'rvc-golden/input/preprocessor-sample-mp4-first-30s.wav'
audio, rate = sf.read(source, dtype='float32', always_2d=True)
if rate != 16000 or audio.shape[1] != 1 or not np.isfinite(audio).all():
    raise ValueError('Expected the confirmed mono 16 kHz original recording')
samples = audio.shape[0]
frames = math.ceil(samples/320)
# The WAV reader loops at EOF. Silence supplies the final analysis window.
upsampled = resample_poly(audio[:, 0], 3, 1)
padded = np.concatenate([upsampled, np.zeros(48000//4, np.float32)])
input48 = out/'native-input-48k-stereo.wav'
sf.write(input48, np.repeat(padded[:, None], 2, axis=1), 48000, subtype='PCM_16')
header = struct.Struct('<IQIBBBB')
packets = {}
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock, (out/'mozart-pre.log').open('w') as log:
    sock.bind(('127.0.0.1', 0))
    sock.settimeout(1)
    command = [str(repo/'build/usb-pre/mozart-pre'), '-i', str(input48),
        '-a', '127.0.0.1', '-p', str(sock.getsockname()[1]),
        '-n', str(frames), '--pace', '--period-frames', '64', '--mode', 'ai',
        '--ctl-port', '0', '--status-file', str(out/'status.json')]
    proc = subprocess.Popen(command, cwd=repo, stdout=log, stderr=log)
    try:
        deadline = time.monotonic()+frames*.02+10
        while len(packets) < frames:
            if time.monotonic() > deadline:
                raise TimeoutError('Preprocessor output capture timed out')
            try:
                data, _ = sock.recvfrom(65536)
            except socket.timeout:
                if proc.poll() is not None:
                    raise RuntimeError(f'Preprocessor exited with {len(packets)}/{frames} frames')
                continue
            if len(data) != header.size+320*4:
                raise ValueError('Unexpected preprocessor packet length')
            magic, pts, index, vad, energy, conf, segment = header.unpack_from(data)
            if magic != 0x4D5A5254 or index < 1 or index > frames or index in packets:
                raise ValueError('Invalid or duplicate preprocessor frame')
            pcm = np.frombuffer(data, dtype='<f4', offset=header.size).copy()
            if not np.isfinite(pcm).all():
                raise ValueError('Preprocessor output contains non-finite samples')
            packets[index] = pcm
        if proc.wait(timeout=5) != 0:
            raise RuntimeError('Native preprocessor failed; inspect mozart-pre.log')
    finally:
        if proc.poll() is None:
            proc.terminate()
            proc.wait(timeout=5)
result = np.concatenate([packets[i] for i in range(1, frames+1)])[:samples]
status = json.loads((out/'status.json').read_text())
if status['send_errors'] or status['state'] == 'failed':
    raise RuntimeError(f'Preprocessor status reports failure: {status}')
sf.write(out/'02-preprocessed.wav', result, 16000, subtype='FLOAT')
(out/'01-original.wav').write_bytes(source.read_bytes())
report = dict(source=str(source), source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    command=command, frames_received=len(packets), captured_samples=frames*320,
    output_samples=samples, output_rate=16000, output_seconds=samples/16000,
    input_preparation='16k mono -> 48k dual mono PCM16; 250ms silence appended for the analysis tail',
    output_preparation='Capture native MZRT PCM; crop final frame padding to the original sample count',
    stages=status['stages'], status=status, gain_normalization=False,
    input_rms=float(np.sqrt(np.mean(audio.astype(np.float64)**2))),
    output_rms=float(np.sqrt(np.mean(result.astype(np.float64)**2))),
    output_peak=float(np.max(np.abs(result))))
(out/'capture.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
