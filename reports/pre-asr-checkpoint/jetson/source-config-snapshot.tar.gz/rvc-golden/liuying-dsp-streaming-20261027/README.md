# 流萤：原始录音及 DSP 版本的流式试听

已在 Jetson 用 `rvc-golden/run_realtime_reference.py` 生成五份流式参考输出。
全部输出为 48 kHz、单声道、30.00 s，数值有限，满幅样本数为 0。

## 试听顺序

优先播放 `10-liuying-level-matched.wav`。
五段均方根（RMS）电平统一到原音经过流萤后的输出电平。
`00-liuying-comparison.wav` 保留各版原始输出电平。

两份连续对照均采用以下顺序：

1. 原始录音 → 流萤。
2. 保守清理 → 流萤。
3. 加强清理 → 流萤。
4. 原降噪＋升 5 半音 → 流萤。
5. 原降噪＋轻均衡＋升 5 半音 → 流萤。

独立输出为 `01-*` 至 `05-*-liuying-golden-streaming.wav`。
独立电平匹配输出以 `matched-` 开头。
各版实际输入保存在 `inputs/`，并保留原字节。

## 流式配置

- Golden 路径：原版 PyTorch RVC 流式入口，CUDA FP16。
- 模型：流萤，v2、F0、48 kHz、202 个 speaker，使用 ID 0。
- 模型内变调：0 半音。formant shift：0。index rate：0。
- 音高提取：RMVPE。随机种子：114514。
- 输入块：240 ms。历史上下文：2.5 s。
- 交叉淡化：50 ms。同步重叠相加（SOLA）搜索：10 ms。
- 每版独立启动进程，共推理 126 块，按模型帧规则裁成 1440000 个输出样本。

本轮输入源为确认过的同一份原始录音。
SHA-256 为 `d7dafb12f8d444b2270f2d06158f47c235ca7892aaca1513561dc9971f2a8654`。
保守与加强版来自 `voice-cleanup-30s/`。
两个升调版来自 `local-voice-dsp-preview/`。

输入与远端输出哈希已核对，详见 `input-manifest.json` 和 `manifest.json`。
每版的 `.json` 与 `.log` 保留推理参数和运行记录。

远端目录为 `/home/moyamryia/Mozart/rvc-golden/liuying-dsp-streaming-20261027/`。
本次推理进程均已结束，未打开声卡或启动 Mozart 后端服务。

## 适用范围

- 配置：Jetson Orin Nano Super 8GB；PyTorch 2.12.0+cu132；CUDA FP16；文件顺序驱动流式算法。
- 样本数：一份 30 秒录音的五个条件，每个条件运行一次。
- 电平匹配按整份输出 RMS 计算，原始模型输出独立保留。
- 原始录音时长为 30.0004375 s，输出按 10 ms 模型帧单位裁到 30.00 s。
- `probe-cpu.*` 和 `probe-cuda.*` 为开头 2 s 的数值探测记录。
- 用户听感待确认。阻塞：尚无本轮试听反馈；解除条件：完成上述五段对照试听。
