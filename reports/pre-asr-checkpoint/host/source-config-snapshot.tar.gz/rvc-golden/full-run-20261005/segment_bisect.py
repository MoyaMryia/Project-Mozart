#!/usr/bin/env python3
"""One-variable diagnostic: hold only the RVC-bound segment byte constant."""
from pathlib import Path
source=(Path(__file__).parent/'full_run.py').read_text().split("\ntry:\n report['baseline']",1)[0]
source=source.replace("subs=OUT/'subtitles.jsonl'","subs=OUT/'bisect-subtitles.jsonl'").replace("(OUT/'results.json')","(OUT/'segment-bisect.json')")
exec(compile(source,'full_run_helpers','exec'))
try:
 report['baseline']=memory();monitor=threading.Thread(target=watcher);monitor.start()
 backend=launch('backend-segment-bisect',[ROOT/'build-gpu/state/mozart_stated',OUT/'backend.yaml']);ready(API+'/api/status',backend)
 for frozen in [False,True]:
  name='segment-frozen' if frozen else 'segment-original';phase[0]=name
  api('/api/mode/switch',{'mode':'rt_rvc','model_id':'qiqi-zh-realtime'});proxy=Proxy(name,freeze_segment=frozen)
  pre=launch('pre-'+name,[ROOT/'build-gpu/preprocessor/mozart-pre','-i',OUT/'replay-48k-stereo.wav','--pace','-a','127.0.0.1','-p','18005','-o','null','-n','750']);pre.wait(timeout=30);time.sleep(.2)
  record={'freeze_segment':frozen,'preprocessor_exit':pre.returncode,'udp':proxy.close(),'status':api('/api/status')['body'],'same_pcm_rnnoise_and_parameters':True,'only_rvc_bound_segment_byte_changed':True};report['phases'].append(record);finish(pre);save();print(json.dumps(record),flush=True)
  api('/api/mode/switch',{'mode':'idle'})
 report['success']=True
finally:
 stop.set()
 for name,p,log in list(reversed(owned)):finish(p)
 if 'monitor' in globals():monitor.join(timeout=2)
 save()
