#!/usr/bin/env python3
"""Offline scoring only: all workload services must have exited first."""
import json,re,time
from pathlib import Path
import numpy as np
import soundfile as sf
import librosa
import torch
from transformers import WhisperFeatureExtractor,WhisperTokenizerFast,WhisperForConditionalGeneration
root=Path(__file__).resolve().parent;repo=root.parents[1]
torch.set_num_threads(2)
snapshot=next(Path('/home/moyamryia/mozart-archive/seedVC/checkpoints/hf_cache/models--openai--whisper-small/snapshots').iterdir())
feature=WhisperFeatureExtractor.from_pretrained(snapshot,local_files_only=True)
tokenizer=WhisperTokenizerFast.from_pretrained(root.parent/'clone-tts/test-20261004/mozart-whisper-tokenizer',local_files_only=True)
model=WhisperForConditionalGeneration.from_pretrained(snapshot,local_files_only=True,torch_dtype=torch.float16).to('cuda').eval()
def words(s):return re.findall(r"[a-z]+(?:'[a-z]+)?|[0-9]+",s.lower())
def wer(ref,hyp):
 r,h=words(ref),words(hyp);prev=list(range(len(h)+1))
 for i,a in enumerate(r,1):
  cur=[i]
  for j,b in enumerate(h,1):cur.append(min(prev[j]+1,cur[j-1]+1,prev[j-1]+(a!=b)))
  prev=cur
 return prev[-1]/max(len(r),1)
results=[]
original=json.loads((root/'results.json').read_text())['phases'];rn=json.loads((root/'followup-results.json').read_text())['phases']
for phase in original+rn:
 jobs=[x for x in phase['tts_results'] if x['event']=='generated']
 # Same first actual translated sentence per engine, plus the anomalous one-word
 # Pocket job and the RNNoise phase's correctly recognized 1987 sentence.
 selected=jobs[:1]
 if phase['engine']=='pocket' and not phase['rnnoise']:selected+=next(([x] for x in jobs if x['text']=='Wuhan'),[])
 if phase['rnnoise']:selected+=jobs[1:2]
 for run in selected:
  wav,sr=sf.read(run['output'],dtype='float32')
  if sr!=16000:wav=librosa.resample(wav,orig_sr=sr,target_sr=16000)
  features=feature(wav,sampling_rate=16000,return_tensors='pt',return_attention_mask=True)
  t0=time.monotonic()
  with torch.inference_mode():ids=model.generate(features.input_features.to('cuda',dtype=model.dtype),attention_mask=features.attention_mask.to('cuda'),max_new_tokens=128,do_sample=False,forced_decoder_ids=tokenizer.get_decoder_prompt_ids(language='en',task='transcribe'))
  text=tokenizer.batch_decode(ids,skip_special_tokens=True)[0]
  item={'phase':phase.get('phase',phase['engine']),'engine':phase['engine'],'rnnoise':phase['rnnoise'],'seq':run['seq'],'expected':run['text'],'transcribed':text,'WER':wer(run['text'],text),'duration_seconds':run['duration_seconds'],'asr_seconds':time.monotonic()-t0}
  results.append(item);(root/'asr-evaluation.json').write_text(json.dumps({'model':'cached official Whisper-small','device':'cuda','torch':torch.__version__,'small_sample_automatic_check_not_human_identity_approval':True,'results':results},indent=2,ensure_ascii=False));print(json.dumps(item,ensure_ascii=False),flush=True)
# Free ASR residency before comparing RVC spectra and F0 on CPU.
del model;torch.cuda.empty_cache()
import sys
sys.path.insert(0,str(root.parent));from verify_backend import compare as compare_file
from compare_streaming_quality import compare as compare_stream
reference=root.parent/'output/qiqi-zh-espeak-pinyin-mixed-python-reference-DET.wav'
file_metrics=compare_file(reference,root/'espeak-qiqi-file-backend.wav')
raw,sr=sf.read(root/'natural-qiqi-realtime.wav',dtype='float32')
status=json.loads((root/'followup-results.json').read_text())['baseline_natural']['status']['stream']
trim=status['startup_output_underruns']*960
trimmed=raw[trim:trim+30*sr];sf.write(root/'natural-qiqi-realtime-trimmed.wav',trimmed,sr,subtype='FLOAT')
stream_metrics=compare_stream(root.parent/'output/preprocessor-sample-mp4-first-30s-qiqi-upstream-realtime.wav',root/'natural-qiqi-realtime-trimmed.wav',3840)
(root/'rvc-quality.json').write_text(json.dumps({'file':file_metrics,'stream':stream_metrics,'stream_startup_trim_samples_48k':trim,'stream_crop_seconds':30,'no_waveform_filters_or_gain_tuning':True},indent=2,default=float));print(json.dumps({'file':file_metrics,'stream':stream_metrics},default=float),flush=True)
