#!/usr/bin/env python3
"""Real file-queue conversion, isolated from realtime/LLM/TTS residency."""
from pathlib import Path
source=(Path(__file__).parent/'full_run.py').read_text().split("\ntry:\n report['baseline']",1)[0]
source=source.replace("subs=OUT/'subtitles.jsonl'","subs=OUT/'file-check-subtitles.jsonl'").replace("(OUT/'results.json')","(OUT/'file-results.json')")
exec(compile(source,'full_run_helpers','exec'))
try:
 report['baseline']=memory();monitor=threading.Thread(target=watcher);monitor.start();phase[0]='file-rvc'
 assets=OUT/'file-assets';assets.mkdir(exist_ok=True)
 for f in (ROOT/'rvc-golden/qiqi-zh-run').iterdir():
  if f.name in ['hubert_base_dynamic.onnx','rmvpe_dynamic.onnx','rmvpe_dynamic.onnx.data']:
   dst=assets/f.name
   if not dst.exists():dst.symlink_to(f)
 models=OUT/'file-models/qiqi-zh-full';models.mkdir(exist_ok=True,parents=True)
 for f in (ROOT/'rvc-golden/qiqi-zh-run/qiqi-zh-full').iterdir():
  if f.suffix in ['.onnx','.data'] or f.name=='config.json':
   dst=models/f.name
   if not dst.exists():dst.symlink_to(f)
 config=(OUT/'backend.yaml').read_text().replace(str(OUT/'models'),str(models.parent)).replace(str(ROOT/'rvc-golden/qiqi-zh-run/hubert_base_dynamic.onnx'),str(assets/'hubert_base_dynamic.onnx')).replace(str(ROOT/'rvc-golden/qiqi-zh-run/rmvpe_dynamic.onnx'),str(assets/'rmvpe_dynamic.onnx')).replace('realtime_hubert_path: '+str(ROOT/'rvc-golden/qiqi-zh-run/hubert-realtime.onnx'),'realtime_hubert_path: ""').replace('realtime_rmvpe_path: '+str(ROOT/'rvc-golden/qiqi-zh-run/rmvpe-realtime.onnx'),'realtime_rmvpe_path: ""').replace(str(OUT/'jobs'),str(OUT/'file-jobs'))
 (OUT/'file-backend.yaml').write_text(config)
 p=launch('backend-file',[ROOT/'build-gpu/state/mozart_stated',OUT/'file-backend.yaml']);ready(API+'/api/status',p)
 report['startup']=api('/api/status');report['switch']=api('/api/mode/switch',{'mode':'file_rvc','model_id':'qiqi-zh-full'})
 inputfile=ROOT/'rvc-golden/input/qiqi-espeak-pinyin-zh-en-mixed.wav'
 r=subprocess.run(['curl','--fail-with-body','--max-time','30','-s','-X','POST',API+'/api/file/convert','-F','audio_file=@'+str(inputfile),'-F','speaker_id=qiqi-zh-full'],capture_output=True,text=True,check=True)
 report['upload']=json.loads(r.stdout);job=report['upload']['job_id'];t0=time.monotonic();statuses=[]
 while time.monotonic()-t0<600:
  if stop.is_set():raise RuntimeError('resource guard during file conversion')
  status=api('/api/file/status?job_id='+job)['body'];statuses.append(status)
  if status['status'] in ['completed','failed','error','cancelled']:break
  time.sleep(.5)
 report['conversion_seconds']=time.monotonic()-t0;report['job_status']=status;report['statuses']=statuses
 if status['status']!='completed':raise RuntimeError('file job failed: '+json.dumps(status))
 with urllib.request.urlopen(API+'/api/file/result?job_id='+job,timeout=30) as r:(OUT/'espeak-qiqi-file-backend.wav').write_bytes(r.read())
 report['output_sha256']=hashlib.sha256((OUT/'espeak-qiqi-file-backend.wav').read_bytes()).hexdigest();report['final_status']=api('/api/status');report['success']=True
except Exception as e:report['errors'].append(repr(e));report['success']=False;print('ERROR: '+repr(e),flush=True)
finally:
 stop.set()
 for name,p,log in list(reversed(owned)):finish(p)
 if 'monitor' in globals():monitor.join(timeout=2)
 report['after_cleanup']=memory();report['elapsed_seconds']=time.monotonic()-started
 if telemetry:
  report['minimum_available_bytes']=min(m['available_bytes'] for m in telemetry);report['maximum_swap_used_bytes']=max(m['swap_used_bytes'] for m in telemetry)
 with (OUT/'file-memory.jsonl').open('w') as f:
  for m in telemetry:f.write(json.dumps(m)+'\n')
 save();print(json.dumps({k:v for k,v in report.items() if k!='statuses'},ensure_ascii=False),flush=True)
