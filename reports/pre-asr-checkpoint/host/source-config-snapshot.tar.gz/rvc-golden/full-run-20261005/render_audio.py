#!/usr/bin/env python3
"""PCM16 listening copies; never changes raw measurement artifacts."""
import hashlib,json
from pathlib import Path
import numpy as np
import soundfile as sf
root=Path(__file__).resolve().parent;out=root/'audition';out.mkdir(exist_ok=True)
sources={
 'original-chinese-input':root.parent/'clone-tts/test-20261004/reference-zh-male.wav',
 'qiqi-reference-voice':root.parent/'clone-tts/qiqi-20261004/reference-qiqi-natural-source.wav',
 'qiqi-rvc-full-stack':root/'pocket-rnnoise-qiqi-backend.wav',
 'qiqi-english-full-stack':root/'pocket-rnnoise/translation-2.wav',
 'qiqi-pocket-short-word-failure':root/'pocket/translation-8.wav',
 'qiqi-zipvoice-english':root/'zipvoice/translation-1.wav',
 'espeak-input':root.parent/'input/qiqi-espeak-pinyin-zh-en-mixed.wav',
 'espeak-python-golden':root.parent/'output/qiqi-zh-espeak-pinyin-mixed-python-reference-DET.wav',
 'espeak-captured-golden-generator':root/'qiqi-captured-golden-generator.wav',
 'espeak-onnx-generator':root/'qiqi-captured-onnx-generator.wav',
 'espeak-mozart-file-backend':root/'espeak-qiqi-file-backend.wav',
 'natural-upstream-realtime':root.parent/'output/preprocessor-sample-mp4-first-30s-qiqi-upstream-realtime.wav',
 'natural-mozart-realtime':root/'natural-qiqi-realtime-trimmed.wav',
}
report=[]
for name,source in sources.items():
 pcm,sr=sf.read(source,dtype='float32')
 if name=='qiqi-rvc-full-stack':pcm=pcm[:round(sr*7.56)]
 peak=float(np.max(np.abs(pcm)));gain=.95/peak if peak>1 else 1
 target=out/(name+'.wav');sf.write(target,pcm*gain,sr,subtype='PCM_16')
 report.append({'name':name,'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_peak':peak,'audition_only_gain':gain,'audition_duration_seconds':len(pcm)/sr,'file':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
(root/'audition-manifest.json').write_text(json.dumps(report,indent=2))
