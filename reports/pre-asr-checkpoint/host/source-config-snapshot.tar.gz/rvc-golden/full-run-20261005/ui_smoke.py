#!/usr/bin/env python3
"""Read-only frontend smoke and isolated, fresh SSE append/rotation test."""
from pathlib import Path
source=(Path(__file__).parent/'full_run.py').read_text().split("\ntry:\n report['baseline']",1)[0]
source=source.replace("subs=OUT/'subtitles.jsonl'","subs=OUT/'ui-subtitles.jsonl'").replace("(OUT/'results.json')","(OUT/'ui-results.json')").replace("OUT/'sse-events.jsonl'","OUT/'ui-sse-events.jsonl'")
exec(compile(source,'full_run_helpers','exec'))
try:
 env=os.environ.copy();env['MOZART_SUBTITLES_JSONL']=str(subs)
 backend=launch('backend-ui-smoke',[ROOT/'build-gpu/state/mozart_stated',OUT/'backend.yaml'],env);ready(API+'/api/status',backend)
 node='/home/moyamryia/.nvm/versions/node/v24.18.0/bin/node'
 frontend=launch('frontend-ui-smoke',[node,ROOT/'frontend/node_modules/vite/bin/vite.js','preview','--host','127.0.0.1','--port','5173','--strictPort'],cwd=ROOT/'frontend');ready('http://127.0.0.1:5173',frontend)
 print('UI READY',flush=True)
 reader=threading.Thread(target=sse_reader,daemon=True);reader.start();time.sleep(.5)
 with subs.open('a') as f:f.write(json.dumps({'seq':91001,'zh':'正常追加测试','en':'normal append test'})+'\n')
 time.sleep(.7);events=OUT/'ui-sse-events.jsonl';first=events.read_text() if events.exists() else ''
 subs.rename(OUT/'ui-subtitles-before-rotation.jsonl');subs.write_text('')
 with subs.open('a') as f:f.write(json.dumps({'seq':91002,'zh':'轮换后追加测试','en':'append after replacement'})+'\n')
 time.sleep(1);second=events.read_text() if events.exists() else ''
 report['sse']={'append_received':'91001' in first,'append_after_file_replacement_received':'91002' in second,'fresh_connection':True,'consumer_timed_out_during_test':False}
 report['api']={path:api(path) for path in ['/api/status','/api/monitor','/api/models']};save();print(json.dumps(report,ensure_ascii=False),flush=True)
 # Keep the preview alive long enough for browser observation, then clean it up.
 time.sleep(45)
finally:
 stop.set()
 for name,p,log in list(reversed(owned)):finish(p)
 save()
