#!/usr/bin/env python3
"""Test-only speech worker; reads actual bridge translations from JSON stdin."""
import argparse, hashlib, json, sys, time
from pathlib import Path
import numpy as np
import soundfile as sf
import sherpa_onnx as so

p=argparse.ArgumentParser();p.add_argument('--engine',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
a.out.mkdir(parents=True,exist_ok=True)
assets=Path('/home/moyamryia/models/sherpa-onnx');start=time.monotonic()
if a.engine=='vits':
 m=assets/'vits-melo-zh_en'
 cfg=so.OfflineTtsModelConfig(vits=so.OfflineTtsVitsModelConfig(model=str(m/'model.int8.onnx'),lexicon=str(m/'lexicon.txt'),tokens=str(m/'tokens.txt'),data_dir=str(m/'dict'),dict_dir=str(m/'dict')),num_threads=2,provider='cpu')
elif a.engine=='pocket':
 m=assets/'clone-test-downloads/sherpa-onnx-pocket-tts-int8-2026-01-26'
 cfg=so.OfflineTtsModelConfig(pocket=so.OfflineTtsPocketModelConfig(lm_flow=str(m/'lm_flow.int8.onnx'),lm_main=str(m/'lm_main.int8.onnx'),encoder=str(m/'encoder.onnx'),decoder=str(m/'decoder.int8.onnx'),text_conditioner=str(m/'text_conditioner.onnx'),vocab_json=str(m/'vocab.json'),token_scores_json=str(m/'token_scores.json')),num_threads=2,provider='cpu')
else:
 m=assets/'clone-test-downloads/sherpa-onnx-zipvoice-distill-int8-zh-en-emilia'
 cfg=so.OfflineTtsModelConfig(zipvoice=so.OfflineTtsZipvoiceModelConfig(encoder=str(m/'encoder.int8.onnx'),decoder=str(m/'decoder.int8.onnx'),tokens=str(m/'tokens.txt'),lexicon=str(m/'lexicon.txt'),data_dir=str(m/'espeak-ng-data'),vocoder=str(assets/'clone-test-downloads/vocos_24khz.onnx')),num_threads=4,provider='cpu')
tts=so.OfflineTts(so.OfflineTtsConfig(model=cfg))
reference=Path('/home/moyamryia/Mozart/rvc-golden/clone-tts/qiqi-20261004/reference-qiqi-natural-source.wav')
ref,sr=sf.read(reference,dtype='float32')
print(json.dumps({'event':'ready','engine':a.engine,'load_seconds':time.monotonic()-start,'reference_sha256':hashlib.sha256(reference.read_bytes()).hexdigest(),'sherpa':so.__version__}),flush=True)
for line in sys.stdin:
 job=json.loads(line);callbacks=[];t0=time.monotonic()
 def callback(samples,progress):
  callbacks.append({'seconds':time.monotonic()-t0,'samples':len(samples),'progress':float(progress)});return 1
 try:
  if a.engine=='vits':audio=tts.generate(job['en'],sid=0,speed=1)
  else:
   gen=so.GenerationConfig();gen.reference_audio=ref;gen.reference_sample_rate=sr;gen.speed=1;gen.silence_scale=1;gen.num_steps=5 if a.engine=='pocket' else 4
   if a.engine=='pocket':gen.extra={'seed':'42'}
   else:gen.reference_text='他覺得他媽是世界單位他是國旗兩人都不可以犧牲這是一道錯誤的觀念不嗎'
   audio=tts.generate(job['en'],gen,callback)
  elapsed=time.monotonic()-t0;pcm=np.asarray(audio.samples,dtype='float32');rate=int(audio.sample_rate)
  if not len(pcm) or not np.isfinite(pcm).all():raise RuntimeError('empty or nonfinite audio')
  file=a.out/('translation-'+str(job['seq'])+'.wav');sf.write(file,pcm,rate,subtype='FLOAT')
  result={'event':'generated','engine':a.engine,'seq':job['seq'],'text':job['en'],'source':job['zh'],'elapsed_seconds':elapsed,'duration_seconds':len(pcm)/rate,'rtf':elapsed/(len(pcm)/rate),'first_callback_seconds':callbacks[0]['seconds'] if callbacks else None,'callbacks':callbacks,'output':str(file),'output_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'rms':float(np.sqrt(np.mean(pcm.astype('float64')**2))),'peak':float(np.max(np.abs(pcm))),'clipped_percent':float(np.mean(np.abs(pcm)>=1)*100),'sample_rate':rate,'finite':True}
 except Exception as e:result={'event':'error','engine':a.engine,'seq':job['seq'],'error':repr(e)}
 print(json.dumps(result,ensure_ascii=False),flush=True)
