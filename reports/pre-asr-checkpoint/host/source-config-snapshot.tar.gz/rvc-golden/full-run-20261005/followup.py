#!/usr/bin/env python3
"""Complete clean baselines and compare the real default RNNoise/VAD path."""
from pathlib import Path
source=(Path(__file__).parent/'full_run.py').read_text().split("\ntry:\n report['baseline']",1)[0]
source=source.replace("subs=OUT/'subtitles.jsonl'","subs=OUT/'followup-subtitles.jsonl'").replace("(OUT/'results.json')","(OUT/'followup-results.json')").replace("OUT/'sse-events.jsonl'","OUT/'followup-sse-events.jsonl'")
exec(compile(source,'full_run_helpers','exec'))
try:
 report['baseline']=memory();monitor=threading.Thread(target=watcher);monitor.start()
 env=os.environ.copy();env['MOZART_SUBTITLES_JSONL']=str(subs)
 backend=launch('backend-followup',[ROOT/'build-gpu/state/mozart_stated',OUT/'backend.yaml'],env);ready(API+'/api/status',backend)
 for name,inputfile in [('espeak',ROOT/'rvc-golden/input/qiqi-espeak-pinyin-zh-en-mixed.wav'),('natural',ROOT/'rvc-golden/input/preprocessor-sample-mp4-first-30s.wav')]:
  phase[0]='baseline-'+name
  p=launch('baseline-'+name,[GOLDPY,ROOT/'tools/stream_audio_udp.py',inputfile,OUT/(name+'-qiqi-realtime.wav'),'--model-id','qiqi-zh-realtime','--flush-seconds','2','--no-trim-leading'])
  while p.poll() is None:
   if stop.is_set():raise RuntimeError('resource guard in baseline')
   time.sleep(.2)
  report['baseline_'+name]={'exit_code':p.returncode,'status':api('/api/status')['body']};finish(p)
  if report['baseline_'+name]['exit_code']:raise RuntimeError('baseline helper failed')
  print(name+' baseline completed',flush=True);save();api('/api/mode/switch',{'mode':'idle'})
 node='/home/moyamryia/.nvm/versions/node/v24.18.0/bin/node'
 frontend=launch('frontend-preview',[node,ROOT/'frontend/node_modules/vite/bin/vite.js','preview','--host','127.0.0.1','--port','5173','--strictPort'],cwd=ROOT/'frontend');ready('http://127.0.0.1:5173',frontend)
 bindir=Path('/home/moyamryia/mozart-archive/qwen35/llama.cpp/build-cuda-bin');env=os.environ.copy();env['LD_LIBRARY_PATH']=str(bindir)+':'+env.get('LD_LIBRARY_PATH','')
 llm=launch('llama-followup',[bindir/'llama-server','-m','/home/moyamryia/mozart-archive/qwen35/gguf/qwen35-0.8b-text-Q4_K_M.gguf','-c','2048','-ngl','99','-np','1','-t','2','-tb','2','--host','127.0.0.1','--port','18204','--jinja'],env);ready('http://127.0.0.1:18204/health',llm)
 threading.Thread(target=sse_reader,daemon=True).start()
 full_phase('pocket',45,rnnoise=True)
 # Routing state and mode responses use real workers, with test-local presets.
 api('/api/mode/switch',{'mode':'rt_rvc','model_id':'qiqi-zh-realtime'})
 report['routing_checks']=[api('/api/realtime/routing',{'mic_muted':True,'bypass':False}),api('/api/status'),api('/api/realtime/routing',{'mic_muted':False,'bypass':True}),api('/api/status'),api('/api/realtime/routing',{'mic_muted':False,'bypass':False})]
 api('/api/mode/switch',{'mode':'idle'})
 # Existing SSE clients should observe appended records after file replacement.
 prior=OUT/'followup-sse-events.jsonl'
 before=prior.read_text() if prior.exists() else ''
 with subs.open('a') as f:f.write(json.dumps({'seq':90001,'zh':'追加测试','en':'append test'})+'\n')
 time.sleep(1)
 appended=prior.read_text() if prior.exists() else ''
 subs.rename(OUT/'followup-subtitles-before-rotation.jsonl')
 subs.write_text(json.dumps({'seq':90002,'zh':'轮换测试','en':'rotation test'})+'\n')
 time.sleep(1)
 with subs.open('a') as f:f.write(json.dumps({'seq':90003,'zh':'轮换后追加','en':'append after rotation'})+'\n')
 time.sleep(1)
 final=prior.read_text() if prior.exists() else ''
 report['sse_checks']={'append_received':'90001' in appended,'replacement_received':'90002' in final,'post_replacement_append_received':'90003' in final,'production_events_before_test':len(before.splitlines())}
 report['api_checks']={path:api(path) for path in ['/api/status','/api/models','/api/monitor','/api/parameters','/api/logs?limit=10']}
 report['zero_shot_checks']={mode:api('/api/mode/switch',{'mode':mode}) for mode in ['rt_zero_shot','file_zero_shot']}
 report['success']=True
except Exception as e:report['errors'].append(repr(e));report['success']=False;print('ERROR: '+repr(e),flush=True)
finally:
 stop.set()
 for name,p,log in list(reversed(owned)):finish(p)
 if 'monitor' in globals():monitor.join(timeout=2)
 report['after_cleanup']=memory();report['elapsed_seconds']=time.monotonic()-started
 if telemetry:
  report['minimum_available_bytes']=min(m['available_bytes'] for m in telemetry);report['maximum_swap_used_bytes']=max(m['swap_used_bytes'] for m in telemetry)
 with (OUT/'followup-memory.jsonl').open('w') as f:
  for m in telemetry:f.write(json.dumps(m)+'\n')
 save();print(json.dumps({k:v for k,v in report.items() if k not in ['phases','api_checks']},ensure_ascii=False),flush=True)
