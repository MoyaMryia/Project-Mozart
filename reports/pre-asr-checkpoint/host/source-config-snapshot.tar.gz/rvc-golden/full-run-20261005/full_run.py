#!/usr/bin/env python3
"""Bounded full-project run. Owns and cleans all test services and UDP proxies."""
import ctypes, gc, hashlib, json, os, queue, select, signal, socket, struct, subprocess, sys, threading, time, urllib.error, urllib.request
from pathlib import Path
import numpy as np
import soundfile as sf

ROOT=Path('/home/moyamryia/Mozart');OUT=ROOT/'rvc-golden/full-run-20261005'
PY=ROOT/'.venv/bin/python';GOLDPY='/home/moyamryia/vc_backend_venv/bin/python'
API='http://127.0.0.1:18080';stop=threading.Event();owned=[];telemetry=[];phase=['startup'];report={'phases':[],'errors':[]};started=time.monotonic()
OUT.mkdir(exist_ok=True,parents=True);subs=OUT/'subtitles.jsonl';subs.write_text('')

def save(): (OUT/'results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
def memory():
 v={x.split(':')[0]:int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines()}
 return {'t':time.monotonic()-started,'phase':phase[0],'available_bytes':v['MemAvailable'],'used_unavailable_bytes':v['MemTotal']-v['MemAvailable'],'swap_used_bytes':v['SwapTotal']-v['SwapFree']}
def watcher():
 while not stop.is_set():
  m=memory();m['process_rss']={}
  for name,p,log in list(owned):
   try:m['process_rss'][name]=int(next(x for x in Path('/proc/'+str(p.pid)+'/status').read_text().splitlines() if x.startswith('VmRSS:')).split()[1])*1024
   except (OSError,StopIteration):pass
  telemetry.append(m)
  if m['available_bytes']<768*1024**2:
   report['errors'].append('Resource guard: available RAM below 768 MiB in '+phase[0]);stop.set()
  stop.wait(.2)
def parent_cleanup():ctypes.CDLL(None).prctl(1,signal.SIGTERM)
def launch(name,cmd,env=None,piped=False,cwd=ROOT):
 log=(OUT/(name+'.log')).open('w')
 p=subprocess.Popen([str(x) for x in cmd],cwd=cwd,env=env,stdout=subprocess.PIPE if piped else log,stderr=log,text=True,bufsize=1,stdin=subprocess.PIPE if piped else subprocess.DEVNULL,start_new_session=True,preexec_fn=parent_cleanup)
 owned.append((name,p,log));return p
def finish(p):
 if p.poll() is None:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
 for item in list(owned):
  if item[1] is p: item[2].close();owned.remove(item)
def api(path,body=None,method=None):
 req=urllib.request.Request(API+path,data=json.dumps(body).encode() if body is not None else None,method=method,headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=20) as r:return {'code':r.status,'body':json.load(r)}
 except urllib.error.HTTPError as e:return {'code':e.code,'body':json.loads(e.read())}
def ready(url,p):
 for i in range(240):
  if stop.is_set():raise RuntimeError('resource guard stopped startup')
  if p.poll() is not None:raise RuntimeError('service exited: '+str(p.args))
  try:
   with urllib.request.urlopen(url,timeout=1) as r:
    if r.status==200:return
  except OSError:pass
  time.sleep(.25)
 raise RuntimeError('readiness timeout '+url)
def lines(p,q):
 for line in p.stdout:
  try:q.put(json.loads(line))
  except json.JSONDecodeError:pass
def wait_event(q,p,timeout=60):
 end=time.monotonic()+timeout
 while time.monotonic()<end:
  if stop.is_set():raise RuntimeError('resource guard')
  try:return q.get(timeout=.2)
  except queue.Empty:
   if p.poll() is not None:raise RuntimeError('worker exited; see logs')
 raise RuntimeError('worker readiness timeout')
def sse_reader():
 try:
  with urllib.request.urlopen(API+'/api/subtitles',timeout=20) as r:
   while not stop.is_set():
    line=r.readline().decode().strip()
    if line.startswith('data: '):
     with (OUT/'sse-events.jsonl').open('a') as f:f.write(line[6:]+'\n')
 except Exception as e:report['sse_reader_end']=repr(e)

class Proxy:
 def __init__(self,name,freeze_segment=False):
  self.name=name;self.freeze_segment=freeze_segment;self.closed=threading.Event();self.inputs={};self.outputs={};self.errors=[];self.times=[];self.client=None
  self.front=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);self.front.bind(('127.0.0.1',18005))
  self.back=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);self.back.connect(('127.0.0.1',18000))
  self.thread=threading.Thread(target=self.run);self.thread.start()
 def run(self):
  while not self.closed.is_set():
   for s in select.select([self.front,self.back],[],[],.1)[0]:
    try:
     data,addr=s.recvfrom(65536)
     if len(data)<20:continue
     idx=struct.unpack_from('<I',data,12)[0];t=time.monotonic()
     if s is self.front:
      self.client=addr;self.inputs[idx]=(data,t)
      if self.freeze_segment:
       forwarded=bytearray(data);forwarded[19]=1;self.back.send(forwarded)
      else:self.back.send(data)
     else:
      self.outputs[idx]=(data,t)
      if self.client:self.front.sendto(data,self.client)
    except OSError as e:self.errors.append(repr(e))
 def close(self):
  self.closed.set();self.thread.join(timeout=2);self.front.close();self.back.close()
  n=max(self.inputs,default=-1)+1;audio=np.zeros(n*960,dtype='float32');input_audio=np.zeros(n*320,dtype='float32')
  ages=[]
  for idx,(data,t) in self.outputs.items():
   if idx<n and len(data)==3860:audio[idx*960:(idx+1)*960]=np.frombuffer(data[20:],dtype='<f4')
   if idx in self.inputs:ages.append((t-self.inputs[idx][1])*1000)
  for idx,(data,t) in self.inputs.items():input_audio[idx*320:(idx+1)*320]=np.frombuffer(data[20:],dtype='<f4')
  sf.write(OUT/(self.name+'-preprocessor-16k.wav'),input_audio,16000,subtype='FLOAT');sf.write(OUT/(self.name+'-qiqi-backend.wav'),audio,48000,subtype='FLOAT')
  return {'input_packets':len(self.inputs),'output_packets':len(self.outputs),'missing_indices':sorted(set(self.inputs)-set(self.outputs)),'errors':self.errors,'packet_return_age_ms_p95':float(np.percentile(ages,95)) if ages else None,'packet_return_age_is_not_audio_latency':True,'output_finite':bool(np.isfinite(audio).all()),'output_peak':float(np.max(np.abs(audio))) if len(audio) else 0,'output_rms':float(np.sqrt(np.mean(audio.astype('float64')**2))) if len(audio) else 0}

def full_phase(engine,duration=45,rnnoise=False):
 phase_name=engine+'-rnnoise' if rnnoise else engine
 phase[0]=phase_name;folder=OUT/phase_name;folder.mkdir(exist_ok=True)
 response=api('/api/mode/switch',{'mode':'rt_rvc','model_id':'qiqi-zh-realtime'});assert response['body']['status']=='active',response
 tts=launch('tts-'+phase_name,[PY,OUT/'tts_lane.py','--engine',engine,'--out',folder],piped=True)
 tq=queue.Queue();threading.Thread(target=lines,args=(tts,tq),daemon=True).start();load=wait_event(tq,tts)
 bridge=launch('bridge-'+phase_name,[PY,ROOT/'tools/subtitle_bridge.py','--stt-model','/home/moyamryia/models/sherpa-onnx/zipformer-zh-14M','--stt-port','18105','--llama-url','http://127.0.0.1:18204','--jsonl',subs],piped=True)
 bq=queue.Queue();threading.Thread(target=lines,args=(bridge,bq),daemon=True).start()
 for i in range(120):
  if '[stt] listening' in (OUT/('bridge-'+phase_name+'.log')).read_text():break
  # STT readiness is written to bridge stdout, not stderr. Read UDP binding.
  listening=subprocess.run(['ss','-lun'],capture_output=True,text=True).stdout
  if ':18105 ' in listening:break
  if bridge.poll() is not None:raise RuntimeError('subtitle bridge exited')
  time.sleep(.1)
 else:raise RuntimeError('STT not ready')
 proxy=Proxy(phase_name);play_device='null'
 pre_args=[ROOT/'build-gpu/preprocessor/mozart-pre','-i',OUT/'replay-48k-stereo.wav','--pace','-a','127.0.0.1','-p','18005','-b','127.0.0.1:18105','-o',play_device,'-n',str(round(duration/.02))]
 if not rnnoise:pre_args.append('--no-rnnoise')
 pre=launch('pre-'+phase_name,pre_args)
 began=time.monotonic();pending=[];busy=False;events=[];jobs=[];dropped=[];next_status=began;statuses=[]
 def collect():
  nonlocal busy
  while not bq.empty():
   ev=bq.get();ev['observed_seconds']=time.monotonic()-began;events.append(ev)
   if ev.get('en'):
    if len(pending)>=2:dropped.append(pending.pop(0))
    pending.append(ev)
  while not tq.empty():
   ev=tq.get();ev['observed_seconds']=time.monotonic()-began;jobs.append(ev);busy=False
  if not busy and pending:
   ev=pending.pop(0);ev['speech_submitted_seconds']=time.monotonic()-began
   tts.stdin.write(json.dumps(ev,ensure_ascii=False)+'\n');tts.stdin.flush();busy=True
 try:
  while pre.poll() is None:
   if stop.is_set():raise RuntimeError('resource guard in '+engine)
   collect()
   if time.monotonic()>=next_status:statuses.append(api('/api/status')['body']);next_status=time.monotonic()+1
   time.sleep(.05)
  time.sleep(1.5);collect()
  # Close STT first so its final delta is translated before stopping the bridge.
  children=Path('/proc/'+str(bridge.pid)+'/task/'+str(bridge.pid)+'/children')
  if children.exists():
   for pid in children.read_text().split():os.kill(int(pid),signal.SIGTERM)
  end=time.monotonic()+35
  while time.monotonic()<end and (busy or pending or bridge.poll() is None):
   collect();time.sleep(.05)
  collect()
  statuses.append(api('/api/status')['body'])
 finally:
  finish(pre);packets=proxy.close();finish(bridge);finish(tts)
 record={'engine':engine,'phase':phase_name,'duration_seconds':duration,'elapsed_seconds':time.monotonic()-began,'tts_load':load,'playback_device':play_device,'rnnoise':rnnoise,'real_preprocessor':True,'real_subtitle_bridge':True,'source_fixture':'replay-48k-stereo.wav','subtitles':events,'tts_results':jobs,'dropped_speech_jobs':dropped,'uncompleted_jobs':len(pending)+int(busy),'udp':packets,'statuses':statuses,'final_status':statuses[-1] if statuses else None}
 (folder/'results.json').write_text(json.dumps(record,indent=2,ensure_ascii=False));report['phases'].append(record);save()
 print(json.dumps({'phase':engine,'subtitles':len(events),'tts_jobs':len(jobs),'udp':packets,'status':record['final_status']},ensure_ascii=False),flush=True)
 api('/api/mode/switch',{'mode':'idle'})

try:
 report['baseline']=memory();report['git_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
 for port in [18080,18204]:
  with socket.socket() as s:
   if s.connect_ex(('127.0.0.1',port))==0:raise RuntimeError('occupied TCP test port '+str(port))
 for port in [18000,18005,18105]:
  with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:s.bind(('127.0.0.1',port))
 models=OUT/'models/qiqi-zh-realtime';models.mkdir(parents=True,exist_ok=True)
 for file in (ROOT/'rvc-golden/qiqi-zh-run/qiqi-zh-realtime').iterdir():
  if file.suffix in ['.onnx','.engine','.json'] and file.name=='config.json' or file.suffix in ['.onnx','.engine']:
   dst=models/file.name
   if not dst.exists():dst.symlink_to(file)
 config=(ROOT/'rvc-golden/qiqi-zh-run/backend-ui.yaml').read_text().replace('models_dir: /home/moyamryia/Mozart/rvc-golden/qiqi-zh-run','models_dir: '+str(models.parent)).replace('/home/moyamryia/Mozart/rvc-golden/qiqi-zh-run/temp',str(OUT/'jobs')).replace('/home/moyamryia/Mozart/rvc-golden/qiqi-zh-run/presets.json',str(OUT/'presets.json'))
 (OUT/'backend.yaml').write_text(config)
 monitor=threading.Thread(target=watcher);monitor.start()
 env=os.environ.copy();env['MOZART_SUBTITLES_JSONL']=str(subs)
 backend=launch('backend',[ROOT/'build-gpu/state/mozart_stated',OUT/'backend.yaml'],env)
 ready(API+'/api/status',backend);report['startup_status']=api('/api/status');save();print('Backend ready',flush=True)
 # Clean deterministic input, then the natural-source upstream realtime fixture.
 for name,inputfile in [('espeak',ROOT/'rvc-golden/input/qiqi-espeak-pinyin-zh-en-mixed.wav'),('natural',ROOT/'rvc-golden/input/preprocessor-sample-mp4-first-30s.wav')]:
  phase[0]='baseline-'+name
  p=launch('baseline-'+name,[GOLDPY,ROOT/'tools/stream_audio_udp.py',inputfile,OUT/(name+'-qiqi-realtime.wav'),'--model-id','qiqi-zh-realtime','--flush-seconds','2','--no-trim-leading'])
  while p.poll() is None:
   if stop.is_set():raise RuntimeError('resource guard during baseline')
   time.sleep(.2)
  report['baseline_'+name]={'exit_code':p.returncode,'status':api('/api/status')['body']}
  if p.returncode:raise RuntimeError('baseline helper failed: '+name)
  finish(p);save()
  api('/api/mode/switch',{'mode':'idle'})
 bindir=Path('/home/moyamryia/mozart-archive/qwen35/llama.cpp/build-cuda-bin');env=os.environ.copy();env['LD_LIBRARY_PATH']=str(bindir)+':'+env.get('LD_LIBRARY_PATH','')
 llm=launch('llama-server',[bindir/'llama-server','-m','/home/moyamryia/mozart-archive/qwen35/gguf/qwen35-0.8b-text-Q4_K_M.gguf','-c','2048','-ngl','99','-np','1','-t','2','-tb','2','--host','127.0.0.1','--port','18204','--jinja'],env)
 ready('http://127.0.0.1:18204/health',llm);print('Qwen ready',flush=True)
 # Exact human Chinese fixture, plus a 1.5 second gap for real VAD segmentation.
 ref=ROOT/'rvc-golden/clone-tts/test-20261004/reference-zh-male.wav';pcm,sr=sf.read(ref,dtype='float32');padded=OUT/'replay-source.wav';sf.write(padded,np.concatenate([pcm,np.zeros(round(sr*1.5),dtype='float32')]),sr,subtype='FLOAT')
 subprocess.run(['ffmpeg','-loglevel','error','-y','-i',str(padded),'-ar','48000','-ac','2','-c:a','pcm_s16le',str(OUT/'replay-48k-stereo.wav')],check=True)
 report['source_sha256']=hashlib.sha256(ref.read_bytes()).hexdigest();report['source_expected_text']='那还是三十六年前，一九八七年。我呢考上了武汉大学的计算机系。'
 threading.Thread(target=sse_reader,daemon=True).start()
 # Frontend is built separately. Serve Vite during the full workload when available.
 nodes=list(Path('/home/moyamryia/.nvm/versions/node').glob('*/bin/node')) if Path('/home/moyamryia/.nvm/versions/node').exists() else []
 if nodes:
  env=os.environ.copy();env['PATH']=str(nodes[-1].parent)+':'+env['PATH']
  frontend=launch('frontend',[nodes[-1],ROOT/'frontend/node_modules/vite/bin/vite.js','--host','127.0.0.1','--port','5173','--strictPort'],env,cwd=ROOT/'frontend')
  ready('http://127.0.0.1:5173',frontend);report['frontend_served']=True
 for engine in ['vits','pocket','zipvoice']:full_phase(engine,45)
 # Real USB microphone capture and playback, with RNNoise explicitly enabled here.
 phase[0]='physical-io';api('/api/mode/switch',{'mode':'rt_rvc','model_id':'qiqi-zh-realtime'});proxy=Proxy('physical')
 pre=launch('physical-io',[ROOT/'build-gpu/preprocessor/mozart-pre','-d','plughw:CARD=Device,DEV=0','-o','plughw:CARD=Device,DEV=0','-a','127.0.0.1','-p','18005','-n','250'])
 pre.wait(timeout=20);report['physical_io']={'exit_code':pre.returncode,'udp':proxy.close(),'status':api('/api/status')['body'],'rnnoise':True,'duration_seconds':5};finish(pre)
 api('/api/mode/switch',{'mode':'idle'})
 report['api_checks']={path:api(path) for path in ['/api/status','/api/models','/api/monitor','/api/parameters','/api/logs?limit=10']}
 report['zero_shot_checks']={mode:api('/api/mode/switch',{'mode':mode}) for mode in ['rt_zero_shot','file_zero_shot']}
 # Confirm a real generated clone WAV can be submitted to the stable USB device.
 generated=next((OUT/'pocket').glob('translation-*.wav'),None)
 if generated:
  r=subprocess.run(['aplay','-q','-D','plughw:CARD=Device,DEV=0',str(generated)],capture_output=True,text=True,timeout=35)
  report['clone_hardware_playback']={'exit_code':r.returncode,'stderr':r.stderr,'file':str(generated),'human_audition_verified':False}
 report['success']=not report['errors']
except Exception as e:
 report['errors'].append(repr(e));report['success']=False;print('RUN ERROR: '+repr(e),flush=True)
finally:
 stop.set()
 for name,p,log in list(reversed(owned)):finish(p)
 if 'monitor' in globals():monitor.join(timeout=2)
 report['after_cleanup']=memory();report['elapsed_seconds']=time.monotonic()-started
 if telemetry:
  report['minimum_available_bytes']=min(m['available_bytes'] for m in telemetry);report['maximum_swap_used_bytes']=max(m['swap_used_bytes'] for m in telemetry)
 with (OUT/'memory.jsonl').open('w') as f:
  for m in telemetry:f.write(json.dumps(m)+'\n')
 save();print(json.dumps({k:v for k,v in report.items() if k not in ['phases','api_checks']},ensure_ascii=False),flush=True)
