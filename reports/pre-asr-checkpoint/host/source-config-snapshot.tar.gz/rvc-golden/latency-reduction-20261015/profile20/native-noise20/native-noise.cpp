#include <fstream>
#include <random>
#include <string>
#include <vector>
int main(int argc,char**argv){
 const int t=std::stoi(argv[1]);std::mt19937 r(114514);
 std::normal_distribution<float> n(0,1);std::uniform_real_distribution<float> u(0,1);
 std::vector<float> a(192*t),b(1),c(480*t);
 for(auto&x:a)x=n(r);for(auto&x:b)x=u(r);b.front()=0;for(auto&x:c)x=n(r);
 std::ofstream f(argv[2],std::ios::binary);
 for(auto*v:{&a,&b,&c})f.write(reinterpret_cast<char*>(v->data()),v->size()*sizeof(float));
}