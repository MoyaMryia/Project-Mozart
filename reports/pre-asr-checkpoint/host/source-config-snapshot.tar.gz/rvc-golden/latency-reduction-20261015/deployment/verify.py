import io,json,os,signal,socket,subprocess,time,urllib.request
from pathlib import Path
import numpy as np
import soundfile as sf
w=Path('/home/moyamryia/mozart-latency-20261015');d=w/'deployment'
cfg=json.loads((d/'backend-file-fast.json').read_text())
def port(kind):
    with socket.socket(socket.AF_INET,kind) as s:
        s.bind(('127.0.0.1',0));return s.getsockname()[1]
p=port(socket.SOCK_STREAM)
cfg['network']['control']['port']=p;cfg['network']['audio']['port']=port(socket.SOCK_DGRAM)
cfg['storage']['temp_dir']=str(d/'smoke-temp');cfg['storage']['presets_path']=str(d/'smoke-presets.json')
f=d/'smoke-backend.json';f.write_text(json.dumps(cfg,indent=2)+'\n')
def api(route,body=None,ctype='application/json'):
    q=urllib.request.Request(f'http://127.0.0.1:{p}'+route,data=body,headers={'Content-Type':ctype})
    with urllib.request.urlopen(q,timeout=20) as r:
        data=r.read();return data if data.startswith(b'RIFF') else json.loads(data)
with (d/'smoke.log').open('w') as log:
    child=subprocess.Popen([str(w/'build/state/mozart_stated'),str(f)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    try:
        deadline=time.monotonic()+40
        while True:
            try:api('/api/status');break
            except OSError:
                if child.poll() is not None or time.monotonic()>deadline:raise RuntimeError('Preset startup failed')
                time.sleep(.02)
        api('/api/mode/switch',json.dumps(dict(mode='file_rvc',model_id='quality')).encode())
        boundary='MozartPresetSmoke'
        body=(f'--{boundary}\r\nContent-Disposition: form-data; name="model_id"\r\n\r\nquality\r\n--{boundary}\r\nContent-Disposition: form-data; name="audio_file"; filename="input.wav"\r\nContent-Type: audio/wav\r\n\r\n').encode()+(w/'reference/input/qiqi-espeak.wav').read_bytes()+f'\r\n--{boundary}--\r\n'.encode()
        key=api('/api/file/convert',body,'multipart/form-data; boundary='+boundary)['job_id']
        while True:
            job=api('/api/file/status?job_id='+key)
            if job['status'] in ['completed','failed','cancelled']:break
            if time.monotonic()>deadline:raise RuntimeError('Preset conversion timed out')
            time.sleep(.02)
        assert job['status']=='completed',job
        wav=api('/api/file/result?job_id='+key);(d/'qiqi-espeak-deployment-mozart-backend.wav').write_bytes(wav)
        audio,rate=sf.read(io.BytesIO(wav),dtype='float32')
        ref,ref_rate=sf.read(w/'profile20/file-only-final/candidate-fast/qiqi-espeak-candidate-fast-0-mozart-backend.wav',dtype='float32')
        assert rate==ref_rate and np.array_equal(audio,ref)
        status=api('/api/status')
        assert all(status['model'][r+'_backend']=='tensorrt' for r in ['generator','hubert','rmvpe'])
        (d/'verification.json').write_text(json.dumps(dict(pcm_identical=True,job=job,status=status),indent=2)+'\n')
    finally:
        os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=15)
print('Preset verification passed')
