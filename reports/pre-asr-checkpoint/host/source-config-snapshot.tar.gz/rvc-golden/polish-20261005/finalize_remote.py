import hashlib
import json
import pathlib
import subprocess
import time
import urllib.request

root = pathlib.Path('/home/moyamryia/Mozart')
out = root/'rvc-golden/polish-20261005'
expected = json.loads((out/'source-sha256.json').read_text())
assert all(hashlib.sha256((root/path).read_bytes()).hexdigest() == digest for path, digest in expected.items())
(out/'source-verification.json').write_text(json.dumps({'matched_files': len(expected), 'all_match': True}, indent=2))
sections = {
    'README.md': '\n\n## Translated reference speech (2026-10-05)\n\nThe reference speech panel uploads WAVs, previews PocketTTS output, downloads results and controls translated English speech. ASR, translation and TTS run in isolated supervised processes. See [deployment and API](tools/REFERENCE_SPEECH.md) and [measured results](reports/polish-20261005/RESULTS.md). Use `state/translated-speech.yaml` to disable unused RVC models; `tools/run_translated_speech.py` can replay `test-audio.mp4` at microphone pace. Legacy audio-conversion zero-shot modes remain unavailable. Translation accuracy and cross-language voice identity still require work.\n',
    'state/API.md': '\n\n## Independent reference speech (2026-10-05)\n\nThe native API proxies `/api/voices` and `/api/speech/*` to the loopback speech service on port 18081. See [reference speech contracts](../tools/REFERENCE_SPEECH.md) for persistent references, job states, cancellation, downloads and session controls. A missing service returns 503 while native routes continue. `idle` describes the RVC lane; captions and reference speech may continue independently. `rvc.enabled: false` disables RVC capabilities and admission and avoids constructing neural engine owners. The legacy `rt_zero_shot` and `file_zero_shot` audio-conversion enums still return 501.\n',
}
for filename, section in sections.items():
    path = root/filename
    current = path.read_text()
    if section.strip().splitlines()[0] not in current:
        path.write_text(current+section)
log = (out/'final-disabled-backend.log').open('w')
p = subprocess.Popen([root/'build-gpu/state/mozart_stated',root/'state/translated-speech.yaml'], cwd=root, stdout=log, stderr=subprocess.STDOUT)
try:
    for _ in range(900):
        if p.poll() is not None:
            raise RuntimeError('Final daemon exited')
        try:
            with urllib.request.urlopen('http://127.0.0.1:18080/api/status', timeout=1) as r:
                status = json.load(r)
            break
        except OSError:
            time.sleep(.1)
    else:
        raise RuntimeError('Final daemon did not become ready')
    assert not status['capabilities']['rt_rvc'] and not status['capabilities']['file_rvc']
    (out/'final-disabled-status.json').write_text(json.dumps(status,indent=2))
finally:
    p.terminate();p.wait(timeout=10);log.close()
assert 'engine loaded' not in (out/'final-disabled-backend.log').read_text()
print('Source hashes match; final disabled daemon healthy without neural engine construction.')
