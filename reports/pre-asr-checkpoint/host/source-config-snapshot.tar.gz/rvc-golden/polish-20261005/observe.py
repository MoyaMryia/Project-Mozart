import json, pathlib, time, urllib.request
out=pathlib.Path('/home/moyamryia/Mozart/rvc-golden/polish-20261005/telemetry-first.jsonl')
end=time.monotonic()+160
with out.open('w') as f:
 while time.monotonic()<end:
  mem={x.split(':')[0]:int(x.split()[1])*1024 for x in pathlib.Path('/proc/meminfo').read_text().splitlines()}
  record={'at':time.time(),'available_bytes':mem['MemAvailable'],'swap_used_bytes':mem['SwapTotal']-mem['SwapFree']}
  try:
   with urllib.request.urlopen('http://127.0.0.1:18080/api/speech/status',timeout=1) as r:d=json.load(r)
   record['jobs']=[{k:j.get(k) for k in ['id','status','synthesis_seconds','duration_seconds','error']} for j in d['jobs']]
  except OSError as e:record['api_error']=str(e)
  f.write(json.dumps(record)+'\n');f.flush();time.sleep(1)
