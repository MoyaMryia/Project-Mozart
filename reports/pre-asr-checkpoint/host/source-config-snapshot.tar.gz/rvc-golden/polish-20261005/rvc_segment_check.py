from pathlib import Path
source=Path('/home/moyamryia/Mozart/rvc-golden/full-run-20261005/full_run.py').read_text().split('\ntry:\n report[',1)[0]
source=source.replace("OUT=ROOT/'rvc-golden/full-run-20261005'", "OUT=ROOT/'rvc-golden/polish-20261005/rvc-check'")
exec(compile(source,'validation_helpers','exec'))
try:
 api('/api/mode/switch',{'mode':'idle'})
 assert api('/api/mode/switch',{'mode':'rt_rvc','model_id':'qiqi-zh-realtime'})['code']==200
 proxy=Proxy('segments-after-fix')
 pre=launch('pre-segments',[ROOT/'build-gpu/preprocessor/mozart-pre','-i',ROOT/'rvc-golden/full-run-20261005/replay-48k-stereo.wav','--pace','-a','127.0.0.1','-p','18005','-o','null','-n','750'])
 pre.wait(timeout=25)
 time.sleep(.2)
 stats=api('/api/status')['body'];packets=proxy.close()
 segments=sorted(set(data[19] for data,t in proxy.inputs.values()))
 result={'pre_exit_code':pre.returncode,'segment_ids':segments,'packets':packets,'status':stats}
 (OUT/'results.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result,ensure_ascii=False))
finally:
 for _,p,_ in list(reversed(owned)):finish(p)
 api('/api/mode/switch',{'mode':'idle'})
