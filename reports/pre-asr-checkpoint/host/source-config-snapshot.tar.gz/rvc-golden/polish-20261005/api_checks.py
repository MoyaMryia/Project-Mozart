import json,pathlib,threading,time,urllib.request,urllib.error
root=pathlib.Path('/home/moyamryia/Mozart/rvc-golden/polish-20261005')
report={}
def call(path,body=None,method=None):
 req=urllib.request.Request('http://127.0.0.1:18080'+path,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json'},method=method)
 try:
  with urllib.request.urlopen(req,timeout=5) as response:return response.status,json.loads(response.read())
 except urllib.error.HTTPError as e:return e.code,json.loads(e.read())
status=call('/api/speech/status')[1];voice=status['voices'][0]['id']
report['status']=status['engine']; report['unsupported_language']=call('/api/speech/jobs',{'text':'你好','voice_id':voice,'language':'zh'})
report['invalid_json_shape']=call('/api/speech/jobs',[])
# A fresh subtitle reader must survive replacement and incomplete writes.
received=[];closed=False
subs=root/'long-run/subtitles.jsonl'; replacement=subs.with_name('subtitles-before-rotation.jsonl')
def reader():
 try:
  with urllib.request.urlopen('http://127.0.0.1:18080/api/subtitles',timeout=20) as response:
   for raw in response:
    if raw.startswith(b'data: '):received.append(json.loads(raw[6:]))
    if closed:break
 except Exception as e:report['reader_end']=str(e)
t=threading.Thread(target=reader,daemon=True);t.start();time.sleep(.5)
with subs.open('a') as f:f.write(json.dumps({'seq':99001,'zh':'追加测试','en':'append test'})+'\n')
time.sleep(.4)
subs.rename(replacement)
subs.write_text(json.dumps({'seq':99002,'zh':'替换测试','en':'replacement test'})+'\n')
time.sleep(.4)
partial=json.dumps({'seq':99003,'zh':'完整行测试','en':'complete line test'})
with subs.open('a') as f:f.write(partial[:12])
time.sleep(.4)
report['partial_not_published']=not any(e.get('seq')==99003 for e in received)
with subs.open('a') as f:f.write(partial[12:]+'\n')
time.sleep(.5)
report['sse']={str(n):any(e.get('seq')==n for e in received) for n in [99001,99002,99003]}
# Restore the producer's original inode with all production captions intact.
subs.rename(subs.with_name('subtitle-rotation-test.jsonl'));replacement.rename(subs)
closed=True
(root/'api-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False))
