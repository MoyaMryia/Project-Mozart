import base64,hashlib,json,os,pathlib,signal,subprocess,time,urllib.request,urllib.error
import numpy as np,soundfile as sf
root=pathlib.Path('/home/moyamryia/Mozart');out=root/'rvc-golden/polish-20261005';owned=[];report={}
def launch(name,command):
 log=(out/(name+'.log')).open('w');p=subprocess.Popen([str(x) for x in command],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);owned.append((p,log));return p
def finish(p):
 if p.poll() is None:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
def call(path,body=None,method=None,binary=False):
 req=urllib.request.Request('http://127.0.0.1:18080'+path,data=json.dumps(body).encode() if body is not None else None,method=method,headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=10) as r:return r.status,r.read() if binary else json.load(r)
 except urllib.error.HTTPError as e:return e.code,json.loads(e.read())
def ready(path,p):
 for _ in range(100):
  if p.poll() is not None:raise RuntimeError('Service exited')
  try:
   code,d=call(path)
   if code==200:return d
  except OSError:pass
  time.sleep(.2)
 raise RuntimeError('readiness timeout')
def wait(job):
 for _ in range(400):
  code,d=call('/api/speech/jobs/'+job['id'])
  if d['status'] in ['completed','failed','cancelled','expired']:return d
  time.sleep(.2)
 raise RuntimeError('job did not finish')
def add_voice(name):
 code,d=call('/api/voices',{'name':name,'audio_base64':base64.b64encode((root/'rvc-golden/clone-tts/qiqi-20261004/reference-qiqi-natural-source.wav').read_bytes()).decode()})
 assert code==200,(code,d);return d
model=pathlib.Path('/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-pocket-tts-int8-2026-01-26')
command=[root/'.venv/bin/python',root/'tools/speech_service.py','--model',model,'--data-dir',out/'speech-api-test','--playback-device','null']
try:
 subprocess.run(['cp','/tmp/mozart-final-speech-service.py',str(root/'tools/speech_service.py')],check=True)
 backend=launch('api-test-backend',[root/'build-gpu/state/mozart_stated',root/'state/translated-speech.yaml']);ready('/api/status',backend)
 report['speech_absent']=call('/api/speech/status')
 speech=launch('api-test-speech',command);ready('/api/speech/status',speech)
 voice=add_voice('zh-qiqi API test');report['voice']=voice
 def submit(text,**extra):
  code,d=call('/api/speech/jobs',{'text':text,'voice_id':voice['id'],**extra});assert code==200,(code,d);return d
 report['bad_reference']=call('/api/voices',{'name':'bad reference','audio_base64':'AAAA'})
 failed=next(j for j in json.loads((out/'long-run/speech-results.json').read_text())['jobs'] if j['status']=='failed')
 fixed=wait(submit(failed['text']));report['previous_clip_sentence']=fixed;assert fixed['status']=='completed',fixed
 code,raw=call(fixed['result_url'],binary=True);assert code==200
 (out/'qiqi-english-peak-fixed.wav').write_bytes(raw);pcm,sr=sf.read(out/'qiqi-english-peak-fixed.wav')
 report['fixed_audio']={'sha256':hashlib.sha256(raw).hexdigest(),'peak':float(np.max(np.abs(pcm))),'finite':bool(np.isfinite(pcm).all()),'sample_rate':sr}
 report['short_word']=wait(submit('Wuhan'))
 slow=submit('This is a long reference voice cancellation test. '*9)
 for _ in range(60):
  state=call('/api/speech/jobs/'+slow['id'])[1]
  if state['status']=='processing':break
  time.sleep(.05)
 report['protected_reference']=call('/api/voices/'+voice['id'],method='DELETE')
 began=time.monotonic();report['cancel']=call('/api/speech/jobs/'+slow['id'],method='DELETE');report['cancel_seconds']=time.monotonic()-began
 recovered=wait(submit('Hello. This is the Qiqi reference voice preview.',utterance_id='recovery-preview'));report['recovered']=recovered;assert recovered['status']=='completed'
 code,raw=call(recovered['result_url'],binary=True);(out/'qiqi-english-preview.wav').write_bytes(raw)
 duplicate=submit('Hello. This is the Qiqi reference voice preview.',utterance_id='recovery-preview');assert duplicate['id']==recovered['id'];report['deduplication']=True
 finish(speech);report['speech_stopped_native_healthy']=call('/api/status')[0];report['speech_stopped_proxy']=call('/api/speech/status')[0]
 speech=launch('api-test-speech-restarted',command);ready('/api/speech/status',speech)
 code,raw=call(recovered['result_url'],binary=True);assert code==200;report['restart_result_sha256']=hashlib.sha256(raw).hexdigest();assert report['restart_result_sha256']==hashlib.sha256((out/'qiqi-english-preview.wav').read_bytes()).hexdigest()
 duplicate=submit('Hello. This is the Qiqi reference voice preview.',utterance_id='recovery-preview');assert duplicate['id']==recovered['id'];report['restart_deduplication']=True
 temporary=add_voice('CRUD-only fixture');report['delete_unused_reference']=call('/api/voices/'+temporary['id'],method='DELETE')
 result=subprocess.run(['aplay','-q','-D','plughw:CARD=Device,DEV=0',str(out/'qiqi-english-preview.wav')],capture_output=True,text=True,timeout=20)
 report['physical_usb_playback']={'exit_code':result.returncode,'stderr':result.stderr,'human_audition_verified':False}
 assert result.returncode==0
 report['success']=True
 (out/'post-checks.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
 print('API tests complete; UI verification window is open for 120 seconds.',flush=True)
 time.sleep(120)
finally:
 (out/'post-checks.json').write_text(json.dumps(report,indent=2,ensure_ascii=False))
 for p,log in reversed(owned):finish(p);log.close()
