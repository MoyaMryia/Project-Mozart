"""Small offline intelligibility check; run only after timed workloads exit."""
import json
import pathlib
import re
import time

import librosa
import soundfile as sf
import torch
from transformers import WhisperFeatureExtractor, WhisperTokenizerFast, WhisperForConditionalGeneration

root = pathlib.Path(__file__).resolve().parent
torch.set_num_threads(2)
snapshot = next(pathlib.Path('/home/moyamryia/mozart-archive/seedVC/checkpoints/hf_cache/models--openai--whisper-small/snapshots').iterdir())
feature = WhisperFeatureExtractor.from_pretrained(snapshot, local_files_only=True)
tokenizer = WhisperTokenizerFast.from_pretrained(root.parent/'clone-tts/test-20261004/mozart-whisper-tokenizer', local_files_only=True)
model = WhisperForConditionalGeneration.from_pretrained(snapshot, local_files_only=True, torch_dtype=torch.float16).to('cuda').eval()
post = json.loads((root/'post-checks.json').read_text())
summary = json.loads((root/'summary.json').read_text())
samples = [('qiqi-english-preview.wav', post['recovered']['text']),
           ('qiqi-english-peak-fixed.wav', post['previous_clip_sentence']['text']),
           ('qiqi-translated-video.wav', summary['refined-run']['audition']['text'])]
def words(text):
    return re.findall(r"[a-z]+(?:'[a-z]+)?|[0-9]+", text.lower())
def wer(reference, hypothesis):
    r, h = words(reference), words(hypothesis)
    previous = list(range(len(h)+1))
    for i, a in enumerate(r, 1):
        current = [i]
        for j, b in enumerate(h, 1):
            current.append(min(previous[j]+1, current[j-1]+1, previous[j-1]+(a != b)))
        previous = current
    return previous[-1]/max(len(r), 1)
results = []
for filename, expected in samples:
    pcm, rate = sf.read(root/filename, dtype='float32')
    if rate != 16000:
        pcm = librosa.resample(pcm, orig_sr=rate, target_sr=16000)
    encoded = feature(pcm, sampling_rate=16000, return_tensors='pt', return_attention_mask=True)
    began = time.monotonic()
    with torch.inference_mode():
        ids = model.generate(encoded.input_features.to('cuda', dtype=model.dtype),
                             attention_mask=encoded.attention_mask.to('cuda'), max_new_tokens=128,
                             do_sample=False, forced_decoder_ids=tokenizer.get_decoder_prompt_ids(language='en', task='transcribe'))
    text = tokenizer.batch_decode(ids, skip_special_tokens=True)[0]
    item = {'file': filename, 'expected': expected, 'transcribed': text,
            'WER': wer(expected, text), 'decode_seconds': time.monotonic()-began}
    results.append(item)
    print(json.dumps(item), flush=True)
(root/'tts-intelligibility.json').write_text(json.dumps({
    'model': 'cached official Whisper-small', 'sample_count': len(results),
    'human_voice_identity_approval': False, 'results': results}, indent=2))
