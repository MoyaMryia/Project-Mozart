import os
import pathlib
import signal
import subprocess
import time

root = pathlib.Path('/home/moyamryia/Mozart')
out = root / 'rvc-golden/polish-20261005'
commands = [
    ['build-gpu/state/mozart_stated', 'state/translated-speech.yaml'],
    ['.venv/bin/python', 'tools/speech_service.py', '--model',
     '/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-pocket-tts-int8-2026-01-26',
     '--data-dir', str(out / 'speech-api-test'), '--playback-device', 'null'],
]
owned = []
try:
    for i, command in enumerate(commands):
        log = (out / f'ui-{i}.log').open('w')
        process = subprocess.Popen(command, cwd=root, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        owned.append((process, log))
    print('UI services started', flush=True)
    time.sleep(240)
finally:
    for process, log in reversed(owned):
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        log.close()
