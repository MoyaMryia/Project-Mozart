import hashlib,json,pathlib,re,resource,time
import soundfile as sf,sherpa_onnx as so
root=pathlib.Path('/home/moyamryia/Mozart');model=pathlib.Path('/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17')
began=time.monotonic();r=so.OfflineRecognizer.from_sense_voice(model=str(model/'model.int8.onnx'),tokens=str(model/'tokens.txt'),language='zh',use_itn=True,num_threads=2)
load=time.monotonic()-began
file=root/'rvc-golden/clone-tts/test-20261004/reference-zh-male.wav';pcm,sr=sf.read(file,dtype='float32');runs=[]
for _ in range(3):
 t=time.monotonic();stream=r.create_stream();stream.accept_waveform(sr,pcm);r.decode_stream(stream);runs.append({'text':stream.result.text,'seconds':time.monotonic()-t,'rtf':(time.monotonic()-t)/(len(pcm)/sr)})
expected='那还是三十六年前，一九八七年。我呢考上了武汉大学的计算机系。'
def norm(s):return re.sub(r'[^\w\u4e00-\u9fff]','',s.replace('三十六','36').replace('一九八七','1987'))
def edit(a,b):
 row=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  nextrow=[i]
  for j,y in enumerate(b,1):nextrow.append(min(nextrow[-1]+1,row[j]+1,row[j-1]+(x!=y)))
  row=nextrow
 return row[-1]
a=norm(expected);b=norm(runs[-1]['text'])
report={'engine':'sensevoice-int8','sherpa':so.__version__,'model_sha256':hashlib.sha256((model/'model.int8.onnx').read_bytes()).hexdigest(),'input_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'load_seconds':load,'runs':runs,'expected':expected,'digit_normalized_cer':edit(a,b)/len(a),'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}
(root/'rvc-golden/polish-20261005/sensevoice-probe.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));print(json.dumps(report,ensure_ascii=False))
