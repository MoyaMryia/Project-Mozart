"""Summarize saved measurements without rerunning or rescoring timed workloads."""
import collections
import hashlib
import json
import pathlib
import statistics

root = pathlib.Path(__file__).resolve().parent
summary = {}
for name, telemetry in [('first-run', 'telemetry-first.jsonl'),
                        ('long-run', 'telemetry-long.jsonl'),
                        ('refined-run', 'telemetry-refined.jsonl')]:
    phase = root / name
    captions = [json.loads(line) for line in (phase / 'subtitles.jsonl').read_text().splitlines() if line]
    records = [json.loads(line) for line in (root / telemetry).read_text().splitlines() if line]
    jobs = {}
    for record in records:
        for job in record.get('jobs', []):
            jobs[job['id']] = job
    final = json.loads((phase / 'speech-results.json').read_text())
    jobs.update({job['id']: job for job in final['jobs']})
    completed = [job for job in jobs.values() if job['status'] == 'completed']
    def stats(values):
        return {'min': min(values), 'median': statistics.median(values), 'max': max(values)} if values else None
    summary[name] = {
        'caption_count': len(captions),
        'caption_speech_errors': dict(collections.Counter(str(c.get('speech_error')) for c in captions if c.get('speech_error'))),
        'caption_translation_errors': [c for c in captions if c.get('translation_error')],
        'translation_ms': stats([c['translate_ms'] for c in captions if 'translate_ms' in c]),
        'minimum_available_GiB': min(r['available_bytes'] for r in records) / 1024**3,
        'swap_used_bytes': stats([r['swap_used_bytes'] for r in records]),
        'max_unfinished_jobs': max(sum(j['status'] in ['queued','processing','ready','playing'] for j in r.get('jobs', [])) for r in records),
        'job_states': dict(collections.Counter(j['status'] for j in jobs.values())),
        'failed_jobs': [j for j in jobs.values() if j['status'] == 'failed'],
        'synthesis_RTF': stats([j['synthesis_seconds']/j['duration_seconds'] for j in completed]),
        'enqueue_to_audio_ready_seconds': stats([j.get('audio_ready_at', j['finished_at'])-j['created_at'] for j in completed]),
        'completed_audio_seconds': sum(j['duration_seconds'] for j in completed),
    }
    selected = next((j for j in completed if len(j.get('source_text', '')) > 10), completed[0])
    path = root / {'first-run':'speech', 'long-run':'speech-long', 'refined-run':'speech-refined'}[name] / 'results' / (selected['id']+'.wav')
    summary[name]['audition'] = {**selected, 'artifact': str(path.relative_to(root))}
    if name == 'refined-run' and path.exists():
        (root / 'qiqi-translated-video.wav').write_bytes(path.read_bytes())
(root / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
print(json.dumps(summary, ensure_ascii=False, indent=2))
