"""Conservative checks for explicit digits, spoken years and large quantities.

This is not a semantic translation evaluator. It catches dropped/mutated numbers
that the small translator has actually produced in the project's replay tests.
"""
import re
from collections import Counter

DIGITS = {c: i for i, c in enumerate('零一二三四五六七八九')}
DIGITS.update({'〇': 0, '两': 2})
UNITS = {'十': 10, '百': 100, '千': 1000}
MONTHS = ('January', 'February', 'March', 'April', 'May', 'June',
          'July', 'August', 'September', 'October', 'November', 'December')
MONTH_PATTERN = r'(?<!\d)(1[0-2]|[1-9])月'
SMALL_WORDS = ('zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven',
               'eight', 'nine', 'ten', 'eleven', 'twelve')


def translation_number_counts(translation):
    actual = Counter(re.findall(r'\d+(?:\.\d+)?', translation.replace(',', '')))
    # Accept an equivalent small count only with an explicit unit. An unrelated
    # "one" or modal "may" must not mask a missing source quantity.
    for value, word in enumerate(SMALL_WORDS):
        actual[str(value)] += len(re.findall(r'\b'+word+r'\s+(?:times|fold|days?|months?|years?|yuan)\b', translation, flags=re.I))
    return actual


def integer(text):
    if text.isdecimal():
        return int(text)
    total = current = 0
    for character in text:
        if character in DIGITS:
            current = DIGITS[character]
        elif character in UNITS:
            total += (current or 1)*UNITS[character]
            current = 0
    return total+current


def required_number_counts(text):
    numbers = Counter()
    for digits, unit in re.findall(r'(\d+(?:\.\d+)?)([万亿千百]?)', text.replace(',', '')):
        if unit:
            value = float(digits)*{'万':10000, '亿':100000000, '千':1000, '百':100}[unit]
            numbers[str(int(value)) if value.is_integer() else str(value)] += 1
        else:
            numbers[digits] += 1
    # Read a year digit by digit, e.g. 一九八七年.
    for year in re.findall(r'([零〇一二三四五六七八九]{4})年', text):
        numbers[''.join(str(DIGITS[c]) for c in year)] += 1
    def large(match):
        amount, unit = match.groups()
        scale = {'万':10000, '亿':100000000}[unit]
        if len(amount) == 2 and all(c in DIGITS for c in amount):
            # Conversational ranges: 七八万 means 70,000–80,000.
            numbers.update(str(DIGITS[c]*scale) for c in amount)
        else:
            numbers[str(integer(amount)*scale)] += 1
        return ''
    remainder = re.sub(r'([零〇一二两三四五六七八九十百千]+)(万|亿)', large, text)
    for amount in re.findall(r'[零〇一二两三四五六七八九十百千]+', remainder):
        if not any(unit in amount for unit in ('百','千')):
            continue
        if not any(c in DIGITS for c in amount) and '十' not in amount:
            # 几千/数百 are vague quantities, not explicit 1,000/100.
            continue
        if len(amount) == 3 and amount[0] in DIGITS and amount[1] in DIGITS and amount[2] in ('百','千'):
            numbers.update(str(DIGITS[c]*UNITS[amount[2]]) for c in amount[:2])
        else:
            numbers[str(integer(amount))] += 1
    return numbers


def required_numbers(text):
    return sorted(required_number_counts(text), key=lambda n: float(n))


def normalize_translation_quantities(text):
    """Spell explicit 万/亿 quantities as equivalent Arabic numerals for the LLM.

    Keep the original source for captions and validation. Do not guess vague
    quantities (几万), broken mixed numerals (一0百), dates or idioms.
    """
    def arabic(match):
        value = float(match[1])*{'万':10000, '亿':100000000}[match[2]]
        return str(int(value)) if value.is_integer() else str(value)
    numerals = '零〇一二两三四五六七八九十百千万亿'
    # Do not partially replace composite quantities such as 一亿五千万 or
    # 2万5千: adjacent replacements could concatenate unrelated digit strings.
    text = re.sub(r'(?<![\d'+numerals+r'])(\d+(?:\.\d+)?)([万亿])(?![\d'+numerals+r'])', arabic, text)
    def chinese(match):
        amount, unit = match.groups()
        scale = {'万':10000, '亿':100000000}[unit]
        if len(amount) == 2 and all(c in DIGITS for c in amount):
            return '–'.join(str(DIGITS[c]*scale) for c in amount)
        return str(integer(amount)*scale)
    return re.sub(r'(?<![\d'+numerals+r'])([零〇一二两三四五六七八九十百千]+)(万|亿)(?![\d'+numerals+r'])', chinese, text)


def repeated_numbers(source, translation):
    required = required_number_counts(source)
    actual = translation_number_counts(translation)
    # A spelled-out calendar name plus an added numeric amount still contains
    # two occurrences of that value: "June ... won 6" is not a faithful 6月底.
    for month in set(re.findall(MONTH_PATTERN, source)):
        actual[month] += len(re.findall(r'\b'+MONTHS[int(month)-1]+r'\b',translation))
    return [n for n in required if actual[n] > required[n]]


def added_large_numbers(source, translation):
    """Reject invented explicit amounts/years, without guessing small counts.

    A vague source such as 几千 does not license a specific 70,000. This check
    does not claim to validate roles, idioms or the meaning around an amount.
    """
    required = required_number_counts(source)
    return sorted((n for n, count in translation_number_counts(translation).items()
                   if count and float(n) >= 1000 and n not in required), key=float)


def values_changed_to_item_counts(source, translation):
    """Catch the measured 'goods worth 38,000' -> '38,000 items' error.

    Only explicit source value constructions qualify; this is a narrow check,
    not a semantic evaluator or an inference about unspecified currency.
    """
    normalized = normalize_translation_quantities(source)
    values = re.findall(r'(?:等值的商品|价值(?:超过)?)(\d+(?:\.\d+)?)', normalized)
    english = translation.replace(',', '')
    return [n for n in values if re.search(r'\b'+re.escape(n)+r'\+?\s+(?:items|products|goods)\b',english,re.I)]


def missing_numbers(source, translation):
    actual = {n for n, count in translation_number_counts(translation).items() if count}
    # A calendar translation such as 2022年5月 -> May 2022 preserves the
    # month. Do not let a month name satisfy another quantity with that value.
    other_values = set(required_numbers(re.sub(MONTH_PATTERN, '', source)))
    for month in re.findall(MONTH_PATTERN, source):
        if month not in other_values and re.search(r'\b'+MONTHS[int(month)-1]+r'\b', translation):
            actual.add(month)
    return [n for n in required_numbers(source) if n not in actual]


def changed_loan_repayment(source, translation):
    """Reject the measured explicit 还贷款 -> borrowing error; not full semantics."""
    if '还贷款' not in source:
        return False
    repayment = re.search(r'\b(?:repay(?:s|ing|ment|ments|ed)?|repaid|pay(?:ing|s)?\s+(?:back|off)|paid\s+(?:back|off)|settle(?:d|s)?\s+(?:the\s+)?loan)\b', translation, re.I)
    borrowing = re.search(r'\b(?:take|taking|took|taken|get|getting|got|borrow(?:ed|ing|s)?)\s+(?:out\s+)?(?:a|the|another)?\s*loan\b', translation, re.I)
    return not repayment or (bool(borrowing) and '借' not in source)
