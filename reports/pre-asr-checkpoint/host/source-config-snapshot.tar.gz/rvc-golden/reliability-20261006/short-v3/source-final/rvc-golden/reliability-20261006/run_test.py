"""Own one bounded, paced Jetson soak; archive results before history eviction."""
import collections
import fcntl
import hashlib
import json
import os
import re
from pathlib import Path
import shutil
import signal
import statistics
import subprocess
import sys
import time
import urllib.request
import wave

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
assert len(sys.argv) == 3 and '/' not in sys.argv[1], 'Usage: run_test.py ATTEMPT SECONDS'
HERE = BASE/sys.argv[1]
HERE.mkdir(exist_ok=True)
SOURCE_SECONDS = int(sys.argv[2])
WATCHDOG_SECONDS = SOURCE_SECONDS+360
TERMINAL = {'completed', 'failed', 'cancelled', 'expired'}


def save(path, value):
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2))
    temporary.replace(path)


def stats(values):
    if not values:
        return None
    ordered = sorted(values)
    return {'min': min(values), 'median': statistics.median(values),
            'p95': ordered[min(len(ordered)-1, int(.95*len(ordered)))], 'max': max(values)}


def file_hash(path):
    result=hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda:source.read(1024*1024),b""):result.update(block)
    return result.hexdigest()


def main():
    # Check dependencies before any owned backend/service starts.
    import numpy, soundfile, sherpa_onnx
    campaign_lock = (BASE/'active-test.lock').open('a')
    fcntl.flock(campaign_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    for filename in ['progress.json', 'exit-status.json', 'summary.json']:
        if (HERE/filename).exists():
            raise RuntimeError('This run directory already has results; never overwrite a run')
    (HERE/'archive').mkdir(exist_ok=True)
    (HERE/'archive-chunks').mkdir(exist_ok=True)
    import importlib.util
    spec = importlib.util.spec_from_file_location('mozart_profile', ROOT/'rvc-golden/overload-diagnosis-20261006/profile.py')
    profile = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(profile)
    previous = {}
    last_sample = time.monotonic()
    selected_model=json.loads((BASE/'campaign-state.json').read_text())['selected_translator']
    model_hash=hashlib.sha256()
    with Path(selected_model['path']).open('rb') as model_file:
        for data in iter(lambda:model_file.read(1024*1024),b''):model_hash.update(data)
    assert model_hash.hexdigest()==selected_model['sha256'],'Selected model hash mismatch'
    command = [sys.executable, str(ROOT/'tools/run_translated_speech.py'),
        '--backend-config', str(ROOT/'state/translated-speech.yaml'),
        '--reference', str(ROOT/'rvc-golden/clone-tts/qiqi-20261004/reference-qiqi-natural-source.wav'),
        '--reference-name', 'zh-qiqi longer test', '--input', '/tmp/test-audio.mp4',
        '--archive-utterances', '--start', '720', '--seconds', str(SOURCE_SECONDS), '--playback-device', 'null',
        '--llama-model',selected_model['path'],
        '--final-model', '/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17',
        '--run-dir', str(HERE/'runtime'), '--data-dir', str(HERE/'speech')]
    start = time.time()
    save(HERE/'protocol.json', {'command': command, 'started_at': start,
        'source_start_seconds': 720, 'source_seconds': SOURCE_SECONDS,
        'input_sha256': file_hash('/tmp/test-audio.mp4'),
        'reference_sha256': hashlib.sha256(Path(command[command.index('--reference')+1]).read_bytes()).hexdigest(),
        'source_sha256': {name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
                          for name in ['tools/speech_service.py','tools/speech_chunks.py','tools/clone_worker.py',
                                       'tools/stt_service.py','tools/subtitle_bridge.py','tools/translation_checks.py','tools/run_translated_speech.py',
                                       'rvc-golden/reliability-20261006/run_test.py']},
        'output': 'ALSA null paced to each generated WAV duration; no physical-speaker soak',
        'rvc_enabled': False, 'live_audio_budget_seconds': 24, 'playback_buffer_limit_seconds': 12, 'chunk_target_words':12,
        'translator_model_sha256':model_hash.hexdigest(),
        'translation_batch_size':256,'translation_ubatch_size':128,'translation_cache_mib':128,
        'deferred_text_queue_limit':4,'live_deadline_seconds': 30, 'watchdog_seconds': WATCHDOG_SECONDS})
    jobs = {}
    hashes = {}
    chunk_hashes = {}
    samples = []
    stopped = False
    def signal_stop(*_):
        nonlocal stopped
        stopped = True
    signal.signal(signal.SIGTERM, signal_stop)
    signal.signal(signal.SIGINT, signal_stop)
    log = (HERE/'launcher.log').open('w')
    process = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    save(HERE/'pids.json', {'harness': os.getpid(), 'supervisor': process.pid})
    failure = None
    def capture(current):
        for job in current:
            jobs[job['id']] = dict(job)
            for chunk in job.get('chunks', []):
                name = chunk['filename']
                source = HERE/'speech/results'/name
                if name not in chunk_hashes and source.exists():
                    target = HERE/'archive-chunks'/name
                    shutil.copyfile(source, target)
                    chunk_hashes[name] = hashlib.sha256(target.read_bytes()).hexdigest()
            if job['status'] == 'completed' and job['id'] not in hashes:
                source = HERE/'speech/results'/(job['id']+'.wav')
                if source.exists():
                    target = HERE/'archive'/source.name
                    shutil.copyfile(source, target)
                    hashes[job['id']] = hashlib.sha256(target.read_bytes()).hexdigest()
                    save(target.with_suffix('.json'), job)
    try:
        with (HERE/'telemetry.jsonl').open('w') as telemetry:
            while process.poll() is None:
                now = time.time()
                if stopped or now-start > WATCHDOG_SECONDS:
                    failure = 'Stopped by signal' if stopped else f'Harness watchdog exceeded {WATCHDOG_SECONDS} seconds'
                    break
                mem = {line.split(':')[0]: int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines()}
                tick = time.monotonic()
                record = profile.sample(previous, max(.001,tick-last_sample))
                previous = record
                last_sample = tick
                try:
                    with urllib.request.urlopen('http://127.0.0.1:18080/api/speech/status', timeout=2) as response:
                        state = json.load(response)
                    capture(state['jobs'])
                    record.update(unfinished=sum(job['status'] not in TERMINAL for job in state['jobs']),
                                  playback_wait_seconds=state.get('buffered_audio_seconds',0),
                                  audio_backlog_seconds=state.get('audio_backlog_seconds',0),
                                  job_states=dict(collections.Counter(job['status'] for job in state['jobs'])), deferred_jobs=state.get('deferred_jobs',0))
                except OSError as error:
                    record['api_error'] = str(error)
                telemetry.write(json.dumps(record)+'\n');telemetry.flush()
                samples.append(record)
                if len(samples)%5 == 1:
                    save(HERE/'jobs.json', sorted(jobs.values(), key=lambda job: job['created_at']))
                    save(HERE/'progress.json', {'status':'running', 'elapsed_seconds': now-start,
                        'observed_job_states':dict(collections.Counter(job['status'] for job in jobs.values())),
                        'archived_completed_wavs':len(hashes), 'available_GiB':mem['MemAvailable']/1024**3,
                        'latest_sample':record})
                time.sleep(2)
    except Exception as error:
        failure = str(error)
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=90)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL);process.wait()
        log.close()
        # Terminal records can finish between the last poll and service shutdown.
        for path in (HERE/'speech/results').glob('*.json'):
            capture([json.loads(path.read_text())])
        completed = sorted([job for job in jobs.values() if job['status']=='completed'], key=lambda job:job['created_at'])
        missing = [job['id'] for job in completed if job['id'] not in hashes]
        if missing:
            failure = 'Completed audio missing from archive: '+', '.join(missing)
        combined = HERE/'qiqi-translated-combined.wav'
        segments = []
        offset = 0
        if completed and not missing:
            with wave.open(str(combined),'wb') as writer:
                settings = None
                for job in completed:
                    path = HERE/'archive'/(job['id']+'.wav')
                    with wave.open(str(path),'rb') as source:
                        actual = (source.getnchannels(),source.getsampwidth(),source.getframerate())
                        if settings is None:
                            settings = actual
                            writer.setnchannels(actual[0]);writer.setsampwidth(actual[1]);writer.setframerate(actual[2])
                        if actual != settings:
                            raise RuntimeError('Cannot combine mismatched WAV formats')
                        duration = source.getnframes()/source.getframerate()
                        writer.writeframes(source.readframes(source.getnframes()))
                    segments.append({'job_id':job['id'], 'start_seconds':offset,
                        'duration_seconds':duration, 'text':job['text'], 'source_text':job.get('source_text','')})
                    offset += duration
        captions_path = HERE/'runtime/subtitles.jsonl'
        captions = [json.loads(line) for line in captions_path.read_text().splitlines() if line] if captions_path.exists() else []
        microphone = (HERE/'runtime/microphone.log').read_text() if (HERE/'runtime/microphone.log').exists() else ''
        frame_match = re.findall(r'发送 (\d+) 帧.*overruns=(\d+)', microphone)
        summary = {'status':'finished' if process.returncode==0 and not failure else 'failed',
            'exit_code':process.returncode, 'failure':failure, 'elapsed_seconds':time.time()-start,
            'source_start_seconds':720, 'source_seconds':SOURCE_SECONDS, 'caption_count':len(captions),
            'job_states':dict(collections.Counter(job['status'] for job in jobs.values())),
            'speech_admission_errors':dict(collections.Counter(c['speech_error'] for c in captions if c.get('speech_error'))),
            'translation_errors':[c for c in captions if c.get('translation_error')],
            'failed_jobs':[job for job in jobs.values() if job['status']=='failed'],
            'archived_completed_wavs':len(hashes), 'missing_completed_wavs':missing,
            'combined_seconds':offset, 'combined_sha256':hashlib.sha256(combined.read_bytes()).hexdigest() if combined.exists() else None,
            'minimum_available_GiB':min(r['available_bytes'] for r in samples)/1024**3 if samples else None,
            'swap_used_bytes':stats([r['swap_used_bytes'] for r in samples]),
            'max_unfinished':max((r.get('unfinished',0) for r in samples), default=0),
            'max_waiting_playback_seconds':max((r.get('playback_wait_seconds',0) for r in samples), default=0),
            'synthesis_RTF':stats([j['synthesis_seconds']/j['duration_seconds'] for j in completed]),
            'enqueue_to_playback_seconds':stats([j['playback_started_at']-j['created_at'] for j in completed]),
            'chunk_duration_seconds':stats([p['duration_seconds'] for j in jobs.values() for p in j.get('chunks',[])]),
            'chunk_synthesis_seconds':stats([p['synthesis_seconds'] for j in jobs.values() for p in j.get('chunks',[]) if 'synthesis_seconds' in p]),
            'total_generated_chunks':sum(j.get('generated_chunks',0) for j in jobs.values()),
            'native_frames':int(frame_match[-1][0]) if frame_match else None,
            'native_overruns':int(frame_match[-1][1]) if frame_match else None,
            'completed_jobs_preserve_all_text':all(' '.join(p['text'] for p in j['chunks'])==' '.join(j['text'].split()) for j in completed),
            'partial_failed_or_expired_jobs':sum(j['status'] in ['failed','expired'] and j.get('played_chunks',0)>0 for j in jobs.values()),
            'first_piece_played_before_generation_done':sum(j.get('playback_started_at',float('inf'))<j.get('generation_finished_at',0) for j in completed),
            'median_CPU_percent':statistics.median([r['cpu_all_cores_percent'] for r in samples if r['cpu_all_cores_percent'] is not None]) if any(r['cpu_all_cores_percent'] is not None for r in samples) else None,
            'swapin_pages':samples[-1]['pswpin']-samples[0]['pswpin'] if samples else None,
            'enqueue_to_audio_ready_seconds':stats([j['audio_ready_at']-j['created_at'] for j in completed]),
            'ready_to_playback_seconds':stats([j['playback_started_at']-j['audio_ready_at'] for j in completed]),
            'translation_ms':stats([c['translate_ms'] for c in captions if 'translate_ms' in c]),
            'original_silence_and_playback_timing_preserved_in_combined':False}
        summary['deferred_jobs_total']=sum(bool(j.get('was_deferred')) for j in jobs.values())
        summary['deferred_jobs_completed']=sum(bool(j.get('was_deferred')) and j['status']=='completed' for j in jobs.values())
        summary['deferred_admission_wait_seconds']=stats([j.get('admission_wait_seconds',0) for j in jobs.values() if j.get('was_deferred')])
        save(HERE/'combined-segments.json', segments)
        save(HERE/'jobs.json', sorted(jobs.values(),key=lambda job:job['created_at']))
        save(HERE/'archive-sha256.json', hashes)
        save(HERE/'archive-chunks-sha256.json', chunk_hashes)
        save(HERE/'summary.json', summary)
        save(HERE/'exit-status.json', {'code':process.returncode,'failure':failure})
        save(HERE/'progress.json',summary)
        print(json.dumps(summary,ensure_ascii=False),flush=True)


if __name__ == '__main__':
    main()
