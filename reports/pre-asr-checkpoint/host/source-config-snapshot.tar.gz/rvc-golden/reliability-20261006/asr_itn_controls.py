"""Inspect SenseVoice's numeral-normalization flag on retained source spans."""
from pathlib import Path
import array,fcntl,hashlib,json,sys,wave
import sherpa_onnx
BASE=Path(__file__).resolve().parent;HERE=BASE/sys.argv[1];HERE.mkdir(exist_ok=False)
lock=(BASE/'active-test.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
prior=BASE/'asr-endpoint-v2';assert json.loads((prior/'exit-status.json').read_text())['complete']
rows=json.loads((prior/'results.json').read_text());targets=[]
for mode,ids in [('ungated',[1,2,15,16,23]),('gated',[1,5,8,9,10])]:
 for row in rows[mode]['captions']:
  if row['seq'] in ids:targets.append({'mode':mode,**row})
results=[]
for flag in [True,False]:
 rec=sherpa_onnx.OfflineRecognizer.from_sense_voice(model='/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17/model.int8.onnx',tokens='/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17/tokens.txt',num_threads=2,language='zh',use_itn=flag)
 for row in targets:
  path=prior/row['wav'];assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
  with wave.open(str(path)) as f:pcm=array.array('h',f.readframes(f.getnframes()))
  ss=rec.create_stream();ss.accept_waveform(16000,[v/32768 for v in pcm]);rec.decode_stream(ss)
  item={'mode':row['mode'],'seq':row['seq'],'use_itn':flag,'text':ss.result.text,'tokens':ss.result.tokens,'source_wav':str(path),'source_sha256':row['sha256'],'human_source_transcript_verified':False};results.append(item);print(json.dumps(item,ensure_ascii=False),flush=True)
  (HERE/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
 del rec
(HERE/'exit-status.json').write_text(json.dumps({'complete':True,'all_inference_finished':True})+'\n')
