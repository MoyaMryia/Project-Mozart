"""Model-free replay of the new guard on exact retained ASR event evidence."""
from pathlib import Path
import json,sys
from unittest.mock import patch
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base.parents[1]/'tools'))
from asr_checks import polarity_audit
from subtitle_bridge import translate_recognized_event
here=base/sys.argv[1];here.mkdir(exist_ok=False);rows=[]
for line in (base/'short-v4/runtime/subtitles.jsonl').read_text().splitlines():
 c=json.loads(line);audit=polarity_audit(c['online_text'],c['zh'])
 if audit:
  if audit['issues']:
   with patch('subtitle_bridge.request_json') as request:
    try:translate_recognized_event('http://unused',{'text':c['zh'],'asr_polarity_audit':audit})
    except ValueError:pass
    else:raise AssertionError('Conflicting modal cues reached translator')
    request.assert_not_called()
  rows.append({'seq':c['seq'],'audit':audit,'blocked_before_translation':bool(audit['issues'])})
assert [r['seq'] for r in rows if r['blocked_before_translation']]==[15]
(here/'results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');(here/'exit-status.json').write_text(json.dumps({'complete':True,'no_model_inference':True,'blocked_before_translation':[15]})+'\n');print(json.dumps(rows,ensure_ascii=False))
