"""Isolated CPU int8 dedicated MT comparison; no deployment or speech replay."""
import fcntl,json,pathlib,sys,time,resource
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path[:0]=[str(BASE/'python-deps'),str(ROOT/'tools')]
import ctranslate2,sentencepiece
from translation_checks import normalize_translation_quantities,missing_numbers,repeated_numbers,added_large_numbers
HERE=BASE/'translation-opus-v1';HERE.mkdir(exist_ok=False)
lock=(BASE/'active-test.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
start=time.monotonic();model=ctranslate2.Translator(str(BASE/'opus-ct2'),device='cpu',compute_type='int8',intra_threads=2,inter_threads=1)
source=sentencepiece.SentencePieceProcessor(model_file=str(BASE/'opus-source/source.spm'));target=sentencepiece.SentencePieceProcessor(model_file=str(BASE/'opus-source/target.spm'))
rows=json.loads((BASE/'translation-cases.json').read_text())
rows += [{'seq':'clean-negation','zh':'我没有赢到25000元。','en':'I did not win 25,000 yuan.'},
 {'seq':'clean-uncertainty-date','zh':'他可能在2022年5月回来。','en':'He may return in May 2022.'},
 {'seq':'clean-value','zh':'我的库存里有价值38000元的商品。','en':'My inventory contains goods worth 38,000 yuan.'},
 {'seq':'clean-crocodile','zh':'我在之后的半年用实际行动告诉他们这是鳄鱼的眼泪。','en':'Over the following six months, I showed them through my actions that these were crocodile tears.'},
 {'seq':'clean-gambling','zh':'7月，我先赢了16000元，之后赢到2万元。平台要求5倍流水，但我没打够。','en':'In July, I first won 16,000 yuan and later reached 20,000. The platform required five times the wagering turnover, but I did not reach it.'},
 {'seq':'clean-benchmark','zh':'这个手机跑分很高。','en':'This phone has a high benchmark score.'}]
results=[]
for row in rows:
 text=normalize_translation_quantities(row['zh'])
 if '跑分' in text and '账户' in text and '网赌' in text:text=text.replace('跑分','account provision')
 began=time.monotonic();tokens=source.encode(text,out_type=str)+['</s>']
 output=model.translate_batch([tokens],beam_size=4,max_decoding_length=256)[0].hypotheses[0]
 english=target.decode([t for t in output if t not in ['</s>','<pad>']])
 result={'seq':row['seq'],'source':row['zh'],'translation_source':text,'translation':english,'baseline_translation':row['en'],'seconds':time.monotonic()-began,'missing':missing_numbers(row['zh'],english),'repeated':repeated_numbers(row['zh'],english),'added_large':added_large_numbers(row['zh'],english),'possibly_truncated':len(output)>=256}
 results.append(result);print(json.dumps(result,ensure_ascii=False),flush=True);(HERE/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
(HERE/'exit-status.json').write_text(json.dumps({'finished':True,'elapsed_seconds':time.monotonic()-start,'maxRSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'runtime':'CPU int8 two threads CTranslate2 4.6.2','no_speech_workload':True})+'\n')
