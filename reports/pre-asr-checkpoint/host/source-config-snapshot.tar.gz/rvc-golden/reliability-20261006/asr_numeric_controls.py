"""Exercise the deployed one-model numeric check on all retained source spans."""
import hashlib,json,resource,sys,time,wave
from pathlib import Path
from unittest.mock import patch
import sherpa_onnx
base=Path(__file__).resolve().parent;root=base.parents[1]
sys.path.insert(0,str(root/'tools'))
from asr_checks import refine_with_numeric_check
from subtitle_bridge import translate_recognized_event
here=base/sys.argv[1];here.mkdir(exist_ok=False)
prior=base/'short-v3';captions=[json.loads(s) for s in (prior/'runtime/subtitles.jsonl').read_text().splitlines() if s]
expected={r['seq']:r['text'] for r in json.loads((base/'asr-itn-v1/results.json').read_text()) if r['mode']=='ungated' and not r['use_itn']}
model=Path('/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17')
recognizer=sherpa_onnx.OfflineRecognizer.from_sense_voice(model=str(model/'model.int8.onnx'),tokens=str(model/'tokens.txt'),num_threads=2,language='zh',use_itn=True)
rows=[];start=time.monotonic()
for caption in captions:
 source=prior/'runtime/utterances'/Path(caption['source_audio']).name
 assert hashlib.sha256(source.read_bytes()).hexdigest()==caption['source_audio_sha256']
 with wave.open(str(source),'rb') as w:
  import array
  pcm=array.array('h',w.readframes(w.getnframes()))
 began=time.monotonic();text,audit=refine_with_numeric_check(recognizer,[s/32768 for s in pcm],caption['online_text'])
 row={'seq':caption['seq'],'text':text,'numeric_audit':audit,'decode_seconds':time.monotonic()-began,'source_sha256':caption['source_audio_sha256'],'source_wav':str(source),'human_source_transcript_verified':False}
 if audit:
  if caption['seq'] in expected:
   assert audit['literal_text']==expected[caption['seq']],(caption['seq'],audit['literal_text'],expected[caption['seq']])
   row['per_stream_override_matches_independent_itn_false_control']=True
  if audit['issues']:
   with patch('subtitle_bridge.request_json') as request:
    try:translate_recognized_event('http://unused',{'text':text,'asr_numeric_audit':audit})
    except ValueError as e:row['rejection']=str(e)
    else:raise AssertionError('Uncertain numeric reading passed translation gate')
    request.assert_not_called()
   row['rejected_before_translation_and_synthesis']=True
 rows.append(row);(here/'results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
 print(caption['seq'],text,audit and audit['issues'],flush=True)
summary={'complete':True,'all_inference_finished':True,'one_resident_model':True,'source_utterances':len(rows),'numeric_checked':[r['seq'] for r in rows if r['numeric_audit']],'blocked_before_translation':[r['seq'] for r in rows if r.get('rejected_before_translation_and_synthesis')],'elapsed_seconds':time.monotonic()-start,'max_RSS_GiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,'human_source_transcript_verified':False}
(here/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(here/'exit-status.json').write_text(json.dumps({'complete':True,'all_inference_finished':True})+'\n');print(json.dumps(summary),flush=True)
