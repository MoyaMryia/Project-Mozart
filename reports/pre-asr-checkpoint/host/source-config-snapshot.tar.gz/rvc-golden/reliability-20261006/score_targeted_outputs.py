"""Inspect unusually long pieces and prior failed inputs after workload exit."""
import fcntl
import hashlib
import json
from pathlib import Path
import sys

import librosa
import soundfile as sf
import torch
from transformers import WhisperFeatureExtractor, WhisperTokenizerFast, WhisperForConditionalGeneration

base=Path(__file__).resolve().parent
here=base/sys.argv[1]
assert (here/'exit-status.json').exists()
lock=(base/'active-test.lock').open('a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
jobs=json.loads((here/'jobs.json').read_text())
pieces=sorted([(p['duration_seconds'],p) for j in jobs for p in j['chunks']],key=lambda x:x[0],reverse=True)[:3]
targets=[{'case':'long-piece-'+str(i),'text':p['text'],'path':'archive-chunks/'+p['filename']} for i,(_,p) in enumerate(pieces)]
missing=[]
captions=[json.loads(line) for line in (here/'runtime/subtitles.jsonl').read_text().splitlines() if line]
byseq={str(c['seq']):c for c in captions}
for seq in ('1','2','13','15','16','17','19','23','86','101','124','156','195','242','293','336','394','396'):
    if seq not in byseq:continue
    j=next((j for j in jobs if j['utterance_id'].rsplit(':',1)[-1]==seq),None)
    if j is None or j['status']!='completed':
        missing.append({'seq':seq,'status':j['status'] if j else 'not-admitted','translation_error':byseq[seq].get('translation_error'),'speech_error':byseq[seq].get('speech_error')})
        continue
    if j['duration_seconds']<=29:
        targets.append({'case':'known-case-'+seq,'text':j['text'],'path':'archive/'+j['id']+'.wav'})
    else:
        for part in j['chunks']:
            targets.append({'case':'known-case-'+seq+'-part-'+str(part['index']),'text':part['text'],'path':'archive-chunks/'+part['filename']})
(here/'targeted-missing-cases.json').write_text(json.dumps(missing)+'\n')
torch.set_num_threads(2)
snapshot=next(Path('/home/moyamryia/mozart-archive/seedVC/checkpoints/hf_cache/models--openai--whisper-small/snapshots').iterdir())
feature=WhisperFeatureExtractor.from_pretrained(snapshot,local_files_only=True)
tokenizer=WhisperTokenizerFast.from_pretrained('/home/moyamryia/Mozart/rvc-golden/clone-tts/test-20261004/mozart-whisper-tokenizer',local_files_only=True)
model=WhisperForConditionalGeneration.from_pretrained(snapshot,local_files_only=True,torch_dtype=torch.float16).to('cuda').eval()
results=[]
for target in targets:
    path=here/target['path'];pcm,rate=sf.read(path,dtype='float32')
    seconds=len(pcm)/rate;assert seconds<=29
    pcm=librosa.resample(pcm,orig_sr=rate,target_sr=16000)
    encoded=feature(pcm,sampling_rate=16000,return_tensors='pt',return_attention_mask=True)
    with torch.inference_mode():
        ids=model.generate(encoded.input_features.to('cuda',dtype=model.dtype),attention_mask=encoded.attention_mask.to('cuda'),max_new_tokens=256,do_sample=False,forced_decoder_ids=tokenizer.get_decoder_prompt_ids(language='en',task='transcribe'))
    results.append({**target,'transcribed':tokenizer.batch_decode(ids,skip_special_tokens=True)[0],
        'duration_seconds':seconds,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'human_voice_similarity_verified':False})
    print(json.dumps(results[-1]),flush=True)
    (here/'targeted-intelligibility.json').write_text(json.dumps(results,indent=2)+'\n')
