"""Verify collected control hashes and exact input PCM assembly; no inference."""
from pathlib import Path
import array,hashlib,json,struct,wave
b=Path(__file__).resolve().parent

def pcm(path,expected=None):
 if expected:assert hashlib.sha256(path.read_bytes()).hexdigest()==expected,path
 with wave.open(str(path),'rb') as w:
  assert (w.getnchannels(),w.getsampwidth(),w.getframerate())==(1,2,16000)
  return w.readframes(w.getnframes())
captions=[json.loads(x) for x in (b/'short-v3/runtime/subtitles.jsonl').read_text().splitlines() if x]
reference=b''.join(pcm(b/'short-v3/runtime/utterances'/Path(c['source_audio']).name,c['source_audio_sha256']) for c in captions)
assert len(reference)==120*16000*2
boundary=json.loads((b/'asr-boundary-v1/results.json').read_text())
for label in ('received','aligned'):
 cursor=0;parts=[]
 for row in boundary:
  r=row[label];assert r['start_sample']==cursor
  data=pcm(b/'asr-boundary-v1'/r['wav'],r['sha256']);assert len(data)//2==r['end_sample']-cursor
  parts.append(data);cursor=r['end_sample']
 assert b''.join(parts)==reference,label
endpoint=json.loads((b/'asr-endpoint-v2/results.json').read_text())
for mode,obj in endpoint.items():
 cursor=0;parts=[]
 for r in obj['captions']:
  assert r['begin_frame']==cursor;cursor=r['end_frame']
  data=pcm(b/'asr-endpoint-v2'/r['wav'],r['sha256']);assert len(data)//2==(r['end_frame']-r['begin_frame'])*320;parts.append(data)
 assert cursor==6000 and b''.join(parts)==reference,mode
packets=(b/'asr-endpoint-v2/contract-frames.bin').read_bytes();assert len(packets)==6000*1300
assert hashlib.sha256(packets).hexdigest()=='9981153bcafa15cab1e07b10fe81b103d729e15cc4fa05338a749c4079308af9'
quantized=array.array('h')
for index in range(6000):
 p=packets[index*1300:(index+1)*1300];magic,pts,frame,*flags=struct.unpack('<IQIBBBB',p[:20]);assert magic==0x4d5a5254 and frame==index+1
 quantized.extend(max(-32768,min(32767,round(v*32768))) for v in struct.unpack('<320f',p[20:]))
assert quantized.tobytes()==reference
for r in json.loads((b/'asr-itn-v1/results.json').read_text()):
 path=b/'asr-endpoint-v2'/Path(r['source_wav']).name;pcm(path,r['source_sha256'])
for r in json.loads((b/'asr-numeric-v1/results.json').read_text()):
 pcm(b/'short-v3/runtime/utterances'/Path(r['source_wav']).name,r['source_sha256'])
 assert not r['human_source_transcript_verified']
receipt={'all_control_manifest_hashes_previously_verified':True,'boundary_received_and_aligned_PCM_exact':True,'endpoint_ungated_and_gated_PCM_exact':True,'all_contract_frames_and_quantized_PCM_exact':True,'input_seconds':120,'input_frames':6000,'all_ITN_and_numeric_source_hashes_verified':True,'human_transcript_verified':False}
(b/'asr-controls-collection-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
for name in ('short-v3','short-v4'):
 a=b/name;protocol=json.loads((a/'protocol.json').read_text())
 for relative,expected in protocol['source_sha256'].items():assert hashlib.sha256((a/'source-final'/relative).read_bytes()).hexdigest()==expected,relative
 print(name,'source-final matches',len(protocol['source_sha256']),'protocol hashes')
