"""Bounded, actual-worker burst demonstrating text admission and paced playback."""
import base64,fcntl,json,pathlib,sys,time,hashlib
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'tools'));from speech_service import SpeechService
name=sys.argv[1] if len(sys.argv)>1 else 'queue-controls-v1'
assert '/' not in name
HERE=BASE/name;HERE.mkdir(exist_ok=False)
lock=(BASE/'active-test.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
command=[str(ROOT/'.venv/bin/python'),str(ROOT/'tools/clone_worker.py'),'--engine','pocket','--model','/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-pocket-tts-int8-2026-01-26','--threads','2']
s=SpeechService(HERE,command,playback_device='null');samples=[];jobs=[]
try:
 ref=next((ROOT/'rvc-golden/chunked-speech-20261006/long-v5/speech/voices').glob('*.wav'))
 voice=s.add_voice({'name':'Qiqi queue controls','audio_base64':base64.b64encode(ref.read_bytes()).decode()})
 texts=['Although there is part-time work, it is mainly for self-improvement, and the salary is very low.',
        'After winning 25,000, I am afraid to tell them it is gambling.',
        'Although there is part-time work, it is mainly for self-improvement, and the salary is very low.',
        'After winning 25,000, I am afraid to tell them it is gambling.',
        'Although there is part-time work, it is mainly for self-improvement, and the salary is very low.']
 # Lock only submission of this artificial burst, allowing worker and player to
 # run normally once all five source events have arrived.
 with s.lock:
  for text in texts:jobs.append(s.submit({'text':text,'voice_id':voice['id'],'live':True,'playback':True}))
 start=time.monotonic()
 while time.monotonic()-start<120:
  state=s.status();samples.append({'time':time.time(),'buffered':state['buffered_audio_seconds'],'backlog':state['audio_backlog_seconds'],'deferred':state['deferred_jobs']})
  if all(j['status'] in ['completed','expired','failed','cancelled'] for j in s.jobs.values()):break
  time.sleep(.1)
 else:raise RuntimeError('queue control watchdog')
 results=[s.jobs[j['id']] for j in jobs]
 report={'jobs':results,'samples':samples,'maximum_actual_buffer':max(t['buffered'] for t in samples),'limits':{'estimated_audio':24,'actual_audio':12,'deferred_text':4,'deadline':30},'output':'ALSA null paced to actual generated duration','hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (HERE/'results').glob('*.wav')}}
 (HERE/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'states':[j['status'] for j in results],'deferred':[j['was_deferred'] for j in results],'admission_waits':[j['admission_wait_seconds'] for j in results],'max_buffer':report['maximum_actual_buffer']}),flush=True)
 assert all(j['status']=='completed' for j in results),[j.get('error',j['status']) for j in results]
 assert report['maximum_actual_buffer']<=12.05
 assert any(j['was_deferred'] for j in results)
finally:s.close();(HERE/'exit-status.json').write_text(json.dumps({'service_stopped':True})+'\n')
