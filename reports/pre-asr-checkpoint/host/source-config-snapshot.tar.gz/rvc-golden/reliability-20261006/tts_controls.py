"""Run corrected translations through the real clone service after translator exit."""
import base64,fcntl,json,pathlib,sys,time,shutil,hashlib
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'tools'));from speech_service import SpeechService
INPUT=sys.argv[1] if len(sys.argv)>1 else 'translation-2b-v3'
HERE=BASE/(sys.argv[2] if len(sys.argv)>2 else 'tts-controls-v1');HERE.mkdir(exist_ok=False)
lock=(BASE/'active-test.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert json.loads((BASE/INPUT/'exit-status.json').read_text())['server_stopped']
command=[str(ROOT/'.venv/bin/python'),str(ROOT/'tools/clone_worker.py'),'--engine','pocket','--model','/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-pocket-tts-int8-2026-01-26','--threads','2']
s=SpeechService(HERE,command,playback_device='null');results=[]
try:
 ref=next((ROOT/'rvc-golden/chunked-speech-20261006/long-v5/speech/voices').glob('*.wav'))
 voice=s.add_voice({'name':'Qiqi reliability controls','audio_base64':base64.b64encode(ref.read_bytes()).decode()})
 for row in json.loads((BASE/INPUT/'results.json').read_text()):
  if row['seq'] not in [156,195,242,336,394,396] or row.get('error'):continue
  j=s.submit({'text':row['translation'],'voice_id':voice['id'],'source_text':row['source'],'live':True,'playback':False})
  end=time.monotonic()+100
  while time.monotonic()<end:
   j=s.route('GET','/api/speech/jobs/'+j['id'],{})
   if j['status'] in ['completed','failed','expired']:break
   time.sleep(.1)
  assert j['status']=='completed',j
  path=HERE/(str(row['seq'])+'.wav');shutil.copy2(HERE/'results'/(j['id']+'.wav'),path)
  results.append({'seq':row['seq'],'text':row['translation'],'job':j,'wav':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()});(HERE/'control-results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'seq':row['seq'],'duration':j['duration_seconds'],'chunks':j['chunk_count']}),flush=True)
finally:s.close();(HERE/'exit-status.json').write_text(json.dumps({'service_stopped':True})+'\n')
