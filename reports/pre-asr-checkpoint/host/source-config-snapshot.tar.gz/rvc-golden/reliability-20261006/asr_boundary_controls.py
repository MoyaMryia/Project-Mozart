"""Compare received-audio cuts with decoded-frame cuts on exact retained PCM."""
from pathlib import Path
import argparse,array,fcntl,hashlib,json,sys,time,wave
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from stt_service import build_recognizer
import sherpa_onnx
source=BASE/sys.argv[1];here=BASE/sys.argv[2];here.mkdir(exist_ok=False)
lock=(BASE/'active-test.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert (source/'exit-status.json').exists()
captions=[json.loads(l) for l in (source/'runtime/subtitles.jsonl').read_text().splitlines() if l]
all_pcm=array.array('h');source_hashes=[]
for c in captions:
 path=source/'runtime/utterances'/Path(c['source_audio']).name
 assert hashlib.sha256(path.read_bytes()).hexdigest()==c['source_audio_sha256']
 with wave.open(str(path)) as f:
  assert (f.getnchannels(),f.getsampwidth(),f.getframerate())==(1,2,16000)
  values=array.array('h',f.readframes(f.getnframes()))
  if sys.byteorder!='little':values.byteswap()
  all_pcm.extend(values)
 source_hashes.append(c['source_audio_sha256'])
assert len(all_pcm)==120*16000
args=argparse.Namespace(model='/home/moyamryia/models/sherpa-onnx/zipformer-zh-14M',threads=2)
recognizer=build_recognizer(args);stream=recognizer.create_stream();endpoints=[]
started=time.monotonic()
for offset in range(0,len(all_pcm),320):
 stream.accept_waveform(16000,[v/32768 for v in all_pcm[offset:offset+320]])
 while recognizer.is_ready(stream):recognizer.decode_stream(stream)
 if recognizer.is_endpoint(stream):
  text=recognizer.get_result(stream)
  token_times=recognizer.timestamps(stream)
  recognizer.reset(stream)
  endpoint=round(recognizer.start_time(stream)*16000)
  endpoints.append({'online_text':text,'timestamps':token_times,'received_end_samples':offset+320,'decoded_end_samples':endpoint,'lag_seconds':(offset+320-endpoint)/16000})
stream.accept_waveform(16000,[0.0]*4800);stream.input_finished()
while recognizer.is_ready(stream):recognizer.decode_stream(stream)
endpoints.append({'online_text':recognizer.get_result(stream),'received_end_samples':len(all_pcm),'decoded_end_samples':len(all_pcm),'lag_seconds':0,'final_flush':True})
final=sherpa_onnx.OfflineRecognizer.from_sense_voice(model='/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17/model.int8.onnx',tokens='/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17/tokens.txt',num_threads=2,language='zh',use_itn=True)
results=[];previous_received=previous_decoded=0
try:
 for seq,point in enumerate(endpoints,1):
  row={'seq':seq,**point}
  for label,start,end in [('received',previous_received,point['received_end_samples']),('aligned',previous_decoded,point['decoded_end_samples'])]:
   assert 0<=start<end<=len(all_pcm),(label,start,end)
   pcm=all_pcm[start:end];ss=final.create_stream();ss.accept_waveform(16000,[v/32768 for v in pcm]);final.decode_stream(ss)
   path=here/f'{seq:04d}-{label}.wav'
   if sys.byteorder!='little':pcm.byteswap()
   with wave.open(str(path),'wb') as writer:
    writer.setnchannels(1);writer.setsampwidth(2);writer.setframerate(16000);writer.writeframes(pcm.tobytes())
   row[label]={'start_sample':start,'end_sample':end,'seconds':(end-start)/16000,'text':ss.result.text,'wav':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
  row['recorded_source_text']=captions[seq-1]['zh'] if seq<=len(captions) else None
  previous_received=point['received_end_samples'];previous_decoded=point['decoded_end_samples'];results.append(row)
  (here/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(json.dumps(row,ensure_ascii=False),flush=True)
 assert previous_received==previous_decoded==len(all_pcm)
 (here/'summary.json').write_text(json.dumps({'received_and_aligned_preserve_every_input_sample':True,'input_seconds':len(all_pcm)/16000,'input_PCM_sha256':hashlib.sha256(all_pcm.tobytes()).hexdigest(),'source_wav_hashes':source_hashes,'endpoints':len(endpoints),'elapsed_seconds':time.monotonic()-started,'human_source_transcript_verified':False,'clock_reference':'Installed1.13.6 recognizer.start_time after reset, decoded cumulative feature-frame clock'},indent=2)+'\n')
finally:
 (here/'exit-status.json').write_text(json.dumps({'process_finished':True,'complete':(here/'summary.json').exists()})+'\n')
