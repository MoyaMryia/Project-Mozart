"""Score exact repaired failure inputs using the same cached Whisper model."""
import fcntl
import json
from pathlib import Path
import librosa
import soundfile as sf
import torch
from transformers import WhisperFeatureExtractor, WhisperTokenizerFast, WhisperForConditionalGeneration

base=Path(__file__).resolve().parent
lock=(base/'active-test.lock').open('a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
import sys
here=base/sys.argv[1]
assert (here/'exit-status.json').exists(),'Workload must have exited'
cases=[json.loads(l) for l in (here/'runtime/subtitles.jsonl').read_text().splitlines() if l]
cases=[{'seq':c['seq'],'text':c['zh'],'wav':'runtime/utterances/'+Path(c['source_audio']).name,'job':{'duration_seconds':c['source_audio_seconds']}} for c in cases if c['seq'] in [1,16,156,195,297,336,394,396] and c.get('source_audio')]

torch.set_num_threads(2)
snapshot=next(Path('/home/moyamryia/mozart-archive/seedVC/checkpoints/hf_cache/models--openai--whisper-small/snapshots').iterdir())
feature=WhisperFeatureExtractor.from_pretrained(snapshot,local_files_only=True)
tokenizer=WhisperTokenizerFast.from_pretrained('/home/moyamryia/Mozart/rvc-golden/clone-tts/test-20261004/mozart-whisper-tokenizer',local_files_only=True)
model=WhisperForConditionalGeneration.from_pretrained(snapshot,local_files_only=True,torch_dtype=torch.float16).to('cuda').eval()
results=[]
for case in cases:
    pcm,rate=sf.read(here/case['wav'],dtype='float32')
    pcm=librosa.resample(pcm,orig_sr=rate,target_sr=16000)
    encoded=feature(pcm,sampling_rate=16000,return_tensors='pt',return_attention_mask=True)
    with torch.inference_mode():
        ids=model.generate(encoded.input_features.to('cuda',dtype=model.dtype),attention_mask=encoded.attention_mask.to('cuda'),max_new_tokens=128,do_sample=False,forced_decoder_ids=tokenizer.get_decoder_prompt_ids(language='zh',task='transcribe'))
    results.append({'seq':case['seq'],'sensevoice_text':case['text'], 'transcribed':tokenizer.batch_decode(ids,skip_special_tokens=True)[0],'duration_seconds':case['job']['duration_seconds'],'human_source_transcript_verified':False})
    print(json.dumps(results[-1]),flush=True)
    (here/'source-recognition-controls.json').write_text(json.dumps(results,indent=2)+'\n')
