"""Detect conflicting explicit amounts without choosing a source transcript.

SenseVoice's ITN switch is a model input, not merely display formatting. Check
the same audio twice only for utterances containing explicit amounts/years.
The second stream reuses the loaded recognizer; it loads no additional model.
Agreement does not establish that either reading matches the speaker.
"""
import re
from translation_checks import required_number_counts


def significant_quantities(text):
    return {value: count for value, count in required_number_counts(text).items()
            if float(value) >= 100}


def numeric_audit(formatted, literal):
    """Return evidence and reasons; never rewrite either recognized text."""
    issues = []
    # 一一万 may be a stutter or a digit sequence. Repeated unit constructions
    # such as 千五千/七千五千 may be clipped speech or adjacent amounts. The
    # existing translation quantity parser must not resolve these ambiguities.
    spans = re.findall(r'[零〇一二两三四五六七八九十百千万亿]+', literal)
    ambiguous = [span for span in spans if
                 re.search(r'([零〇一二两三四五六七八九])\1[百千万亿]', span)
                 or any(span.count(unit) > 1 for unit in '十百千万亿')]
    if ambiguous:
        issues.append('ambiguous_literal_quantity')
    formatted_counts = significant_quantities(formatted)
    literal_counts = significant_quantities(literal)
    if formatted_counts != literal_counts:
        issues.append('itn_quantity_disagreement')
    return {'formatted_text': formatted, 'literal_text': literal,
            'formatted_quantities': formatted_counts,
            'literal_quantities': literal_counts,
            'ambiguous_literal_spans': ambiguous, 'issues': issues,
            'same_audio': True, 'human_source_transcript_verified': False}


def refine_with_numeric_check(recognizer, pcm, online_text=''):
    stream = recognizer.create_stream()
    stream.set_option('use_itn', '1')
    stream.accept_waveform(16000, pcm)
    recognizer.decode_stream(stream)
    text = stream.result.text.strip()
    if not significant_quantities(text) and not significant_quantities(online_text):
        return text, None
    try:
        literal_stream = recognizer.create_stream()
        literal_stream.set_option('use_itn', '0')
        literal_stream.accept_waveform(16000, pcm)
        recognizer.decode_stream(literal_stream)
        literal = literal_stream.result.text.strip()
        if not literal:
            raise RuntimeError('Literal numeric check returned no text')
        audit = numeric_audit(text, literal)
    except Exception as error:
        audit = {'formatted_text': text, 'literal_text': '',
                 'issues': ['numeric_check_failed'], 'error': str(error),
                 'same_audio': True, 'human_source_transcript_verified': False}
    return text, audit
