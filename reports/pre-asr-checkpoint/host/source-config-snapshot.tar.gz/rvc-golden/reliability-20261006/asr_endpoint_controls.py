"""Capture exact contract frames, then compare ungated/acoustic-gated endpoints."""
from pathlib import Path
import argparse,array,fcntl,hashlib,json,socket,struct,subprocess,sys,time,wave
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];HERE=BASE/sys.argv[1];HERE.mkdir(exist_ok=False)
lock=(BASE/'active-test.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sys.path.insert(0,str(ROOT/'tools'));from stt_service import build_recognizer
import sherpa_onnx
HEADER=struct.Struct('<IQIBBBB');SIZE=1300
wav=HERE/'microphone.wav'
subprocess.run(['ffmpeg','-v','error','-y','-ss','720','-i','/tmp/test-audio.mp4','-t','120','-ar','48000','-ac','2','-c:a','pcm_s16le',str(wav)],check=True,timeout=120)
with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
 sock.setsockopt(socket.SOL_SOCKET,socket.SO_RCVBUF,1<<22);sock.bind(('127.0.0.1',18130));sock.settimeout(.2)
 with (HERE/'preprocessor.log').open('w') as log:
  p=subprocess.Popen([str(ROOT/'build-gpu/preprocessor/mozart-pre'),'-i',str(wav),'-n','6000','-a','127.0.0.1','-p','18130'],stdout=log,stderr=subprocess.STDOUT)
  packets=[];limit=time.monotonic()+120
  try:
   while len(packets)<6000 and time.monotonic()<limit:
    try:packet,_=sock.recvfrom(65536)
    except socket.timeout:
     if p.poll() is not None:break
     continue
    assert len(packet)==SIZE
    magic,pts,idx,*flags=HEADER.unpack(packet[:20]);assert magic==0x4D5A5254 and idx==len(packets)+1
    packets.append(packet)
   assert len(packets)==6000,len(packets);assert p.wait(timeout=15)==0
  finally:
   if p.poll() is None:p.terminate();p.wait(timeout=5)
(HERE/'contract-frames.bin').write_bytes(b''.join(packets))
original=BASE/'short-v3';old=array.array('h')
for path in sorted((original/'runtime/utterances').glob('*.wav')):
 with wave.open(str(path)) as f:old.extend(array.array('h',f.readframes(f.getnframes())))
quantized=array.array('h');frames=[]
for packet in packets:
 meta=HEADER.unpack(packet[:20]);pcm=struct.unpack('<320f',packet[20:]);frames.append((meta,pcm));quantized.extend(max(-32768,min(32767,round(v*32768))) for v in pcm)
assert old==quantized,'Contract recapture differs from actual run input'
args=argparse.Namespace(model='/home/moyamryia/models/sherpa-onnx/zipformer-zh-14M',threads=2)
final=sherpa_onnx.OfflineRecognizer.from_sense_voice(model='/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17/model.int8.onnx',tokens='/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17/tokens.txt',num_threads=2,language='zh',use_itn=True)
all_results={}
for mode in ['ungated','gated']:
 rec=build_recognizer(args);stream=rec.create_stream();pending=[];rows=[];begin=0;blocked=[]
 def emit(end,reason,meta):
  global pending,begin
  online=rec.get_result(stream);ss=final.create_stream();ss.accept_waveform(16000,pending);final.decode_stream(ss)
  path=HERE/f'{mode}-{len(rows)+1:04d}.wav';pcm=array.array('h',(max(-32768,min(32767,round(v*32768))) for v in pending))
  with wave.open(str(path),'wb') as out:out.setnchannels(1);out.setsampwidth(2);out.setframerate(16000);out.writeframes(pcm.tobytes())
  row={'seq':len(rows)+1,'begin_frame':begin,'end_frame':end,'seconds':(end-begin)*.02,'online_text':online,'text':ss.result.text,'reason':reason,'vad':meta[3],'conf':meta[5],'wav':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()};rows.append(row);print(json.dumps({'mode':mode,**row},ensure_ascii=False),flush=True);pending=[];begin=end
 for number,(meta,pcm) in enumerate(frames,1):
  pending.extend(pcm);stream.accept_waveform(16000,list(pcm))
  while rec.is_ready(stream):rec.decode_stream(stream)
  if rec.is_endpoint(stream):
   duration=(number-begin)*.02
   if mode=='gated' and meta[3] and duration<12:
    blocked.append({'frame':number,'duration':duration,'vad':meta[3],'conf':meta[5]});continue
   emit(number,'max_length' if duration>=12 else 'endpoint',meta);rec.reset(stream)
 if pending:
  stream.accept_waveform(16000,[0.0]*4800);stream.input_finished()
  while rec.is_ready(stream):rec.decode_stream(stream)
  emit(6000,'final_flush',frames[-1][0])
 assert sum(r['end_frame']-r['begin_frame'] for r in rows)==6000
 all_results[mode]={'captions':rows,'blocked_active_speech_endpoints':blocked,'frame_count':6000,'max_span_seconds':max(r['seconds'] for r in rows)}
 (HERE/'results.json').write_text(json.dumps(all_results,ensure_ascii=False,indent=2)+'\n')
(HERE/'summary.json').write_text(json.dumps({'contract_frames':6000,'all_quantized_input_matches_short_v3':True,'contract_sha256':hashlib.sha256((HERE/'contract-frames.bin').read_bytes()).hexdigest(),'ungated_captions':len(all_results['ungated']['captions']),'gated_captions':len(all_results['gated']['captions']),'blocked':len(all_results['gated']['blocked_active_speech_endpoints']),'original_words_not_manually_corrected':True,'human_transcript_verified':False},indent=2)+'\n')
(HERE/'exit-status.json').write_text(json.dumps({'complete':True,'preprocessor_stopped':p.poll() is not None})+'\n')
