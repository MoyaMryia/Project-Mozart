"""Compare small time-unit readings on exact retained source audio, no rewrite."""
from pathlib import Path
import array,hashlib,json,sys,wave
import sherpa_onnx
base=Path(__file__).resolve().parent;here=base/sys.argv[1];here.mkdir(exist_ok=False)
model=Path('/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17')
r=sherpa_onnx.OfflineRecognizer.from_sense_voice(model=str(model/'model.int8.onnx'),tokens=str(model/'tokens.txt'),num_threads=2,language='zh',use_itn=True)
rows=[]
for seq in (13,14):
 path=base/'short-v4/runtime/utterances'/f'{seq:04d}.wav'
 with wave.open(str(path),'rb') as w:pcm=array.array('h',w.readframes(w.getnframes()))
 row={'seq':seq,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'human_source_transcript_verified':False}
 for mode in ('1','0'):
  s=r.create_stream();s.set_option('use_itn',mode);s.accept_waveform(16000,[x/32768 for x in pcm]);r.decode_stream(s)
  row['formatted' if mode=='1' else 'literal']=s.result.text
 rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
(here/'results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');(here/'exit-status.json').write_text(json.dumps({'complete':True,'all_inference_finished':True})+'\n')
