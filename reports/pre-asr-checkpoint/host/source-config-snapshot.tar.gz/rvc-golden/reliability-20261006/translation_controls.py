"""Bounded actual-translator controls before TTS/workload inference."""
import fcntl,json,os,pathlib,subprocess,sys,time,urllib.request
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from subtitle_bridge import translate
def streamed_hash(path):
 h=__import__('hashlib').sha256()
 with path.open('rb') as f:
  for data in iter(lambda:f.read(1024*1024),b''):h.update(data)
 return h.hexdigest()

HERE=BASE/(sys.argv[1] if len(sys.argv)>1 else 'translation-v2');HERE.mkdir(exist_ok=False)
from run_translated_speech import assert_ports_available
import socket
lock=(BASE/'active-test.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert_ports_available([(18220,socket.SOCK_STREAM)])
home=pathlib.Path.home();binary=home/'mozart-archive/qwen35/llama.cpp/build-cuda-bin/llama-server'
model=pathlib.Path(os.environ.get('MOZART_CONTROL_MODEL',str(home/'mozart-archive/qwen35/gguf/qwen35-0.8b-text-Q4_K_M.gguf')))
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(binary.parent)+':'+env.get('LD_LIBRARY_PATH','')
if os.environ.get('MOZART_DISABLE_GRAPHS')=='1':env['GGML_CUDA_DISABLE_GRAPHS']='1'
command=[str(binary),'-m',str(model),'-c','2048','-ngl','99','-np','1','-t','2','-tb','2','--host','127.0.0.1','--port','18220','--jinja']
if os.environ.get('MOZART_NO_MMAP')=='1':command+=['--no-mmap']
if os.environ.get('MOZART_BOUNDED_RUNTIME')=='1':command+=['-b','256','-ub','128','--cache-ram','128']
if os.environ.get('MOZART_CONTROL_UBATCH'):command+=['-ub',os.environ['MOZART_CONTROL_UBATCH']]
with (HERE/'server.log').open('w') as log:
 p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 import threading
 readings=[];monitor_stop=threading.Event()
 def monitor():
  while not monitor_stop.is_set():
   try:
    memory={line.split(':')[0]:int(line.split()[1])*1024 for line in pathlib.Path('/proc/meminfo').read_text().splitlines()}
    status={line.split(':')[0]:line.split(':')[1].strip() for line in pathlib.Path('/proc/'+str(p.pid)+'/status').read_text().splitlines() if ':' in line}
    readings.append({'time':time.time(),'available_bytes':memory['MemAvailable'],'translator_RSS_bytes':int(status['VmRSS'].split()[0])*1024})
   except (OSError,KeyError):pass
   monitor_stop.wait(.2)
 watcher=threading.Thread(target=monitor,daemon=True);watcher.start()

 try:
  deadline=time.monotonic()+90
  while time.monotonic()<deadline:
   assert p.poll() is None,'translator exited'
   try:
    with urllib.request.urlopen('http://127.0.0.1:18220/health',timeout=1) as r:
     if r.status==200:break
   except OSError:time.sleep(.2)
  else:raise RuntimeError('translator readiness timeout')
  (HERE/'protocol.json').write_text(json.dumps({'command':command,'disable_cuda_graphs':env.get('GGML_CUDA_DISABLE_GRAPHS')=='1','model':str(model),'model_sha256':streamed_hash(model),'bridge_sha256':__import__('hashlib').sha256((ROOT/'tools/subtitle_bridge.py').read_bytes()).hexdigest()},indent=2)+'\n')
  results=[]
  for old in json.loads((BASE/os.environ.get('MOZART_CONTROL_CASES','translation-cases.json')).read_text()):
   row={'seq':old['seq'],'source':old['zh'],'baseline_translation':old['en'],'baseline_error':old.get('translation_error')}
   row['audit']=[]
   try:row['translation'],row['seconds']=translate('http://127.0.0.1:18220',old['zh'],audit=row['audit']);row['error']=None
   except Exception as e:row['error']=str(e)
   results.append(row);print(json.dumps(row,ensure_ascii=False),flush=True);(HERE/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
 finally:
  p.terminate()
  try:p.wait(timeout=15)
  except subprocess.TimeoutExpired:p.kill();p.wait()
  monitor_stop.set();watcher.join(timeout=1)
  (HERE/'memory-samples.json').write_text(json.dumps(readings)+'\n')
  (HERE/'exit-status.json').write_text(json.dumps({'server_stopped':p.poll() is not None,'returncode':p.returncode})+'\n')
