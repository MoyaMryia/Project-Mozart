"""Bounded actual-translator controls before TTS/workload inference."""
import fcntl,json,os,pathlib,subprocess,sys,time,urllib.request
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from subtitle_bridge import request_json
from translation_checks import required_numbers, missing_numbers, repeated_numbers
HERE=BASE/(sys.argv[1] if len(sys.argv)>1 else 'translation-probe-q8');HERE.mkdir(exist_ok=False)
from run_translated_speech import assert_ports_available
import socket
lock=(BASE/'active-test.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert_ports_available([(18220,socket.SOCK_STREAM)])
home=pathlib.Path.home();binary=home/'mozart-archive/qwen35/llama.cpp/build-cuda-bin/llama-server'
model=home/'mozart-archive/qwen35/gguf/qwen35-0.8b-text-Q8_0.gguf'
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(binary.parent)+':'+env.get('LD_LIBRARY_PATH','')
command=[str(binary),'-m',str(model),'-c','2048','-ngl','99','-np','1','-t','2','-tb','2','--host','127.0.0.1','--port','18220','--jinja']
with (HERE/'server.log').open('w') as log:
 p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 try:
  deadline=time.monotonic()+90
  while time.monotonic()<deadline:
   assert p.poll() is None,'translator exited'
   try:
    with urllib.request.urlopen('http://127.0.0.1:18220/health',timeout=1) as r:
     if r.status==200:break
   except OSError:time.sleep(.2)
  else:raise RuntimeError('translator readiness timeout')
  results=[]
  for old in json.loads((BASE/'translation-cases.json').read_text()):
   row={'seq':old['seq'],'source':old['zh'],'baseline_translation':old['en'],'baseline_error':old.get('translation_error')}
   row['audit']=[]
   try:
    start=time.monotonic()
    prompt='将下面的口语中文忠实翻译成英文，只输出英文译文。不要编造或重复原文没有的事实。保留否定、不确定性、品牌型号和数字。大数使用阿拉伯数字。二本院校是second-tier college。'
    constraints=required_numbers(old['zh'])
    if constraints:prompt+='数字必须保留：'+', '.join(constraints)+'。'
    if '跑分' in old['zh'] and '账户' in old['zh'] and '网赌' in old['zh']:prompt+='这里跑分指为网络赌博平台提供账户的活动，译为account provision，不是人名，不要注音。'
    for attempt in range(2):
     instruction=prompt if attempt==0 else prompt+'逐句翻译，禁止重复金额，不要解释。'
     r=request_json('http://127.0.0.1:18220/v1/chat/completions',{'messages':[{'role':'system','content':instruction+' /no_think'},{'role':'user','content':old['zh']}],'chat_template_kwargs':{'enable_thinking':False},'max_tokens':300,'temperature':0},10)
     c=r['choices'][0];text=c['message']['content'].strip();missing=missing_numbers(old['zh'],text);repeated=repeated_numbers(old['zh'],text)
     row['audit'].append({'attempt':attempt+1,'content':text,'missing':missing,'repeated':repeated,'finish_reason':c.get('finish_reason')})
     if not missing and not repeated and c.get('finish_reason')=='stop':break
    row['translation']=text;row['seconds']=time.monotonic()-start;row['error']=None if not missing and not repeated and c.get('finish_reason')=='stop' else str({'missing':missing,'repeated':repeated,'finish':c.get('finish_reason')})

   except Exception as e:row['error']=str(e)
   results.append(row);print(json.dumps(row,ensure_ascii=False),flush=True);(HERE/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
 finally:
  p.terminate()
  try:p.wait(timeout=15)
  except subprocess.TimeoutExpired:p.kill();p.wait()
  (HERE/'exit-status.json').write_text(json.dumps({'server_stopped':p.poll() is not None,'returncode':p.returncode})+'\n')
