"""Conservative checks for explicit digits, spoken years and large quantities.

This is not a semantic translation evaluator. It catches dropped/mutated numbers
that the small translator has actually produced in the project's replay tests.
"""
import re

DIGITS = {c: i for i, c in enumerate('零一二三四五六七八九')}
DIGITS.update({'〇': 0, '两': 2})
UNITS = {'十': 10, '百': 100, '千': 1000}


def integer(text):
    if text.isdecimal():
        return int(text)
    total = current = 0
    for character in text:
        if character in DIGITS:
            current = DIGITS[character]
        elif character in UNITS:
            total += (current or 1)*UNITS[character]
            current = 0
    return total+current


def required_numbers(text):
    numbers = set()
    for digits, unit in re.findall(r'(\d+(?:\.\d+)?)([万亿]?)', text.replace(',', '')):
        if unit:
            value = float(digits)*(10000 if unit == '万' else 100000000)
            numbers.add(str(int(value)) if value.is_integer() else str(value))
        else:
            numbers.add(digits)
    # Read a year digit by digit, e.g. 一九八七年.
    for year in re.findall(r'([零〇一二三四五六七八九]{4})年', text):
        numbers.add(''.join(str(DIGITS[c]) for c in year))
    for amount, unit in re.findall(r'([零〇一二两三四五六七八九十百千]+)(万|亿)', text):
        scale = 10000 if unit == '万' else 100000000
        if len(amount) == 2 and all(c in DIGITS for c in amount):
            # Conversational ranges: 七八万 means 70,000–80,000.
            numbers.update(str(DIGITS[c]*scale) for c in amount)
        else:
            numbers.add(str(integer(amount)*scale))
    return sorted(numbers, key=lambda n: float(n))


def missing_numbers(source, translation):
    actual = set(re.findall(r'\d+(?:\.\d+)?', translation.replace(',', '')))
    return [n for n in required_numbers(source) if n not in actual]
