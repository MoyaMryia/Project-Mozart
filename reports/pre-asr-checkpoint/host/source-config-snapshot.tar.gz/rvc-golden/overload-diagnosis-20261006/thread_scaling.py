#!/usr/bin/env python3
"""Bounded standalone TTS thread comparison using saved, identical jobs."""
import hashlib
import json
from pathlib import Path
import selectors
import statistics
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUT = HERE / 'thread-scaling'


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def response(process, seconds=90):
    with selectors.DefaultSelector() as selector:
        selector.register(process.stdout, selectors.EVENT_READ)
        if not selector.select(seconds):
            raise TimeoutError('Worker response exceeded bounded timeout')
    line = process.stdout.readline()
    if not line:
        raise RuntimeError('Worker exited before response')
    result = json.loads(line)
    if 'error' in result:
        raise RuntimeError(result['error'])
    return result


def main():
    import numpy as np
    import soundfile as sf
    if OUT.exists():
        raise RuntimeError('Do not duplicate or overwrite this benchmark')
    OUT.mkdir()
    good = sorted((j for j in json.loads((HERE/'wav-only/jobs.json').read_text())
                   if j['status'] == 'completed'), key=lambda j: j['duration_seconds'])
    chosen = [good[i] for i in (3, 10, 17)]
    reference = HERE/'wav-only/speech/voices'/f"{chosen[0]['voice_id']}.wav"
    save(OUT/'input-jobs.json', chosen)
    results = {}
    try:
        for threads in (2, 1, 4):
            directory = OUT/f'threads-{threads}'
            directory.mkdir()
            command = [sys.executable, str(ROOT/'tools/clone_worker.py'), '--engine', 'pocket',
                       '--model', str(Path.home()/'models/sherpa-onnx/clone-test-downloads/sherpa-onnx-pocket-tts-int8-2026-01-26'),
                       '--threads', str(threads)]
            save(directory/'command.json', command)
            started = time.monotonic()
            with (directory/'stderr.log').open('w') as log:
                process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                           stderr=log, text=True, bufsize=1)
                save(OUT/'progress.json', {'threads':threads, 'pid':process.pid})
                rows = []
                try:
                    ready = response(process)
                    load_seconds = time.monotonic()-started
                    for iteration, job in enumerate([chosen[0]] + chosen*2):
                        output = directory/f'job-{iteration}.wav'
                        began = time.monotonic()
                        process.stdin.write(json.dumps({**job, 'reference':str(reference),
                                                       'output':str(output)})+'\n')
                        process.stdin.flush()
                        result = response(process)
                        wall_seconds = time.monotonic()-began
                        pcm, rate = sf.read(output, dtype='float32')
                        rows.append({**result, 'iteration':iteration, 'warmup':iteration == 0,
                                     'text':job['text'], 'wall_seconds':wall_seconds,
                                     'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
                                     'finite':bool(np.isfinite(pcm).all()),
                                     'clipping_samples':int(np.sum(np.abs(pcm)>=1)),
                                     'rms':float(np.sqrt(np.mean(pcm*pcm))), 'sample_rate':rate})
                        save(directory/'measurements.json', rows)
                        save(OUT/'progress.json', {'threads':threads, 'pid':process.pid,
                                                  'completed_generations':iteration+1})
                finally:
                    if process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=5)
                    process.stdin.close()
                    process.stdout.close()
            measured = [r for r in rows if not r['warmup']]
            results[str(threads)] = {'runtime':ready, 'load_seconds':load_seconds,
                'measured_jobs':len(measured),
                'audio_seconds':sum(r['duration_seconds'] for r in measured),
                'synthesis_seconds':sum(r['synthesis_seconds'] for r in measured),
                'weighted_RTF':sum(r['synthesis_seconds'] for r in measured)/sum(r['duration_seconds'] for r in measured),
                'median_first_callback_seconds':statistics.median(r['first_callback_seconds'] for r in measured),
                'all_finite':all(r['finite'] for r in measured),
                'clipping_samples':sum(r['clipping_samples'] for r in measured)}
            save(OUT/'summary.json', results)
            print(json.dumps({'threads':threads, **results[str(threads)]}), flush=True)
        save(OUT/'exit-status.json', {'exit_code':0, 'test_workers_stopped':True})
    except BaseException as error:
        save(OUT/'exit-status.json', {'exit_code':1, 'error':str(error)})
        raise


if __name__ == '__main__':
    main()
