"""Controlled identical-input playback/WAV-only probes with process telemetry."""
import collections
import json
import os
from pathlib import Path
import re
import signal
import statistics
import subprocess
import sys
import time
import urllib.request

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2))


def sample(previous, elapsed):
    cpu = [int(x) for x in Path('/proc/stat').read_text().splitlines()[0].split()[1:9]]
    total, idle = sum(cpu), cpu[3]+cpu[4]
    mem = {line.split(':')[0]:int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines()}
    vm = {line.split()[0]:int(line.split()[1]) for line in Path('/proc/vmstat').read_text().splitlines()}
    rows = {}
    hz = os.sysconf('SC_CLK_TCK')
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            args = (p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
            kind = next((k for k in ['clone_worker.py','speech_service.py','stt_service.py','subtitle_bridge.py','llama-server','mozart_stated','mozart-pre'] if k in args),None)
            if not kind or args.startswith(('bash ','ssh ','timeout ')):
                continue
            fields = (p/'stat').read_text().rsplit(')',1)[1].split()
            ticks = int(fields[11])+int(fields[12])
            before = previous.get('processes',{}).get(p.name)
            status = (p/'status').read_text()
            rss = int(re.search(r'^VmRSS:\s+(\d+)',status,re.M)[1])*1024
            threads = int(re.search(r'^Threads:\s+(\d+)',status,re.M)[1])
            rows[p.name] = {'kind':kind,'ticks':ticks,'rss_bytes':rss,'threads':threads,
                'one_core_percent':100*(ticks-before['ticks'])/hz/elapsed if before else None}
        except (FileNotFoundError,ProcessLookupError,PermissionError,TypeError):
            continue
    old_total, old_idle = previous.get('total',total),previous.get('idle',idle)
    cpu_pct = 100*(1-(idle-old_idle)/(total-old_total)) if total>old_total else None
    return {'at':time.time(),'total':total,'idle':idle,'cpu_all_cores_percent':cpu_pct,
            'available_bytes':mem['MemAvailable'],'swap_used_bytes':mem['SwapTotal']-mem['SwapFree'],
            'pswpin':vm['pswpin'],'pswpout':vm['pswpout'],'processes':rows}


def main():
    summaries = json.loads((HERE/'summary.json').read_text()) if (HERE/'summary.json').exists() else {}
    if 'same_source_texts' in summaries:
        raise RuntimeError('Do not overwrite completed measurements')
    for mode in ['paced-playback','wav-only']:
        if mode in summaries:
            continue
        out = HERE/mode
        out.mkdir(exist_ok=True)
        command = [sys.executable,str(ROOT/'tools/run_translated_speech.py'),
            '--backend-config',str(ROOT/'state/translated-speech.yaml'),
            '--reference',str(ROOT/'rvc-golden/clone-tts/qiqi-20261004/reference-qiqi-natural-source.wav'),
            '--input','/tmp/test-audio.mp4','--start','720','--seconds','120',
            '--playback-device','null', '--final-model',
            '/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17',
            '--run-dir',str(out/'runtime'),'--data-dir',str(out/'speech')]
        if mode=='wav-only':
            command += ['--no-playback']
        save(out/'command.json',command)
        log = (out/'launcher.log').open('w')
        gpu_log = (out/'tegrastats.log').open('w')
        gpu = subprocess.Popen(['tegrastats','--interval','1000'],stdout=gpu_log,stderr=subprocess.STDOUT)
        process = subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
        previous = {};rows=[];jobs={};start=time.monotonic();last=start
        try:
            with (out/'telemetry.jsonl').open('w') as telemetry:
                while process.poll() is None:
                    now=time.monotonic()
                    if now-start>330:
                        raise RuntimeError('Probe exceeded 330-second watchdog')
                    record=sample(previous,max(.001,now-last));last=now;previous=record
                    try:
                        with urllib.request.urlopen('http://127.0.0.1:18080/api/speech/status',timeout=1) as r:
                            d=json.load(r)
                        jobs.update({j['id']:dict(j) for j in d['jobs']})
                        record['job_states']=dict(collections.Counter(j['status'] for j in d['jobs']))
                    except OSError:
                        pass
                    telemetry.write(json.dumps(record)+'\n');telemetry.flush();rows.append(record)
                    save(HERE/'progress.json',{'phase':mode,'elapsed_seconds':now-start,'job_states':dict(collections.Counter(j['status'] for j in jobs.values())),'cpu_all_cores_percent':record['cpu_all_cores_percent']})
                    time.sleep(1)
        finally:
            if process.poll() is None:
                process.terminate();process.wait(timeout=90)
            gpu.terminate();gpu.wait(timeout=10);log.close();gpu_log.close()
        result=json.loads((out/'runtime/speech-results.json').read_text())
        jobs.update({j['id']:j for j in result['jobs']})
        caps=[json.loads(line) for line in (out/'runtime/subtitles.jsonl').read_text().splitlines() if line]
        active=[r for r in rows if any(j.get('kind')=='clone_worker.py' for j in r['processes'].values())]
        def metric(values):
            return {'median':statistics.median(values),'max':max(values)} if values else None
        proc={}
        for kind in ['clone_worker.py','stt_service.py','llama-server']:
            values=[p for r in active for p in r['processes'].values() if p['kind']==kind]
            proc[kind]={'rss_bytes':metric([p['rss_bytes'] for p in values]),
                'one_core_percent':metric([p['one_core_percent'] for p in values if p['one_core_percent'] is not None])}
        gpu_pct=[int(n) for n in re.findall(r'GR3D_FREQ\s+(\d+)%',(out/'tegrastats.log').read_text())]
        temps=[float(n) for n in re.findall(r'cpu@([0-9.]+)C',(out/'tegrastats.log').read_text())]
        finished=[j for j in jobs.values() if j['status']=='completed']
        summaries[mode]={'exit_code':process.returncode,'caption_count':len(caps),'source_texts':[c['zh'] for c in caps],
            'job_states':dict(collections.Counter(j['status'] for j in jobs.values())),
            'admission_errors':dict(collections.Counter(c['speech_error'] for c in caps if c.get('speech_error'))),
            'translation_errors':[c for c in caps if c.get('translation_error')],
            'completed_audio_seconds':sum(j['duration_seconds'] for j in finished),
            'synthesis_RTF':metric([j['synthesis_seconds']/j['duration_seconds'] for j in finished]),
            'cpu_all_cores_percent':metric([r['cpu_all_cores_percent'] for r in active if r['cpu_all_cores_percent'] is not None]),
            'minimum_available_GiB':min(r['available_bytes'] for r in rows)/1024**3,
            'swapin_pages':rows[-1]['pswpin']-rows[0]['pswpin'],'swapout_pages':rows[-1]['pswpout']-rows[0]['pswpout'],
            'gpu_percent':metric(gpu_pct),'cpu_temperature_C':metric(temps),'process_metrics':proc}
        save(out/'jobs.json',list(jobs.values()))
        save(HERE/'summary.json',summaries)
        print(json.dumps(summaries[mode],ensure_ascii=False),flush=True)
        time.sleep(2)
    summaries['same_source_texts']=summaries['paced-playback']['source_texts']==summaries['wav-only']['source_texts']
    save(HERE/'summary.json',summaries)
    save(HERE/'progress.json',{'phase':'complete'})


if __name__=='__main__':
    main()
