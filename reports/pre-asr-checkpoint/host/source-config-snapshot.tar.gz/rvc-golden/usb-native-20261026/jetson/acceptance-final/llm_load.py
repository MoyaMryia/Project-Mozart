import json
from pathlib import Path
import signal
import time
import urllib.request

root = Path(__file__).resolve().parent
stop = False

def finish(signum, frame):
    global stop
    stop = True

signal.signal(signal.SIGTERM, finish)
signal.signal(signal.SIGINT, finish)
started = time.monotonic()
report = {"passed": False, "started_monotonic_s": started, "requests": [], "error": None}
try:
    with (root / "llm-requests.jsonl").open("w") as log:
        while not stop and time.monotonic() - started < 150:
            body = {"model": "qwen", "messages": [
                {"role": "system", "content": "Translate Chinese to English. Return only the translation."},
                {"role": "user", "content": f"第 {len(report['requests']) + 1} 组：今天的天气很好，我们一起去公园散步。"}],
                "max_tokens": 128, "temperature": 0, "stream": False,
                "chat_template_kwargs": {"enable_thinking": False}}
            began = time.monotonic()
            request = urllib.request.Request("http://127.0.0.1:18204/v1/chat/completions",
                data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(request, timeout=30) as response:
                result = json.load(response)
            content = result["choices"][0]["message"]["content"]
            tokens = result["usage"]["completion_tokens"]
            if not isinstance(content, str) or not content.strip() or not isinstance(tokens, int) or tokens <= 0:
                raise ValueError("LLM response contains no generated text or tokens")
            item = {"started_monotonic_s": began, "finished_monotonic_s": time.monotonic(),
                    "content": content, "completion_tokens": tokens}
            report["requests"].append(item)
            log.write(json.dumps(item, ensure_ascii=False) + "\n")
            log.flush()
    report["passed"] = bool(report["requests"])
except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
    report["error"] = f"{type(error).__name__}: {error}"
    raise
finally:
    report["finished_monotonic_s"] = time.monotonic()
    (root / "llm-load.json").write_text(json.dumps(report, ensure_ascii=False, indent=2))
