#!/bin/bash
set -euo pipefail
cd /home/moyamryia/Mozart
base=/home/moyamryia/Mozart/build/run/acceptance-20261026/async-final
mkdir -p "$base"
cp build/run/acceptance-20261026/llm_load.py "$base/llm_load.py"
start() {
    local role=$1; shift
    sudo systemd-run --unit="mozart-native-${role}-t4-20261026" --collect \
        --property=Type=exec --property=RuntimeMaxSec=240 --property=User=moyamryia \
        --property=WorkingDirectory=/home/moyamryia/Mozart \
        --property="StandardOutput=append:$base/$role.log" --property=StandardError=inherit "$@"
}
start rvc build-gpu/state/mozart_stated /home/moyamryia/Mozart/rvc-golden/full-run-20261005/backend.yaml
start llm /usr/bin/env LD_LIBRARY_PATH=/home/moyamryia/mozart-archive/qwen35/llama.cpp/build-cuda-bin \
    /home/moyamryia/mozart-archive/qwen35/llama.cpp/build-cuda-bin/llama-server \
    -m /home/moyamryia/mozart-archive/qwen35/gguf/qwen35-0.8b-text-Q4_K_M.gguf \
    -c 2048 -ngl 99 -np 1 -t 2 -tb 2 --host 127.0.0.1 --port 18204 --jinja
start ai .venv/bin/python tools/native_ai_load.py \
    --asr-model /home/moyamryia/models/sherpa-onnx/zipformer-zh-14M \
    --tts-model /home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-pocket-tts-int8-2026-01-26 \
    --wav /home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17/test_wavs/zh.wav \
    --seconds 150 --output "$base/ai.json" --ready-file "$base/ai-ready.json"
ready=0
for i in $(seq 1 60); do
    if test -s "$base/ai-ready.json" && curl -fsS http://127.0.0.1:18204/health > "$base/llm-health.json" 2>/dev/null \
        && curl -fsS http://127.0.0.1:18080/api/status > "$base/rvc-initial.json" 2>/dev/null; then
        ready=1; break
    fi
    sleep 1
done
[[ "$ready" == 1 ]]
curl -fsS -X POST http://127.0.0.1:18080/api/mode/switch -H 'Content-Type: application/json' \
    -d '{"mode":"rt_rvc","model_id":"qiqi-zh-realtime"}' > "$base/activate.json"
start requests .venv/bin/python "$base/llm_load.py"
ready=0
for i in $(seq 1 30); do
    if test -s "$base/llm-requests.jsonl"; then ready=1; break; fi
    sleep 1
done
[[ "$ready" == 1 ]]
curl -fsS http://127.0.0.1:18080/api/status > "$base/rvc-before.json"
.venv/bin/python -c 'import time; print(time.monotonic())' > "$base/host-window-start-monotonic.txt"
printf 'load ready\n'
