#!/usr/bin/env python3
"""Isolated, warm sherpa-onnx reference TTS worker; JSON lines in and out."""
import argparse
import json
import sys
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--engine', choices=['pocket', 'zipvoice'], required=True)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--vocoder', default='')
    parser.add_argument('--threads', type=int, default=2)
    args = parser.parse_args()
    import numpy as np
    import soundfile as sf
    import sherpa_onnx as so
    m = args.model
    if args.engine == 'pocket':
        model = so.OfflineTtsPocketModelConfig(**{
            key: str(m / filename) for key, filename in {
                'lm_flow': 'lm_flow.int8.onnx', 'lm_main': 'lm_main.int8.onnx',
                'encoder': 'encoder.onnx', 'decoder': 'decoder.int8.onnx',
                'text_conditioner': 'text_conditioner.onnx', 'vocab_json': 'vocab.json',
                'token_scores_json': 'token_scores.json'}.items()})
    else:
        model = so.OfflineTtsZipvoiceModelConfig(
            encoder=str(m/'encoder.int8.onnx'), decoder=str(m/'decoder.int8.onnx'),
            tokens=str(m/'tokens.txt'), lexicon=str(m/'lexicon.txt'),
            data_dir=str(m/'espeak-ng-data'), vocoder=args.vocoder)
    tts = so.OfflineTts(so.OfflineTtsConfig(model=so.OfflineTtsModelConfig(
        **{args.engine: model}, num_threads=args.threads, provider='cpu')))
    print(json.dumps({'ready': True, 'runtime': so.__version__, 'engine': args.engine}), flush=True)
    for line in sys.stdin:
        job = json.loads(line)
        start = time.monotonic()
        first = None
        received = 0
        limit = job['max_duration_seconds']
        def callback(samples, progress):
            nonlocal first, received
            if first is None:
                first = time.monotonic() - start
            received += len(samples)
            return int(received / tts.sample_rate <= limit)
        try:
            reference, rate = sf.read(job['reference'], dtype='float32')
            config = so.GenerationConfig()
            config.reference_audio = reference
            config.reference_sample_rate = rate
            config.reference_text = job.get('reference_text', '')
            config.num_steps = 5 if args.engine == 'pocket' else 4
            config.speed = 1
            config.silence_scale = 1
            maximum_frames = None
            if args.engine == 'pocket':
                config.extra = {'seed': '42'}
                if job.get('live') or job.get('chunk_count', 1) > 1:
                    # Pocket's latent frames represent 80 ms. Bound the latent
                    # loop itself: its callbacks only run during later decoding.
                    maximum_frames = max(1, int(limit*12.5))
                    config.extra['max_frames'] = str(maximum_frames)
            audio = tts.generate(job['text'], config, callback)
            pcm = np.asarray(audio.samples, dtype='float32')
            duration = len(pcm) / audio.sample_rate
            if not len(pcm) or not np.isfinite(pcm).all():
                raise ValueError('Engine returned empty or non-finite audio')
            if duration > limit or received / tts.sample_rate > limit:
                raise ValueError('Generated speech exceeded the duration limit; result rejected')
            if maximum_frames is not None and duration >= maximum_frames*.08-.001:
                raise ValueError('Generation reached the frame limit without a verified ending; result rejected')
            peak = float(np.max(np.abs(pcm)))
            if peak > 4:
                raise ValueError('Engine amplitude exceeds the safe range; result rejected')
            gain = min(1.0, .98/peak) if peak else 1.0
            pcm *= gain
            sf.write(job['output'], pcm, audio.sample_rate, subtype='PCM_16', format='WAV')
            print(json.dumps({'duration_seconds': duration, 'sample_rate': audio.sample_rate,
                'synthesis_seconds': time.monotonic()-start, 'first_callback_seconds': first,
                'raw_peak': peak, 'output_gain': gain}), flush=True)
        except Exception as error:
            print(json.dumps({'error': str(error)}), flush=True)


if __name__ == '__main__':
    main()
