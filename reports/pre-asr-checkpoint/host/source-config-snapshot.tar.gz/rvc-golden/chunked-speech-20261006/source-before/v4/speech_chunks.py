"""Split reference speech at word/clause boundaries without dropping text."""
import re

UNFINISHED_ENDINGS = {'a', 'an', 'the', 'to', 'of', 'for', 'with', 'from', 'into',
                     'and', 'or', 'but', 'because', 'that', 'which', 'while',
                     'my', 'your', 'his', 'her', 'their', 'our'}


def split_speech_text(text, language='en', words=12):
    if language == 'zh':
        # Preserve every character; prefer punctuation in the latter half.
        result = []
        while len(text) > 24:
            cuts = [i+1 for i, c in enumerate(text[:24]) if c in '，。！？；' and i >= 11]
            cut = cuts[-1] if cuts else 24
            result.append(text[:cut])
            text = text[cut:]
        if text:
            result.append(text)
        return result
    tokens = text.split()
    result = []
    while len(tokens) > words:
        sentences = [i+1 for i, word in enumerate(tokens[:words])
                     if i >= 3 and re.search(r'[.!?][\"\')]*$', word)]
        cuts = sentences or [i+1 for i, word in enumerate(tokens[:words])
                if i >= 3 and re.search(r'[.!?;,][\"\')]*$', word)]
        cut = cuts[-1] if cuts else words
        if not cuts:
            # A fragment such as "paid money to" provoked repeating generation
            # in the real replay. Keep the preposition/determiner with its phrase.
            while cut > 4 and tokens[cut-1].lower() in UNFINISHED_ENDINGS:
                cut -= 1
        result.append(' '.join(tokens[:cut]))
        tokens = tokens[cut:]
    if tokens:
        tail = ' '.join(tokens)
        if len(tokens) < 4 and result and len(result[-1].split())+len(tokens) <= words+3:
            result[-1] += ' '+tail
        else:
            result.append(tail)
    return result


def estimated_audio_seconds(text, language='en'):
    # Calibrated conservatively from the saved Qiqi/PocketTTS run (~.344 s/word).
    return max(.8, len(text)*.18 if language == 'zh' else len(text.split())*.36)
