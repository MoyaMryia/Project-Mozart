"""Verify collected hashes, ordered PCM assembly and text preservation."""
import hashlib
import json
from pathlib import Path
import re
import sys
import wave

base=Path(__file__).resolve().parent
a=base/sys.argv[1]
jobs=json.loads((a/'jobs.json').read_text())
summary=json.loads((a/'summary.json').read_text())
parents=json.loads((a/'archive-sha256.json').read_text())
pieces=json.loads((a/'archive-chunks-sha256.json').read_text())
for key,value in parents.items():
    assert hashlib.sha256((a/'archive'/(key+'.wav')).read_bytes()).hexdigest()==value,key
for key,value in pieces.items():
    assert hashlib.sha256((a/'archive-chunks'/key).read_bytes()).hexdigest()==value,key
combined=a/'qiqi-translated-combined.wav'
assert hashlib.sha256(combined.read_bytes()).hexdigest()==summary['combined_sha256']
done=[j for j in jobs if j['status']=='completed']
frames=0
for j in jobs:
    assert ' '.join(j['chunk_texts'])==' '.join(j['text'].split()),j['id']
    for p in j['chunks']:
        if 'synthesis_text' in p:
            tokens=lambda s:re.findall(r"\w+(?:'\w+)?",s)
            assert tokens(p['synthesis_text'])==tokens(p['text']),p['filename']
for j in done:
    assert ' '.join(p['text'] for p in j['chunks'])==' '.join(j['text'].split()),j['id']
    parts=[]
    for p in j['chunks']:
        with wave.open(str(a/'archive-chunks'/p['filename']),'rb') as w:
            parts.append(w.readframes(w.getnframes()))
    with wave.open(str(a/'archive'/(j['id']+'.wav')),'rb') as w:
        assert b''.join(parts)==w.readframes(w.getnframes()),j['id']
        frames+=w.getnframes()
with wave.open(str(combined),'rb') as w:
    assert frames==w.getnframes()
    seconds=w.getnframes()/w.getframerate()
segments=json.loads((a/'combined-segments.json').read_text())
with wave.open(str(combined),'rb') as joined:
    for segment in segments:
        with wave.open(str(a/'archive'/(segment['job_id']+'.wav')),'rb') as parent:
            count=parent.getnframes()
            assert joined.readframes(count)==parent.readframes(count),segment['job_id']
    assert not joined.readframes(1)
assert len(parents)==len(done)
receipt={'attempt':sys.argv[1],'verified_parent_hashes':len(parents),'verified_piece_hashes':len(pieces),
    'verified_combined_hash':summary['combined_sha256'],'combined_seconds':seconds,
    'all_parent_PCM_matches_ordered_piece_PCM':True,'combined_PCM_matches_ordered_parent_PCM':True,'all_original_text_and_synthesis_words_preserved':True}
(a/'collection-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
