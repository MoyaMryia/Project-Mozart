"""Bounded offline Pocket controls; never overlap workload or quality inference."""
import fcntl
import hashlib
import json
from pathlib import Path
import time

import numpy as np
import soundfile as sf
import sherpa_onnx as so

BASE = Path(__file__).resolve().parent
HERE = BASE/'termination-controls-v3'
HERE.mkdir(exist_ok=False)
lock = (BASE/'active-test.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert (BASE/'long-v2/exit-status.json').exists()
m = Path('/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-pocket-tts-int8-2026-01-26')
model = so.OfflineTtsPocketModelConfig(**{k:str(m/v) for k,v in {
    'lm_flow':'lm_flow.int8.onnx', 'lm_main':'lm_main.int8.onnx',
    'encoder':'encoder.onnx', 'decoder':'decoder.int8.onnx',
    'text_conditioner':'text_conditioner.onnx', 'vocab_json':'vocab.json',
    'token_scores_json':'token_scores.json'}.items()})
tts = so.OfflineTts(so.OfflineTtsConfig(model=so.OfflineTtsModelConfig(
    pocket=model,num_threads=2,provider='cpu')))
ref = next((BASE/'long-v2/speech/voices').glob('*.wav'))
pcm,rate = sf.read(ref,dtype='float32')
cases = [
 ('loan-raw', "They didn't know that I had taken out a loan", 11),
 ('loan-period', "They didn't know that I had taken out a loan.", 11),
 ('loan-complete', "They didn't know that I had taken out a loan from my family before.", 12),
 ('ellipsis-raw', 'to confess. One is kidnapping someone, the other is...', 10.1),
 ('ellipsis-period', 'to confess. One is kidnapping someone, the other is.', 10.1),
 ('yes-raw','yes',4), ('yes-period','yes.',4),
]
results=[]
for name,text,limit in cases:
    c=so.GenerationConfig();c.reference_audio=pcm;c.reference_sample_rate=rate
    c.num_steps=5;c.speed=1;c.silence_scale=1
    frames=int(limit*12.5);c.extra={'seed':'42','max_frames':str(frames)}
    received=[0]
    def callback(samples,progress):
        received[0]+=len(samples)
        return int(received[0]/tts.sample_rate<=limit)
    start=time.monotonic();a=tts.generate(text,c,callback)
    duration=len(a.samples)/a.sample_rate
    path=HERE/(name+'.wav');sf.write(path,np.asarray(a.samples),a.sample_rate,subtype='PCM_16')
    result={'case':name,'text':text,'limit':limit,'extras':dict(c.extra),
        'duration_seconds':duration,'compute_seconds':time.monotonic()-start,
        'received_seconds':received[0]/tts.sample_rate,
        'saturated_or_over_limit':duration>=frames*.08-.001 or received[0]/tts.sample_rate>limit,
        'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    results.append(result);print(json.dumps(result),flush=True)
    (HERE/'results.json').write_text(json.dumps(results,indent=2)+'\n')
(HERE/'protocol.json').write_text(json.dumps({'runtime':so.__version__,'reference':str(ref),
    'reference_sha256':hashlib.sha256(ref.read_bytes()).hexdigest(),
    'model':str(m),'steps':5,'seed':42,'threads':2,'output':'diagnostic only; rejected audio retained'},indent=2)+'\n')
