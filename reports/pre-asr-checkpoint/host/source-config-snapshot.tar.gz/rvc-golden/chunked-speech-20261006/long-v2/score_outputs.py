"""Offline WAV health and sampled intelligibility; run after the soak exits."""
import collections
import fcntl
import json
from pathlib import Path
import re
import statistics
import time

import librosa
import numpy as np
import soundfile as sf
import torch
from transformers import WhisperFeatureExtractor, WhisperTokenizerFast, WhisperForConditionalGeneration

HERE = Path(__file__).resolve().parent
assert (HERE/'exit-status.json').exists(), 'Wait for the timed workload to exit'
campaign_lock = (HERE.parent/'active-test.lock').open('a')
fcntl.flock(campaign_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
jobs = sorted([j for j in json.loads((HERE/'jobs.json').read_text()) if j['status']=='completed'], key=lambda j:j['created_at'])
assert jobs, 'No completed speech to score'
health = []
boundaries = []
for job in jobs:
    path = HERE/'archive'/(job['id']+'.wav')
    pcm, rate = sf.read(path, dtype='float32')
    offset = 0
    for piece in job.get('chunks', [])[:-1]:
        offset += round(piece['duration_seconds']*rate)
        if 0 < offset < len(pcm):
            boundaries.append({'job_id':job['id'], 'sample_offset':offset,
                'absolute_step':float(abs(pcm[offset]-pcm[offset-1]))})
    health.append({'id':job['id'], 'duration_seconds':len(pcm)/rate,
        'sample_rate':rate, 'finite':bool(np.isfinite(pcm).all()),
        'peak':float(np.max(np.abs(pcm))) if len(pcm) else 0,
        'rms':float(np.sqrt(np.mean(pcm.astype('float64')**2))) if len(pcm) else 0,
        'clip_percent':float(np.mean(np.abs(pcm)>=.999)*100) if len(pcm) else 0})
(HERE/'audio-health.json').write_text(json.dumps(health,indent=2))
(HERE/'chunk-boundaries.json').write_text(json.dumps(boundaries,indent=2))
# Whisper-small has a 30-second feature window; do not silently truncate long WAVs.
eligible = [j for j in jobs if j['duration_seconds']<=29]
assert eligible, 'No speech within the scoring window'
indices = sorted(set(round(i*(len(eligible)-1)/7) for i in range(8)))
selected = {eligible[i]['id']:eligible[i] for i in indices}
for job in [min(eligible,key=lambda j:j['duration_seconds']),max(eligible,key=lambda j:j['duration_seconds'])]:
    selected[job['id']] = job
torch.set_num_threads(2)
snapshot = next(Path('/home/moyamryia/mozart-archive/seedVC/checkpoints/hf_cache/models--openai--whisper-small/snapshots').iterdir())
feature = WhisperFeatureExtractor.from_pretrained(snapshot,local_files_only=True)
tokenizer = WhisperTokenizerFast.from_pretrained(Path('/home/moyamryia/Mozart/rvc-golden/clone-tts/test-20261004/mozart-whisper-tokenizer'),local_files_only=True)
model = WhisperForConditionalGeneration.from_pretrained(snapshot,local_files_only=True,torch_dtype=torch.float16).to('cuda').eval()
def words(text):
    return re.findall(r"[a-z]+(?:'[a-z]+)?|[0-9]+",text.lower())
def edit_count(reference,hypothesis):
    r,h = words(reference),words(hypothesis)
    previous = list(range(len(h)+1))
    for i,a in enumerate(r,1):
        current = [i]
        for j,b in enumerate(h,1):
            current.append(min(previous[j]+1,current[j-1]+1,previous[j-1]+(a!=b)))
        previous = current
    return previous[-1],len(r)
results = []
for job in sorted(selected.values(),key=lambda j:j['created_at']):
    pcm,rate = sf.read(HERE/'archive'/(job['id']+'.wav'),dtype='float32')
    if rate!=16000:
        pcm = librosa.resample(pcm,orig_sr=rate,target_sr=16000)
    encoded = feature(pcm,sampling_rate=16000,return_tensors='pt',return_attention_mask=True)
    began = time.monotonic()
    with torch.inference_mode():
        ids = model.generate(encoded.input_features.to('cuda',dtype=model.dtype),
            attention_mask=encoded.attention_mask.to('cuda'),max_new_tokens=256,do_sample=False,
            forced_decoder_ids=tokenizer.get_decoder_prompt_ids(language='en',task='transcribe'))
    text = tokenizer.batch_decode(ids,skip_special_tokens=True)[0]
    errors,count = edit_count(job['text'],text)
    results.append({'id':job['id'],'expected':job['text'],'transcribed':text,
        'duration_seconds':job['duration_seconds'],'word_edits':errors,'reference_words':count,
        'WER':errors/max(count,1),'decode_seconds':time.monotonic()-began})
    print(json.dumps(results[-1]),flush=True)
    (HERE/'intelligibility-samples.json').write_text(json.dumps(results,indent=2))
summary = {'model':'cached official Whisper-small','sample_selection':'eight evenly spaced completed jobs, plus shortest and longest; <=29 seconds',
    'samples':len(results),'human_voice_identity_approved':False,
    'weighted_WER':sum(r['word_edits'] for r in results)/max(1,sum(r['reference_words'] for r in results)),
    'median_WER':statistics.median(r['WER'] for r in results),
    'all_completed_WAVs_finite':all(r['finite'] for r in health),
    'completed_WAV_count':len(health),'maximum_peak':max(r['peak'] for r in health),
    'maximum_clip_percent':max(r['clip_percent'] for r in health),
    'chunk_boundary_count':len(boundaries),
    'maximum_chunk_boundary_step':max((b['absolute_step'] for b in boundaries),default=0),
    'excluded_from_ASR_for_duration':sum(j['duration_seconds']>29 for j in jobs)}
(HERE/'quality-summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary),flush=True)
