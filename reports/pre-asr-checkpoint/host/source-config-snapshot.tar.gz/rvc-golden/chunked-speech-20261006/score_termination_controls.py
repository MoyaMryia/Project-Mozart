"""Score exact repaired failure inputs using the same cached Whisper model."""
import fcntl
import json
from pathlib import Path
import librosa
import soundfile as sf
import torch
from transformers import WhisperFeatureExtractor, WhisperTokenizerFast, WhisperForConditionalGeneration

base=Path(__file__).resolve().parent
lock=(base/'active-test.lock').open('a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
here=base/'termination-controls-v3'
cases=json.loads((here/'results.json').read_text())
torch.set_num_threads(2)
snapshot=next(Path('/home/moyamryia/mozart-archive/seedVC/checkpoints/hf_cache/models--openai--whisper-small/snapshots').iterdir())
feature=WhisperFeatureExtractor.from_pretrained(snapshot,local_files_only=True)
tokenizer=WhisperTokenizerFast.from_pretrained('/home/moyamryia/Mozart/rvc-golden/clone-tts/test-20261004/mozart-whisper-tokenizer',local_files_only=True)
model=WhisperForConditionalGeneration.from_pretrained(snapshot,local_files_only=True,torch_dtype=torch.float16).to('cuda').eval()
results=[]
for case in cases:
    if case['case'] not in ('loan-period','ellipsis-period','yes-period'):
        continue
    pcm,rate=sf.read(here/(case['case']+'.wav'),dtype='float32')
    pcm=librosa.resample(pcm,orig_sr=rate,target_sr=16000)
    encoded=feature(pcm,sampling_rate=16000,return_tensors='pt',return_attention_mask=True)
    with torch.inference_mode():
        ids=model.generate(encoded.input_features.to('cuda',dtype=model.dtype),attention_mask=encoded.attention_mask.to('cuda'),max_new_tokens=128,do_sample=False,forced_decoder_ids=tokenizer.get_decoder_prompt_ids(language='en',task='transcribe'))
    results.append({'case':case['case'],'expected':case['text'], 'transcribed':tokenizer.batch_decode(ids,skip_special_tokens=True)[0],'duration_seconds':case['duration_seconds'],'human_voice_similarity_verified':False})
    print(json.dumps(results[-1]),flush=True)
    (here/'intelligibility.json').write_text(json.dumps(results,indent=2)+'\n')
