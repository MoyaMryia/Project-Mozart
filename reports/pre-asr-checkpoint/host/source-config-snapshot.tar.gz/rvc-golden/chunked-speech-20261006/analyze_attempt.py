"""Compare retained identical-source runs; no inference or file mutations outside reports."""
import collections
import json
from pathlib import Path
import statistics
import sys

base=Path(__file__).resolve().parent
attempt=base/sys.argv[1]
baseline=(base.parent/'overload-diagnosis-20261006/paced-playback'
          if json.loads((attempt/'summary.json').read_text())['source_seconds']==120
          else base.parent/'long-speech-20261006')
def read(p): return json.loads(p.read_text())
def captions(p): return [json.loads(l) for l in p.read_text().splitlines() if l]
def stats(xs):
    if not xs:return None
    xs=sorted(xs)
    return {'min':xs[0],'median':statistics.median(xs),'p95':xs[min(len(xs)-1,int(.95*len(xs)))],'max':xs[-1]}
oldc=captions(baseline/'runtime/subtitles.jsonl')
newc=captions(attempt/'runtime/subtitles.jsonl' if (attempt/'runtime/subtitles.jsonl').exists() else attempt/'captions.jsonl')
oldj=read(baseline/'jobs.json');newj=read(attempt/'jobs.json')
out={'source_caption_count':{'baseline':len(oldc),'attempt':len(newc)},
     'matching_recognition_and_translation':len(oldc)==len(newc) and all((a['zh'],a['en'])==(b['zh'],b['en']) for a,b in zip(oldc,newc)),
     'recognition_changes':[a['seq'] for a,b in zip(oldc,newc) if a['zh']!=b['zh']],
     'translation_changes':[a['seq'] for a,b in zip(oldc,newc) if a['en']!=b['en']],
     'coverage':{}}
for label,cs,js in [('baseline',oldc,oldj),('attempt',newc,newj)]:
    valid=[c for c in cs if c.get('speech') or c.get('speech_error','').startswith('HTTP Error 429')]
    done=[j for j in js if j['status']=='completed']
    offered=sum(len(c['en'].split()) for c in valid)
    words=sum(len(j['text'].split()) for j in done)
    out['coverage'][label]={'valid_offered_jobs':len(valid),'completed_jobs':len(done),
        'valid_job_fraction':len(done)/len(valid),'offered_words':offered,
        'completed_text_words':words,'word_fraction':words/offered,
        'budget_skipped_words':sum(len(c['en'].split()) for c in valid if c.get('speech_error'))}
def key(j):return j.get('utterance_id','').rsplit(':',1)[-1]
o={key(j):j for j in oldj if j['status']=='completed'}
pairs=[(o[key(j)],j) for j in newj if j['status']=='completed' and key(j) in o and o[key(j)]['text']==j['text']]
out['matched_completed_jobs']=len(pairs)
for field in ('audio_ready_at','playback_started_at'):
    out[field+'_matched_delay']={label:stats([pair[i][field]-pair[i]['created_at'] for pair in pairs]) for i,label in enumerate(('baseline','attempt'))}
rows=captions(attempt/'telemetry.jsonl')
out['CPU_all_cores_percent']=stats([r['cpu_all_cores_percent'] for r in rows if r.get('cpu_all_cores_percent') is not None])
bykind=collections.defaultdict(lambda:{'rss_bytes':[],'one_core_percent':[]})
for r in rows:
    grouped=collections.defaultdict(lambda:{'rss_bytes':0,'one_core_percent':0})
    for p in r.get('processes',{}).values():
        for metric in grouped[p['kind']]: grouped[p['kind']][metric]+=p.get(metric,0) or 0
    for kind,metrics in grouped.items():
        for k,v in metrics.items():bykind[kind][k].append(v)
out['process_metrics']={kind:{k:stats(v) for k,v in m.items()} for kind,m in bykind.items()}
out['all_admitted_chunk_texts_preserve_original']=all(' '.join(j.get('chunk_texts',[]))==' '.join(j['text'].split()) for j in newj)
out['successful_synthesis_not_played_seconds']=sum(c.get('synthesis_seconds',0) for j in newj for c in j.get('chunks',[]) if j.get('playback') and c.get('status')!='completed')
out['failed_call_compute_seconds']='Not separately instrumented in this attempt; do not treat failed-job wall time as CPU compute.'
out['partial_failed_played_seconds']=sum(j.get('played_duration_seconds',0) for j in newj if j['status']=='failed')
out['note']='Word coverage counts completed translated text, not verified pronunciations. Failed partial jobs are excluded from completed coverage.'
(attempt/'comparison.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
