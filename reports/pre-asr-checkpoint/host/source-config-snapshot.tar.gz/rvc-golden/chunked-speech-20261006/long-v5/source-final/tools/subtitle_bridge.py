#!/usr/bin/env python3
"""Streaming Chinese ASR → English translation → captions and reference speech.

Captions are always published. Speech admission failures are explicit and never
fall back to reading Chinese through an English voice. The speech service owns
its bounded queue and playback device.
"""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import urllib.request
import uuid
from translation_checks import missing_numbers, required_numbers

SYSTEM_PROMPT = (
    'Translate the Chinese utterance into English. Return only the translation. '
    'Preserve names, years, numbers, negation and uncertainty exactly. '
    'Use Arabic numerals for years and large quantities. 二本院校 means a second-tier college, '
    'not a two-year college. 七八万 means 70,000–80,000. '
    'Do not invent context, people, relationships or events. /no_think'
)


def request_json(url, body, timeout=10):
    request = urllib.request.Request(url, data=json.dumps(body).encode(),
        headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.load(response)


def translate(url, text, timeout=10):
    started = time.monotonic()
    constraints = required_numbers(text)
    messages = [{'role': 'system', 'content': SYSTEM_PROMPT}, {'role': 'user', 'content': text}]
    if constraints:
        messages[0]['content'] += ' Preserve these exact numerals: '+', '.join(constraints)+'.'
    for attempt in range(2):
        result = request_json(url+'/v1/chat/completions', {
            'chat_template_kwargs': {'enable_thinking': False},
            'messages': messages, 'max_tokens': 300, 'temperature': 0}, timeout)
        content = result['choices'][0]['message']['content'].strip()
        if not content:
            raise ValueError('Translator returned no text')
        missing = missing_numbers(text, content)
        if not missing:
            return content, time.monotonic()-started
        messages += [{'role':'assistant', 'content':content}, {'role':'user',
            'content':'Correct the translation. Preserve the original meaning and these exact numerals: '
                +', '.join(missing)+'. Return only the corrected English translation.'}]
    raise ValueError('Translation rejected: required numerals missing: '+', '.join(missing))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stt-model', required=True)
    parser.add_argument('--final-model', default=None, help='Optional SenseVoice final-utterance model directory')
    parser.add_argument('--stt-port', type=int, default=18100)
    parser.add_argument('--llama-url', default='http://127.0.0.1:18200')
    parser.add_argument('--jsonl', default='/tmp/opencode/subtitles.jsonl')
    parser.add_argument('--speech-url', default='http://127.0.0.1:18080',
                        help='Speech-session API; speech is enabled in the control UI')
    parser.add_argument('--speak', action='store_true', help='Submit translated text to an enabled speech session')
    args = parser.parse_args()
    Path(args.jsonl).parent.mkdir(parents=True, exist_ok=True)
    session_id = uuid.uuid4().hex
    stt_command = [sys.executable, str(Path(__file__).with_name('stt_service.py')),
        '--model', args.stt_model, '--port', str(args.stt_port), '--json']
    if args.final_model:
        stt_command += ['--final-model', args.final_model]
    stt = subprocess.Popen(stt_command,
        stdout=subprocess.PIPE, stderr=sys.stderr, text=True)
    def terminate(*_):
        # Leave stdout open and drain the child's final utterance before exiting.
        if stt.poll() is None:
            stt.terminate()
    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    print(f'[bridge] stt pid={stt.pid} port={args.stt_port}', file=sys.stderr, flush=True)
    try:
        with open(args.jsonl, 'a', encoding='utf-8') as captions:
            seq = 0
            for line in stt.stdout:
                try:
                    event = json.loads(line.strip())
                except json.JSONDecodeError:
                    continue
                if event.get('type') != 'final' or not event.get('text', '').strip():
                    continue
                seq += 1
                text = event['text'].strip()
                record = {'seq': seq, 'utterance_id': f'{session_id}:{event["seq"]}',
                    'zh': text, 'en': '', 'asr_engine': event.get('final_engine', 'zipformer'),
                    'online_text': event.get('online_text', text), 'final_decode_ms': event.get('final_decode_ms', 0),
                    'ts': time.strftime('%H:%M:%S'), 'final': True}
                try:
                    record['en'], elapsed = translate(args.llama_url, text)
                    record['translate_ms'] = int(elapsed*1000)
                except Exception as error:
                    record['translation_error'] = str(error)
                    print(f'[bridge] translate failed: {error}', file=sys.stderr, flush=True)
                if args.speak and record['en']:
                    try:
                        result = request_json(args.speech_url+'/api/speech/events', {
                            'text': record['en'], 'source_text': text,
                            'utterance_id': record['utterance_id']}, timeout=3)
                        record['speech'] = result.get('id', result.get('skipped', ''))
                    except Exception as error:
                        record['speech_error'] = str(error)
                print(json.dumps(record, ensure_ascii=False), flush=True)
                captions.write(json.dumps(record, ensure_ascii=False)+'\n')
                captions.flush()
        stt.wait(timeout=5)
        if stt.returncode:
            raise RuntimeError(f'STT exited with status {stt.returncode}')
    finally:
        if stt.poll() is None:
            stt.terminate()
            try:
                stt.wait(timeout=5)
            except subprocess.TimeoutExpired:
                stt.kill()
                stt.wait()
        stt.stdout.close()


if __name__ == '__main__':
    main()
