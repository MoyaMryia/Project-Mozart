"""Exercise the corrected numeric split through the real SpeechService worker."""
import base64
import fcntl
import hashlib
import json
from pathlib import Path
import sys
import time

base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root/'tools'))
from speech_service import SpeechService

lock=(base/'active-test.lock').open('a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert (base/'short-v4/quality-summary.json').exists()
here=base/'numeric-service-v4'
here.mkdir(exist_ok=False)
command=[str(root/'.venv/bin/python'),str(root/'tools/clone_worker.py'),
    '--engine','pocket','--model','/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-pocket-tts-int8-2026-01-26','--threads','2']
service=SpeechService(here,command,playback_device='null')
try:
    ref=next((base/'long-v3/speech/voices').glob('*.wav'))
    voice=service.add_voice({'name':'Numeric production control','audio_base64':base64.b64encode(ref.read_bytes()).decode()})
    text='After winning 25,000, I am afraid to tell them it is gambling.'
    job=service.submit({'text':text,'voice_id':voice['id'],'live':True,'playback':False})
    deadline=time.monotonic()+100
    while time.monotonic()<deadline:
        job=service.route('GET','/api/speech/jobs/'+job['id'],{})
        if job['status'] in ('completed','failed','expired'):break
        time.sleep(.1)
    assert job['status']=='completed',job
    assert job['chunk_texts']==['After winning 25,000,','I am afraid to tell them it is gambling.']
    controls={c['case']:c for c in json.loads((base/'numeric-controls-v4/results.json').read_text())}
    for piece,key in zip(job['chunks'],('number-prefix-period','number-main-clause')):
        actual=hashlib.sha256((here/'results'/piece['filename']).read_bytes()).hexdigest()
        assert actual==controls[key]['sha256'],(actual,controls[key]['sha256'])
    result={'status':'passed','job':job,'pieces_match_scored_controls_byte_for_byte':True,
        'output':'Download-only component test; no physical playback',
        'source_sha256':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ('tools/speech_service.py','tools/speech_chunks.py','tools/clone_worker.py')}}
    (here/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'passed','duration_seconds':job['duration_seconds'],'chunks':job['chunk_count'],'pieces_match_scored_controls_byte_for_byte':True}),flush=True)
finally:
    service.close()
