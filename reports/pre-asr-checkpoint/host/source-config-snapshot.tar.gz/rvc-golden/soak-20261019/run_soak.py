"""按原速回放完整文件，保存组合运行与音频证据。"""
import argparse
import base64
from collections import Counter
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import select
import shutil
import signal
import socket
import sqlite3
import struct
import subprocess
import sys
import threading
import time
import urllib.request
import wave

import numpy as np
import soundfile as sf


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def request(url, body=None):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=3) as response:
        return json.load(response)


class Relay:
    def __init__(self, output):
        self.output = output
        self.stopped = threading.Event()
        self.error = None
        self.sent = self.received = 0
        self.duplicate = self.bad = self.out_of_order = 0
        self.last_index = -1
        self.peer = None
        self.incoming = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.incoming.bind(('127.0.0.1', 18020))
        self.backend = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.backend.connect(('127.0.0.1', 18010))
        self.thread = threading.Thread(target=self.run)

    def run(self):
        try:
            with sf.SoundFile(self.output/'processed-input.wav', 'w', 16000, 1, subtype='FLOAT') as source, \
                    sf.SoundFile(self.output/'qiqi-mozart-backend.wav', 'w', 48000, 1, subtype='FLOAT') as audio, \
                    (self.output/'rvc-packet-indices.bin').open('wb') as indices:
                while not self.stopped.is_set():
                    ready, _, _ = select.select([self.incoming, self.backend], [], [], .2)
                    for sock in ready:
                        if sock is self.incoming:
                            packet, self.peer = sock.recvfrom(65536)
                            if len(packet) != 1300 or packet[:4] != b'TRZM':
                                raise ValueError('Invalid input contract packet')
                            if struct.unpack_from('<I', packet, 12)[0] != self.sent + 1:
                                raise ValueError('Input frame sequence gap')
                            source.write(np.frombuffer(packet, dtype='<f4', offset=20))
                            self.backend.send(packet)
                            self.sent += 1
                        else:
                            packet = sock.recv(65536)
                            if len(packet) != 3860 or packet[:4] != b'TRZM':
                                self.bad += 1
                                raise ValueError('Invalid output contract packet')
                            index = struct.unpack_from('<I', packet, 12)[0]
                            if index != self.received + 1:
                                raise ValueError('Output frame sequence gap or duplicate')
                            self.duplicate += int(index == self.last_index)
                            self.out_of_order += int(index < self.last_index)
                            self.last_index = index
                            indices.write(struct.pack('<I', index))
                            samples = np.frombuffer(packet, dtype='<f4', offset=20)
                            if not np.isfinite(samples).all():
                                raise ValueError('Non-finite RVC output')
                            audio.write(samples)
                            self.received += 1
                            if self.peer:
                                self.incoming.sendto(packet, self.peer)
        except (OSError, ValueError, RuntimeError) as error:
            self.error = str(error)

    def close(self):
        self.stopped.set()
        self.thread.join(5)
        self.incoming.close()
        self.backend.close()

    def status(self):
        return {name: getattr(self, name) for name in
                ('sent', 'received', 'duplicate', 'bad', 'out_of_order', 'last_index', 'error')}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seconds', type=float, help='仅用于独立短预检。默认回放完整输入。')
    args = parser.parse_args()
    if args.seconds is not None and args.seconds <= 0:
        parser.error('seconds must be positive')
    root, output, home = args.repo.resolve(), args.output.resolve(), Path.home()
    output.mkdir(parents=True, exist_ok=False)
    sys.path[:0] = [str(root/'tools'), str(root/'rvc-golden'), str(root/'rvc-golden/realtime-patches-20261008')]
    from run_probe import sample
    from run_translated_speech import assert_ports_available, check_services
    from verify_tempo_playback import stats
    lock = (home/'Mozart/rvc-golden/reliability-20261006/active-test.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert_ports_available([(18080, socket.SOCK_STREAM), (18081, socket.SOCK_STREAM),
        (18090, socket.SOCK_STREAM), (18200, socket.SOCK_STREAM),
        (18100, socket.SOCK_DGRAM), (18010, socket.SOCK_DGRAM), (18020, socket.SOCK_DGRAM)])
    runtime = output/'runtime'
    runtime.mkdir()
    archived = output/'speech/results'
    archived.mkdir(parents=True)
    decoded = output/'input-48k-stereo.wav'
    probe = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
        '-of', 'json', str(args.input)], check=True, capture_output=True, text=True)
    source_seconds = float(json.loads(probe.stdout)['format']['duration'])
    if args.seconds is not None:
        source_seconds = min(source_seconds, args.seconds)
    filters = 'aresample=48000,'
    if args.seconds is not None:
        filters += f'atrim=duration={source_seconds},asetpts=PTS-STARTPTS,'
    filters += 'apad=pad_dur=3,asetnsamples=n=960:p=1'
    decode = ['ffmpeg', '-v', 'error', '-nostdin', '-i', str(args.input), '-af', filters,
        '-ar', '48000', '-ac', '2', '-c:a', 'pcm_s16le', str(decoded)]
    subprocess.run(decode, check=True, timeout=180)
    with wave.open(str(decoded), 'rb') as wav:
        frames = wav.getnframes() // 960
    assets = home/'Mozart/rvc-golden/qiqi-zh-run'
    reference = home/'Mozart/rvc-golden/clone-tts/qiqi-20261004/reference-qiqi-natural-source.wav'
    boundary = home/'mozart-efficiency-20261014/reference/nnsplit-zh.onnx'
    early = home/'mozart-realtime-patches-20261008/early-audio-runtime-20261009/python'
    old_config = home/'mozart-tempo-115-20261016/final115/rvc/parallel-1/backend.json'
    config = json.loads(old_config.read_text())
    config['network']['audio']['port'] = 18010
    config['network']['control']['port'] = 18090
    config['storage']['temp_dir'] = str(output/'rvc-temp')
    config['storage']['presets_path'] = str(output/'rvc-presets.json')
    save(output/'rvc-backend.json', config)
    speech_config = {'input': {'contract': {'sample_rate': 16000}},
        'output': {'sample_rate': 48000}, 'network': {'audio': {'host': '127.0.0.1', 'port': 18000},
        'control': {'host': '127.0.0.1', 'port': 18080}},
        'rvc': {'enabled': False, 'models_dir': str(output/'disabled-models'), 'device': 'cpu'},
        'storage': {'temp_dir': str(output/'file-temp'), 'presets_path': str(output/'presets.json'), 'max_queue_depth': 5}}
    save(output/'speech-backend.json', speech_config)
    py = str(root/'.venv/bin/python')
    binary = root/'build-gpu/state/mozart_stated'
    translator = home/'mozart-archive/qwen35/llama.cpp/build-cuda-bin/llama-server'
    commands = {
        'backend': [str(binary), str(output/'speech-backend.json')],
        'rvc': [str(binary), str(output/'rvc-backend.json')],
        'translation': [str(translator), '-m', str(home/'mozart-archive/qwen35/gguf/qwen35-0.8b-text-Q4_K_M.gguf'),
            '-c', '2048', '-b', '256', '-ub', '128', '--cache-ram', '128', '-ngl', '99',
            '-np', '1', '-t', '2', '-tb', '2', '--host', '127.0.0.1', '--port', '18200', '--jinja'],
        'speech': [py, str(root/'tools/speech_service.py'), '--model',
            str(home/'models/sherpa-onnx/clone-test-downloads/sherpa-onnx-pocket-tts-int8-2026-01-26'),
            '--preload', '--data-dir', str(output/'service-data'), '--playback-device', 'null',
            '--provider', 'cpu', '--precision', 'int8', '--threads', '2', '--delivery-policy', 'coverage',
            '--playback-tempo', 'flexible', '--playback-tempo-max', '1.15', '--capture-playback',
            '--early-audio', '--audio-chunk-frames', '3'],
        'captions': [py, str(root/'tools/subtitle_bridge.py'), '--stt-model',
            str(home/'models/sherpa-onnx/zipformer-zh-14M'), '--jsonl', str(runtime/'subtitles.jsonl'),
            '--speak', '--delivery-policy', 'coverage', '--queue-dir', str(output/'service-data/captions'),
            '--boundary-model', str(boundary), '--utterance-dir', str(runtime/'utterances')],
        'microphone': [str(root/'build-gpu/preprocessor/mozart-pre'), '-i', str(decoded), '--pace',
            '-a', '127.0.0.1', '-p', '18020', '-b', '127.0.0.1:18100', '-o', 'null', '-n', str(frames),
            '--model', str(home/'Mozart/preprocessor/assets/rnnoise_default.rnnb')]}
    protocol = {'input': str(args.input), 'input_sha256': digest(args.input),
        'source_seconds': source_seconds, 'flush_seconds': 3, 'expected_frames': frames,
        'requested_input': 'complete file' if args.seconds is None else 'separate short preflight',
        'reference_sha256': digest(reference), 'commands': commands, 'started_at': time.time(),
        'rnnoise_model_sha256': digest(home/'Mozart/preprocessor/assets/rnnoise_default.rnnb'),
        'source_sha256': {str(p.relative_to(root)): digest(p) for p in (root/'tools').glob('*.py')},
        'binary_sha256': digest(binary), 'tempo_library_sha256': digest(root/'build-gpu/preprocessor/libmozart-tempo.so'),
        'topology': 'One paced mozart-pre sends identical processed packets to ASR and realtime RVC; paced ALSA null TTS.',
        'preprocessing': 'Default native RNNoise/VAD/high-pass/resampling; same packets retained as processed-input.wav',
        'drain_budget_seconds': 900}
    save(output/'protocol.json', protocol)
    owned, jobs, copied = [], {}, set()
    relay = Relay(output)
    previous, samples = {}, []
    input_started = None
    completed = False
    database = None
    def stop(*_):
        raise KeyboardInterrupt('Soak interrupted')
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    def launch(name):
        env = dict(os.environ, MOZART_SUBTITLES_JSONL=str(runtime/'subtitles.jsonl'))
        if name == 'translation':
            env['LD_LIBRARY_PATH'] = str(translator.parent) + ':' + env.get('LD_LIBRARY_PATH', '')
        if name == 'speech':
            env['PYTHONPATH'] = str(early) + ':' + env.get('PYTHONPATH', '')
        if name == 'rvc':
            env.update(MOZART_RVC_PROFILE='1', MOZART_RVC_DEVICE_CHAIN='1', MOZART_RVC_PARALLEL_FEATURES='1')
        log = (runtime/(name + '.log')).open('w')
        proc = subprocess.Popen(commands[name], cwd=root, env=env, stdout=log,
            stderr=subprocess.STDOUT, start_new_session=True)
        owned.append((name, proc, log))
        save(output/'pids.json', {'harness': os.getpid(), **{n: p.pid for n, p, _ in owned}})
        return proc
    def ready(url, predicate=lambda value: True):
        deadline = time.monotonic() + 120
        while time.monotonic() < deadline:
            check_services(owned)
            try:
                value = request(url)
            except OSError:
                time.sleep(.2)
                continue
            if value.get('warmup_error'):
                raise RuntimeError(value['warmup_error'])
            if predicate(value):
                return value
            time.sleep(.2)
        raise TimeoutError('Service readiness timeout: ' + url)
    def capture(status):
        records = [json.loads(row[0]) for row in database.execute('SELECT payload FROM jobs ORDER BY created')]
        for job in records:
            jobs[job['id']] = job
            if job['status'] == 'completed' and job['id'] not in copied:
                paths = list((output/'service-data/results').glob(job['id'] + '*'))
                for path in paths:
                    shutil.copyfile(path, archived/path.name)
                if not (archived/(job['id'] + '.wav')).is_file():
                    raise RuntimeError('Completed synthesis missing: ' + job['id'])
                if job.get('playback_tempo', 1) > 1 and (not job.get('playback_audio_filename') or
                        not (archived/job['playback_audio_filename']).is_file()):
                    raise RuntimeError('Completed playback capture missing: ' + job['id'])
                copied.add(job['id'])
    def group_members(group):
        members = []
        for path in Path('/proc').iterdir():
            if not path.name.isdigit():
                continue
            try:
                fields = (path/'stat').read_text().rsplit(')', 1)[1].split()
            except (FileNotFoundError, ProcessLookupError):
                continue
            if int(fields[2]) == group and fields[0] != 'Z':
                members.append(int(path.name))
        return members
    try:
        launch('backend')
        ready('http://127.0.0.1:18080/api/status')
        launch('rvc')
        ready('http://127.0.0.1:18090/api/status')
        active = request('http://127.0.0.1:18090/api/mode/switch', {'mode': 'rt_rvc', 'model_id': 'qiqi-zh-realtime'})
        if active.get('status') != 'active':
            raise RuntimeError('RVC activation failed: ' + json.dumps(active))
        launch('translation')
        ready('http://127.0.0.1:18200/health')
        launch('speech')
        ready('http://127.0.0.1:18080/api/speech/status', lambda status: bool(status.get('runtime')))
        database = sqlite3.connect(f'file:{output}/service-data/speech-jobs.sqlite3?mode=ro', uri=True)
        voice = request('http://127.0.0.1:18080/api/voices', {'name': 'Qiqi full-file soak',
            'audio_base64': base64.b64encode(reference.read_bytes()).decode()})
        request('http://127.0.0.1:18080/api/speech/session', {'enabled': True, 'voice_id': voice['id'], 'language': 'en', 'playback': True})
        bridge = launch('captions')
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            check_services(owned)
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as check:
                try:
                    check.bind(('127.0.0.1', 18100))
                except OSError:
                    break
            time.sleep(.2)
        else:
            raise TimeoutError('ASR readiness timeout')
        relay.thread.start()
        pre = launch('microphone')
        input_started = time.monotonic()
        protocol['input_started_at'] = time.time()
        protocol['expected_input_end_at'] = time.time() + frames*.02
        save(output/'protocol.json', protocol)
        bridge_stopped = False
        with (output/'telemetry.jsonl').open('w') as telemetry:
            while True:
                elapsed = time.monotonic() - input_started
                if elapsed > frames*.02 + protocol['drain_budget_seconds']:
                    raise TimeoutError('Full-file replay and drain watchdog expired')
                required = [item for item in owned if item[0] not in ('microphone', 'captions')]
                if not bridge_stopped:
                    required.append(next(item for item in owned if item[0] == 'captions'))
                check_services(required)
                if relay.error:
                    raise RuntimeError(relay.error)
                record = sample(previous)
                previous = record
                speech = request('http://127.0.0.1:18080/api/speech/status')
                capture(speech)
                rvc = request('http://127.0.0.1:18090/api/status')
                record.update(elapsed_seconds=elapsed, relay=relay.status(), rvc_stream=rvc['stream'],
                    buffered_audio_seconds=speech.get('buffered_audio_seconds'),
                    audio_backlog_seconds=speech.get('audio_backlog_seconds'),
                    unfinished_jobs=speech.get('unfinished_jobs'), pending_jobs=speech.get('pending_jobs'))
                if speech.get('warmup_error') or speech.get('storage_warning'):
                    raise RuntimeError('Speech service reported runtime/storage failure')
                telemetry.write(json.dumps(record) + '\n')
                telemetry.flush()
                samples.append(record)
                save(output/'jobs.json', sorted(jobs.values(), key=lambda job: job['created_at']))
                save(output/'progress.json', {'status': 'draining' if bridge_stopped else 'running',
                    'elapsed_seconds': elapsed, 'source_seconds': source_seconds,
                    'job_states': dict(Counter(j['status'] for j in jobs.values())),
                    'archived_completed': len(copied), 'available_GiB': record['available_bytes']/1024**3,
                    'audio_backlog_seconds': record['audio_backlog_seconds'], 'relay': relay.status(), 'rvc_stream': rvc['stream']})
                if pre.poll() is not None:
                    if pre.returncode:
                        raise RuntimeError('Preprocessor failed: ' + str(pre.returncode))
                    if not bridge_stopped:
                        bridge.terminate()
                        bridge_stopped = True
                    if bridge.poll() is not None:
                        if bridge.returncode:
                            raise RuntimeError('Caption bridge failed: ' + str(bridge.returncode))
                        speech = request('http://127.0.0.1:18080/api/speech/status')
                        capture(speech)
                        if not speech['unfinished_jobs']:
                            save(runtime/'speech-results.json', speech)
                            save(output/'rvc-status.json', rvc)
                            break
                time.sleep(2)
        relay.close()
        if relay.error:
            raise RuntimeError(relay.error)
        if relay.sent != frames or relay.received != frames or relay.duplicate or relay.out_of_order:
            raise RuntimeError('UDP frame count/order mismatch: ' + json.dumps(relay.status()))
        packet_indices = np.fromfile(output/'rvc-packet-indices.bin', dtype='<u4')
        if not np.array_equal(packet_indices, np.arange(1, frames + 1, dtype=np.uint32)):
            raise RuntimeError('UDP frame indices differ from complete input sequence')
        packet_counts = re.findall(r'\[stt\] exit: packets=(\d+)', (runtime/'captions.log').read_text())
        if not packet_counts or int(packet_counts[-1]) != frames:
            raise RuntimeError('ASR input packet count differs from complete source')
        latest = {}
        for line in (runtime/'subtitles.jsonl').read_text().splitlines():
            row = json.loads(line)
            latest[row['seq']] = row
        if not latest or any(not row.get('final') or row.get('translation_status') != 'completed' or
                row.get('speech_error') for row in latest.values()):
            raise RuntimeError('Final source captions missing, incomplete or rejected')
        offered = [job_id for row in latest.values() for job_id in row.get('speech_jobs', [])]
        if not offered or set(offered) != set(jobs):
            raise RuntimeError('Caption speech task set differs from collected task set')
        if not jobs or any(job['status'] != 'completed' for job in jobs.values()):
            raise RuntimeError('Speech jobs missing or not all completed: ' +
                json.dumps(dict(Counter(job['status'] for job in jobs.values()))))
        stream = rvc['stream']
        rvc_errors = [key for key in ('inference_errors', 'late_blocks', 'input_overruns',
            'output_overruns', 'resets', 'skipped_blocks') if stream.get(key)]
        if stream['output_underruns'] != stream['startup_output_underruns']:
            rvc_errors.append('steady_state_output_underrun')
        if not stream['blocks'] or rvc_errors:
            raise RuntimeError('Realtime RVC acceptance failed: ' + json.dumps(rvc_errors))
        completed = True
    finally:
        failure = str(sys.exc_info()[1]) if sys.exc_info()[1] else None
        if relay.thread.ident is not None:
            relay.close()
        else:
            relay.incoming.close()
            relay.backend.close()
        cleanup_failures = []
        for name, process, log in reversed(owned):
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            if process.poll() is None:
                try:
                    process.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    cleanup_failures.append(name)
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
            deadline = time.monotonic() + 3
            while group_members(process.pid) and time.monotonic() < deadline:
                time.sleep(.1)
            if group_members(process.pid):
                cleanup_failures.append(name + ':descendants')
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            log.close()
        if database is not None:
            database.close()
        result = {'status': 'collected' if completed and not cleanup_failures else 'failed',
            'exit_code': 0 if completed and not cleanup_failures else 1, 'failure': failure,
            'forced_cleanup': cleanup_failures, 'elapsed_seconds': time.monotonic()-input_started if input_started else None,
            'source_seconds': source_seconds, 'relay': relay.status(),
            'job_states': dict(Counter(j['status'] for j in jobs.values())), 'archived_completed': len(copied),
            'minimum_available_GiB': min(r['available_bytes'] for r in samples)/1024**3 if samples else None,
            'maximum_backlog_seconds': max((r['audio_backlog_seconds'] or 0 for r in samples), default=None),
            'swap_used_bytes': stats([r['swap_used_bytes'] for r in samples]),
            'remaining_pids_before_cleanup': cleanup_failures}
        save(output/'jobs.json', sorted(jobs.values(), key=lambda job: job['created_at']))
        save(output/'exit-status.json', result)
        save(output/'progress.json', result)
        save(output/'archive-sha256.json', {p.name: digest(p) for p in archived.iterdir()})
    if not completed or cleanup_failures:
        raise RuntimeError('Soak failed; inspect exit-status.json')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
