"""比较原速中英文音频时长，并模拟纯播放时长造成的积压。"""
import argparse
import csv
import json
from pathlib import Path
import statistics
import sys

import numpy as np
import soundfile as sf

from run_soak import save

QUIET_DB = -40
QUIET_MIN_SECONDS = .15
ENERGY_HOP_SECONDS = .01


def describe(values):
    if not values:
        return None
    return {'count': len(values), 'median': statistics.median(values),
        'p90': float(np.percentile(values, 90)), 'p95': float(np.percentile(values, 95)),
        'min': min(values), 'max': max(values)}


def audio_metrics(path):
    pcm, rate = sf.read(path, dtype='float32', always_2d=True)
    seconds = len(pcm)/rate
    nonfinite = int(np.count_nonzero(~np.isfinite(pcm)))
    if nonfinite or not len(pcm):
        return {'samples': len(pcm), 'rate': rate, 'seconds': seconds,
            'low_energy_seconds': None, 'nonfinite_samples': nonfinite}
    power = np.mean(pcm.astype(np.float64)**2, axis=1)
    hop = round(rate*ENERGY_HOP_SECONDS)
    starts = np.arange(0, len(power), hop)
    counts = np.diff(np.append(starts, len(power)))
    rms = np.sqrt(np.add.reduceat(power, starts)/counts)
    quiet = rms <= 10**(QUIET_DB/20)
    edges = np.flatnonzero(np.diff(np.concatenate(([False], quiet, [False]))))
    quiet_samples = 0
    for begin, end in edges.reshape(-1, 2):
        samples = int(np.sum(counts[begin:end]))
        if samples/rate >= QUIET_MIN_SECONDS:
            quiet_samples += samples
    return {'samples': len(pcm), 'rate': rate, 'seconds': seconds,
        'low_energy_seconds': quiet_samples/rate, 'nonfinite_samples': nonfinite}


def duration_budget(pairs, speed):
    carry = 0.0
    waits = []
    signed_excess = 0.0
    for pair in pairs:
        excess = pair['english_seconds']/speed-pair['chinese_seconds']
        signed_excess += excess
        carry = max(0.0, carry+excess)
        waits.append(carry)
    return {'speed': speed, 'signed_total_excess_seconds': signed_excess,
        'maximum_unserved_seconds': max(waits, default=0), 'final_unserved_seconds': carry,
        'unserved_seconds_after_each_source_window': waits}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root, output = args.run.resolve(), args.output.resolve()
    sys.path.insert(0, str(args.repo.resolve()/'tools'))
    from tempo_control import DEFAULT_TEMPO_MAX
    rows = json.loads((root/'rows.json').read_text())
    protocol = json.loads((root/'protocol.json').read_text())
    output.mkdir(parents=True, exist_ok=False)
    pairs = []
    next_sample = 0
    expected_rate = round(protocol['source_samples']/protocol['source_seconds'])
    for row in rows:
        source = audio_metrics(root/'source-segments'/Path(row['source_audio']).name)
        if row['source_start_sample'] != next_sample or row['source_samples'] != source['samples'] or not source['samples'] or source['rate'] != expected_rate:
            raise ValueError('Source range/WAV sample mismatch: '+str(row['index']))
        next_sample += source['samples']
        pair = {'index': row['index'], 'source_start_seconds': row['source_start_seconds'],
            'chinese_seconds': source['seconds'], 'chinese_low_energy_seconds': source['low_energy_seconds'],
            'source_text': row['source_text'], 'translation': row.get('translation', ''),
            'quality_flags': row.get('quality_flags', {}), 'error': row.get('error'),
            'english_seconds': None, 'english_low_energy_seconds': None, 'ratio': None,
            'ratio_without_low_energy': None, 'excess_seconds': None,
            'synthesis_seconds': row.get('synthesis_seconds'), 'synthesis_rtf': None}
        if row.get('audio'):
            english = audio_metrics(root/'audio'/Path(row['audio']).name)
            pair.update(english_seconds=english['seconds'], english_low_energy_seconds=english['low_energy_seconds'],
                ratio=english['seconds']/source['seconds'], excess_seconds=english['seconds']-source['seconds'],
                english_nonfinite_samples=english['nonfinite_samples'], audio_empty=not english['samples'])
            if source['low_energy_seconds'] is not None and english['low_energy_seconds'] is not None:
                chinese_active = source['seconds']-source['low_energy_seconds']
                if chinese_active > 0:
                    pair['ratio_without_low_energy'] = (english['seconds']-english['low_energy_seconds'])/chinese_active
            if english['seconds'] and row.get('synthesis_seconds') is not None:
                pair['synthesis_rtf'] = row['synthesis_seconds']/english['seconds']
        pairs.append(pair)
    if next_sample != protocol['source_samples']:
        raise ValueError('Source windows do not cover the complete input')
    known = [pair for pair in pairs if pair['english_seconds'] is not None and not pair['audio_empty']]
    complete = len(known) == len(pairs) and bool(pairs)
    flags = [pair for pair in known if pair['error'] or any(pair['quality_flags'].values())]
    summary = {'source_segments': len(pairs), 'paired_audio_segments': len(known),
        'missing_audio_indices': [pair['index'] for pair in pairs if pair['english_seconds'] is None],
        'empty_audio_indices': [pair['index'] for pair in pairs if pair.get('audio_empty')],
        'nonfinite_audio_indices': [pair['index'] for pair in pairs if pair.get('english_nonfinite_samples', 0)],
        'source_samples_covered': next_sample, 'source_seconds_all': sum(p['chinese_seconds'] for p in pairs),
        'chinese_seconds_paired': sum(p['chinese_seconds'] for p in known),
        'english_seconds_paired': sum(p['english_seconds'] for p in known),
        'weighted_ratio_paired': sum(p['english_seconds'] for p in known)/sum(p['chinese_seconds'] for p in known) if known else None,
        'per_segment_ratio': describe([p['ratio'] for p in known]),
        'per_segment_ratio_without_low_energy': describe([p['ratio_without_low_energy'] for p in known if p['ratio_without_low_energy'] is not None]),
        'english_longer_segments': sum(p['ratio'] > 1 for p in known),
        'segments_above_tempo_cap': sum(p['ratio'] > DEFAULT_TEMPO_MAX for p in known), 'tempo_cap': DEFAULT_TEMPO_MAX,
        'synthesis_rtf': describe([p['synthesis_rtf'] for p in known if p['synthesis_rtf'] is not None]),
        'translation_flagged_or_error_paired_segments': len(flags),
        'synthesis_rtf_timing': 'From immediately before tts.generate through WAV writing and sample quality statistics, divided by generated WAV duration.',
        'largest_excess_indices': [p['index'] for p in sorted(known, key=lambda p:p['excess_seconds'], reverse=True)[:10]],
        'budget_model': {'definition': 'B_i=max(0,B_(i-1)+English_i/speed-Chinese_i). B_0=0.',
            'meaning': 'Counterfactual duration budget only; inference and observed playback timing excluded.',
            'computed': complete, 'reason': None if complete else 'missing_or_empty_audio_pairs',
            'runs': [duration_budget(pairs, speed) for speed in sorted({1.0, DEFAULT_TEMPO_MAX})] if complete else []},
        'low_energy_method': {'frame_seconds': ENERGY_HOP_SECONDS, 'threshold_dbfs': QUIET_DB,
            'minimum_interval_seconds': QUIET_MIN_SECONDS, 'meaning': 'Amplitude-based low-energy intervals; not speech recognition or VAD.'}}
    save(output/'pairs.json', pairs)
    save(output/'summary.json', summary)
    fields = ['index', 'source_start_seconds', 'chinese_seconds', 'english_seconds', 'ratio', 'excess_seconds',
        'chinese_low_energy_seconds', 'english_low_energy_seconds', 'ratio_without_low_energy',
        'synthesis_seconds', 'synthesis_rtf', 'source_text', 'translation', 'error', 'audio_empty', 'english_nonfinite_samples']
    with (output/'pairs.csv').open('w', newline='') as target:
        writer = csv.DictWriter(target, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(pairs)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
