#!/usr/bin/env bash
set -euo pipefail
run_root=/home/moyamryia/mozart-full-soak-20261019
repo_root=/home/moyamryia/mozart-efficiency-20261014/candidate
python_bin=/home/moyamryia/Mozart/.venv/bin/python
source_file=/home/moyamryia/mozart-full-soak-input.mp4
trap 'printf "%s\n" "$?" > "$run_root/controller-exit-code"' EXIT
"$python_bin" -u "$run_root/run_soak.py" --repo "$repo_root" --input "$source_file" \
  --seconds 20 --output "$run_root/preflight3" > "$run_root/preflight3-console.log" 2>&1
cd "$repo_root"
export PATH="$repo_root/.venv/bin:$PATH"
bash tools/ci-local.sh python > "$run_root/python-regression.log" 2>&1
"$python_bin" -u "$run_root/run_soak.py" --repo "$repo_root" --input "$source_file" \
  --output "$run_root/full" > "$run_root/full-console.log" 2>&1
