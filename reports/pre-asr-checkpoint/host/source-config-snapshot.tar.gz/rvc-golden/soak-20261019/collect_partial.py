"""核对失败长测中已完成的音频，保存独立试听产物。"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import wave


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


root, repo = map(Path, sys.argv[1:])
jobs = json.loads((root/'jobs.json').read_text())
completed = sorted((j for j in jobs if j['status'] == 'completed'), key=lambda j: j['created_at'])
if not completed:
    raise RuntimeError('No completed audio to collect')
verification = root/'completed-verification'
verification.mkdir(exist_ok=False)
(verification/'speech').symlink_to(root/'speech', target_is_directory=True)
(verification/'jobs.json').write_text(json.dumps(completed, ensure_ascii=False, indent=2)+'\n')
with (verification/'console.log').open('w') as log:
    code = subprocess.run([sys.executable, str(repo/'rvc-golden/verify_tempo_playback.py'),
        '--replay', str(verification), '--output', str(verification/'verification.json')],
        stdout=log, stderr=subprocess.STDOUT).returncode
archive = root/'speech/results'
expected = json.loads((root/'archive-sha256.json').read_text())
mismatches = [name for name, checksum in expected.items() if digest(archive/name) != checksum]
if mismatches:
    raise RuntimeError('Archive hash mismatch: '+str(mismatches))
preview = root/'preview'
preview.mkdir(exist_ok=False)
combined = preview/'completed-playback.wav'
segments = []
offset = 0
with wave.open(str(combined), 'wb') as output:
    settings = None
    for job in completed:
        path = archive/job.get('playback_audio_filename', job['id']+'.wav')
        with wave.open(str(path), 'rb') as audio:
            actual = (audio.getnchannels(), audio.getsampwidth(), audio.getframerate())
            if settings is None:
                settings = actual
                output.setnchannels(actual[0])
                output.setsampwidth(actual[1])
                output.setframerate(actual[2])
            if actual != settings:
                raise RuntimeError('Mismatched playback WAV format')
            if not audio.getnframes():
                raise RuntimeError('Empty completed playback WAV')
            duration = audio.getnframes()/audio.getframerate()
            output.writeframes(audio.readframes(audio.getnframes()))
        segments.append({'job_id': job['id'], 'source_text': job.get('source_text'), 'text': job['text'],
            'offset_seconds': offset, 'duration_seconds': duration, 'filename': path.name})
        offset += duration
(preview/'segments.json').write_text(json.dumps(segments, ensure_ascii=False, indent=2)+'\n')
for source, name in [(combined, 'completed-playback.mp3'), (root/'processed-input.wav', 'processed-input.mp3'),
                     (root/'qiqi-mozart-backend.wav', 'qiqi-mozart-backend.mp3')]:
    subprocess.run(['ffmpeg', '-v', 'error', '-nostdin', '-i', str(source), '-ac', '1',
        '-c:a', 'libmp3lame', '-b:a', '48k', str(preview/name)], check=True)
receipt = {'complete_run_passed': False, 'observed_jobs': len(jobs), 'completed_jobs': len(completed),
    'verification_subset': 'All jobs marked completed in the last observed snapshot; other states retained in original jobs.json',
    'verification_exit_code': code, 'archive_files_checked': len(expected), 'archive_hash_mismatches': mismatches,
    'combined_playback_seconds': offset, 'combined_omits_original_gaps_and_incomplete_jobs': True,
    'preview_sha256': {p.name: digest(p) for p in preview.iterdir()}}
(root/'partial-collection.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(receipt, ensure_ascii=False, indent=2))
if code:
    raise RuntimeError('Independent playback verification failed; original failure retained')
