"""使用离线英文识别检查超长合成音频，保留分窗识别原文。"""
import argparse
from pathlib import Path

import soundfile as sf
import sherpa_onnx as so

from run_soak import digest, save

WINDOW_SECONDS = 15


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(exist_ok=False)
    recognizer = so.OfflineRecognizer.from_sense_voice(model=str(args.model/'model.int8.onnx'),
        tokens=str(args.model/'tokens.txt'), num_threads=2, language='en', use_itn=True)
    results = []
    for index in [108, 117, 126]:
        path = args.run/'audio'/f'{index:05d}.wav'
        with sf.SoundFile(path) as audio:
            for begin in range(0, len(audio), WINDOW_SECONDS*audio.samplerate):
                pcm = audio.read(WINDOW_SECONDS*audio.samplerate, dtype='float32')
                stream = recognizer.create_stream()
                stream.accept_waveform(audio.samplerate, pcm)
                recognizer.decode_stream(stream)
                results.append({'index': index, 'start_seconds': begin/audio.samplerate,
                    'seconds': len(pcm)/audio.samplerate, 'text': stream.result.text})
    save(args.output/'rows.json', results)
    save(args.output/'protocol.json', {'recognizer_model': str(args.model), 'language': 'en',
        'window_seconds': WINDOW_SECONDS, 'runtime': so.__version__, 'harness_sha256': digest(Path(__file__)),
        'meaning': 'Automatic retranscription of generated WAV; human listening judgment is separate.'})


if __name__ == '__main__':
    main()
