# 完整文件长测续接

用户于 2026-10-19 授权使用 `test-audio.mp4`，完整回放约 69 分 46 秒。
用户已用后续消息取消一小时截断。

## 运行位置

- 本机项目：`/home/moyamryia/Projects/Project-Mozart`。
- SSH：`jetson-wg`。
- 板端候选：`/home/moyamryia/mozart-efficiency-20261014/candidate`。
- 板端测试：`/home/moyamryia/mozart-full-soak-20261019`。
- tmux：`mozart_full_soak_20261019`。
- 心跳：`mozart`，绑定当前对话，每 10 分钟检查。
- 输入：`/home/moyamryia/mozart-full-soak-input.mp4`。
- 输入 SHA-256：`2b80f2d78c59c530b53cb96e8a8aef9852f169231f312a67ce352a19db61b389`。

## 控制器

`launch.sh` 先运行独立 `preflight3`，再运行 Python 回归，最后运行 `full`。
`controller-exit-code` 仅在控制器结束后出现。
正式运行期间读取 `full/progress.json` 和 `full/protocol.json`。
正常推进时保持安静。不要重复启动正常测试。

预检第一次因候选缺少默认 RNNoise 资产而失败，已显式传入原应用的资产路径。
预检第二次完成双路 1151 帧和 6 个播报任务，末端任务集合检查错误使夹具失败。
该类型错误已修复。原始预检目录保持原样。

`preflight3` 已通过：1151/1151 个输入和输出包，6/6 个播报任务，清理无残留。
随后板端 Python 回归 217/217 通过，耗时 17.723 s。
`full` 已启动；初始检查为 101/101 个包、8 个 RVC 块和零推理错误。
写作 lint 与 diff 空白检查通过。
当前脚本 SHA-256 为 `96ab50f4ad09c3c137ca3d3d13085a98bafe344ebb0d76b2d9125c7b577e7430`。
正式输入于新加坡时间 10:23:40 开始，预计 11:33:29 输入完毕。
排空截止时间为 11:48:29。该时间包含协议中的 900 s 排空预算。

2026-10-19 后续检查确认正式运行已失败，服务于 10:32:41 前后退出。
后端 UDP 记录 recv=26854、sent=26850、dropped=4，严格序号检查触发停止。
没有重新启动原负载。全部服务已清理。
结果报告为 `reports/soak-20261019/RESULTS.md`。
160 个完成任务中，157 个变速捕获独立 FFmpeg 核验通过。
全部 160 个原速任务与按序片段拼接一致。3206 个归档文件哈希一致。
三份 MP3 试听副本和小型证据已同步到本机 `rvc-golden/soak-20261019/full`。
结果报告和证据链接已检查，写作 lint 通过。心跳 `mozart` 已暂停。

测试只修改候选目录中的 `tools/stt_service.py`：退出包数诊断定向 `stderr`。
该诊断原来进入机器读取的标准输出，被字幕桥丢弃。
本机同一行改动尚未提交。原应用目录没有修改。
`reviewer` 已审查脚本及该行改动，问题已修复。

## 正式配置

同一个 `mozart-pre` 以 20 ms 节拍回放完整文件，并执行默认 RNNoise、VAD、高通和重采样。
预处理器把同一个契约包发送给实时 RVC 和 ASR。
UDP 中继保存处理后输入、RVC 输出和全部返回包序号。
输入末尾附加 3 s 静音，并补齐 960 采样帧。

实时 RVC 使用既有 Qiqi TensorRT 配置，240 ms 块、2.5 s 历史和 400 ms 启动预算。
ASR 使用 Zipformer；翻译使用 Qwen3.5-0.8B Q4_K_M。
PocketTTS 使用 CPU int8、2 线程、5 步、早期输出 3 帧。
播报使用灵活变速，最大 1.15 倍，覆盖率优先。
播放为按采样数计时的 ALSA `null`。
输入结束后，队列排空预算为 900 s。

脚本每 2 s 记录 CPU、进程、可用内存、swap、积压和 RVC 状态。
脚本读取语音 SQLite 的全部当前行，持续保存任务及完整音频，避免最近 128 项接口造成遗漏。
完成任务的原速 WAV、片段 WAV、变速捕获及 JSON 保存在 `full/speech/results`。
完整语音服务数据保存在 `full/service-data`。

## 结束后处理

1. 读取退出状态和全部失败日志。
2. 核对全部输入帧、RVC 包序号和 ASR 退出包数。
3. 按全部最终源字幕统计覆盖率、错误、未播报项和任务完成率。
4. 解析 `runtime/rvc.log` 中的 profile 时间。
5. 统计欠载、迟到、跳块、采集溢出、积压、内存及 swap。
6. 使用 `verify_tempo_playback.py --replay full --output verification.json` 独立核对默认 FFmpeg 输出。
7. 合并完成的播报音频，并保存片段偏移清单。
8. 先收集小型记录与校验和到本机，再提供音频预览。
9. 写入 `reports/soak-20261019/RESULTS.md`。
10. 运行 `tools/writing_lint.py`，汇报后暂停心跳 `mozart`。

`analyze_clauses.py` 可复用大部分分析；其 `native_frames` 正则需要核对实际日志。
当前脚本的退出状态使用 `collected` 表示执行与基本门控通过。
独立音频比较和语义核对完成后，才能给出相应验收结论。
业务失败是有效结果。保留失败记录，不放宽门控，不删句重算分母。
只修复有明确证据的夹具错误，并使用新尝试目录。
不要提交、推送或合并 PR。

## 适用范围

- 配置：上述 Jetson 组合负载与静默播放设备。
- 样本：一个完整固定输入；短预检单独记录。
- 人工语义与听感未验证。阻塞：缺少人工核对。解除条件：试听并记录逐句结果。
- 物理声卡延迟未验证。阻塞：本次使用 ALSA null。解除条件：执行物理回环录音计时。
