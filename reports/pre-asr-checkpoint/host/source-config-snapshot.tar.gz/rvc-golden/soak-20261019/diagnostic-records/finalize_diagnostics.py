"""核对诊断归档，保留逐段证据并生成试听副本。"""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
import subprocess

import numpy as np
import soundfile as sf

from analyze_duration_pairs import describe, duration_budget
from run_soak import digest, save


def waveform_metrics(path):
    peak, nonfinite, over, samples = 0.0, 0, 0, 0
    with sf.SoundFile(path) as audio:
        rate, channels = audio.samplerate, audio.channels
        for pcm in audio.blocks(blocksize=262144, dtype='float32', always_2d=True):
            finite = np.isfinite(pcm)
            nonfinite += int(np.count_nonzero(~finite))
            over += int(np.count_nonzero(np.abs(pcm) > 1))
            if finite.any():
                peak = max(peak, float(np.max(np.abs(pcm[finite]))))
            samples += len(pcm)
    return {'samples': samples, 'rate': rate, 'channels': channels, 'seconds': samples/rate,
        'finite_peak': peak, 'nonfinite_samples': nonfinite, 'over_fullscale_samples': over}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--checks-only', action='store_true')
    args = parser.parse_args()
    base = args.base.resolve()
    out = args.output.resolve() if args.output else base/'derived-checks'
    out.mkdir(exist_ok=False)
    rvc, static = base/'rvc-only-full', base/'static-full'
    rows = json.loads((static/'rows.json').read_text())
    pairs = json.loads((static/'duration-analysis/pairs.json').read_text())
    summary = json.loads((static/'duration-analysis/summary.json').read_text())
    source_checks, audio_checks, manifest = [], [], []
    with sf.SoundFile(static/'input-16k.wav') as decoded, sf.SoundFile(static/'translated-speech-combined.wav') as combined:
        for row in rows:
            source, rate = sf.read(row['source_audio'], dtype='float32')
            original = decoded.read(len(source), dtype='float32')
            source_checks.append({'index': row['index'], 'samples': len(source),
                'exact': rate == decoded.samplerate and np.array_equal(source, original)})
            if row.get('audio'):
                path = Path(row['audio'])
                metrics = waveform_metrics(path)
                pcm, rate = sf.read(path, dtype='float32')
                offset_matches = combined.tell()/combined.samplerate == row['combined_start_seconds']
                ordered = combined.read(len(pcm), dtype='float32')
                audio_checks.append({'index': row['index'], **metrics,
                    'metadata_matches': metrics['samples'] == row['audio_samples'] and rate == row['audio_rate'],
                    'combined_exact': rate == combined.samplerate and np.array_equal(pcm, ordered),
                    'offset_matches': offset_matches,
                    'combined_start_seconds': row['combined_start_seconds']})
        source_exhausted = decoded.tell() == len(decoded)
        combined_exhausted = combined.tell() == len(combined)
    save(out/'source-window-checks.json', source_checks)
    save(out/'ordered-audio-checks.json', audio_checks)
    for stage in [rvc, static]:
        for path in sorted(stage.rglob('*')):
            if path.is_file():
                manifest.append({'path': str(path.relative_to(base)), 'bytes': path.stat().st_size, 'sha256': digest(path)})
    save(out/'archive-sha256.json', manifest)
    indices = np.fromfile(rvc/'rvc-packet-indices.bin', dtype='<u4')
    telemetry = [json.loads(line) for line in (rvc/'telemetry.jsonl').read_text().splitlines()]
    log = (rvc/'rvc.log').read_text()
    profiles = {}
    for tag in ['realtime', 'stream']:
        values = [float(v) for v in re.findall(r'\[profile\]\['+tag+r'\][^\n]* total=([0-9.]+)ms', log)]
        profiles[tag] = {**describe(values), 'unit': 'ms'} if values else None
    blocks, current = [], []
    for pair in pairs:
        if pair['english_seconds'] is None or pair.get('audio_empty'):
            if current:
                blocks.append(current)
                current = []
        else:
            current.append(pair)
    if current:
        blocks.append(current)
    budgets = [{'first_index': block[0]['index'], 'last_index': block[-1]['index'],
        'segments': len(block), 'chinese_seconds': sum(p['chinese_seconds'] for p in block),
        'runs': [duration_budget(block, speed) for speed in sorted({1.0, summary['tempo_cap']})]} for block in blocks]
    long_runs = []
    for threshold in sorted({1.0, summary['tempo_cap']}):
        start, group = None, []
        for pair in pairs+[{'ratio': None}]:
            if pair['ratio'] is not None and pair['ratio'] > threshold:
                if start is None:
                    start = pair['index']
                group.append(pair)
            elif group:
                long_runs.append({'threshold': threshold, 'first_index': start, 'last_index': group[-1]['index'],
                    'segments': len(group), 'source_seconds': sum(p['chinese_seconds'] for p in group),
                    'excess_at_threshold_seconds': sum(p['english_seconds']/threshold-p['chinese_seconds'] for p in group)})
                start, group = None, []
    save(out/'contiguous-duration-budgets.json', budgets)
    save(out/'consecutive-long-runs.json', long_runs)
    known = [p for p in pairs if p['english_seconds'] is not None and not p.get('audio_empty')]
    groups = {}
    for label, group in [('flagged', [p for p in known if any(p['quality_flags'].values())]),
                         ('without_flags', [p for p in known if not any(p['quality_flags'].values())])]:
        groups[label] = {'segments': len(group), 'chinese_seconds': sum(p['chinese_seconds'] for p in group),
            'english_seconds': sum(p['english_seconds'] for p in group),
            'ratio_distribution': describe([p['ratio'] for p in group])}
    first, last = telemetry[0], telemetry[-1]
    result = {'source_window_checks': len(source_checks), 'source_windows_exact': all(p['exact'] for p in source_checks),
        'source_exhausted': source_exhausted, 'audio_checks': len(audio_checks),
        'audio_metadata_matches': all(p['metadata_matches'] for p in audio_checks),
        'combined_exact': all(p['combined_exact'] for p in audio_checks), 'combined_exhausted': combined_exhausted,
        'combined_offsets_match': all(p['offset_matches'] for p in audio_checks),
        'audio_nonfinite_samples': sum(p['nonfinite_samples'] for p in audio_checks),
        'audio_over_fullscale_samples': sum(p['over_fullscale_samples'] for p in audio_checks),
        'audio_over_fullscale_segments': sum(p['over_fullscale_samples'] > 0 for p in audio_checks),
        'audio_peak': max(p['finite_peak'] for p in audio_checks),
        'rvc_packet_indices': {'count': len(indices), 'first': int(indices[0]), 'last': int(indices[-1]),
            'exact_1_to_expected': bool(np.array_equal(indices, np.arange(1, json.loads((rvc/'protocol.json').read_text())['expected_frames']+1, dtype='<u4')))},
        'rvc_audio': waveform_metrics(rvc/'qiqi-mozart-backend.wav'),
        'rvc_input': waveform_metrics(rvc/'processed-input.wav'), 'profiles': profiles,
        'telemetry_samples': len(telemetry), 'minimum_available_GiB': min(p['available_bytes'] for p in telemetry)/2**30,
        'swap_used_first_bytes': first['swap_used_bytes'], 'swap_used_last_bytes': last['swap_used_bytes'],
        'swap_used_delta_bytes': last['swap_used_bytes']-first['swap_used_bytes'],
        'swap_in_delta_pages': last['pswpin']-first['pswpin'], 'swap_out_delta_pages': last['pswpout']-first['pswpout'],
        'quality_flag_counts': dict(Counter(k for row in rows for k, value in row.get('quality_flags', {}).items() if value)),
        'timing_totals_seconds': {key: sum(row.get(key, 0) for row in rows) for key in ['asr_seconds', 'translation_seconds', 'synthesis_seconds']},
        'quality_groups': groups, 'missing_audio_indices': summary['missing_audio_indices'],
        'harness_sha256': digest(Path(__file__))}
    save(out/'summary.json', result)
    integrity_keys = ['source_windows_exact', 'source_exhausted', 'audio_metadata_matches', 'combined_exact', 'combined_exhausted', 'combined_offsets_match']
    failed_integrity = [key for key in integrity_keys if not result[key]]
    if failed_integrity:
        raise RuntimeError('Archive integrity failed: '+', '.join(failed_integrity))
    if args.checks_only:
        return
    preview = out/'preview'
    preview.mkdir()
    tracks = [('rvc-full', rvc/'qiqi-mozart-backend.wav'), ('static-full', static/'translated-speech-combined.wav')]
    for index in [0, 108, 117, 126]:
        tracks.extend([(f'{index:05d}-chinese', Path(rows[index]['source_audio'])),
                       (f'{index:05d}-english', Path(rows[index]['audio']))])
    for name, source in tracks:
        subprocess.run(['ffmpeg', '-v', 'error', '-nostdin', '-i', str(source), '-codec:a', 'libmp3lame',
            '-b:a', '64k', str(preview/(name+'.mp3'))], check=True)
    save(out/'preview-sha256.json', [{'path': str(p.relative_to(out)), 'sha256': digest(p), 'bytes': p.stat().st_size} for p in sorted(preview.iterdir())])
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
