#!/usr/bin/env bash
set -u
run_root=/home/moyamryia/mozart-full-soak-20261019
repo_root=/home/moyamryia/mozart-efficiency-20261014/candidate
python_bin=/home/moyamryia/Mozart/.venv/bin/python
trap 'printf "%s\n" "$?" > "$run_root/diagnostics-controller-exit-code"' EXIT
"$python_bin" -u "$run_root/run_rvc_only.py" --repo "$repo_root" --previous "$run_root/full" \
  --output "$run_root/rvc-only-preflight" --frames 1000 --diagnostic > "$run_root/rvc-only-preflight-console.log" 2>&1
preflight_code=$?
if [ "$preflight_code" -ne 0 ]; then
  exit "$preflight_code"
fi
"$python_bin" -u "$run_root/run_rvc_only.py" --repo "$repo_root" --previous "$run_root/full" \
  --output "$run_root/rvc-only-full" --diagnostic > "$run_root/rvc-only-full-console.log" 2>&1
rvc_code=$?
printf '%s\n' "$rvc_code" > "$run_root/rvc-only-exit-code"
"$python_bin" -u "$run_root/offline_static.py" --repo "$repo_root" --input /home/moyamryia/mozart-full-soak-input.mp4 \
  --output "$run_root/static-full" > "$run_root/static-full-console.log" 2>&1
static_code=$?
printf '%s\n' "$static_code" > "$run_root/static-exit-code"
if [ "$rvc_code" -ne 0 ] || [ "$static_code" -ne 0 ]; then
  exit 1
fi
