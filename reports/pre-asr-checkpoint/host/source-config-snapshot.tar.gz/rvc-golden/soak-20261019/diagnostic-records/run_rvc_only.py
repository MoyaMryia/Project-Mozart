"""使用既有完整输入执行独立实时变声长测。"""
import argparse
import fcntl
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import wave

import numpy as np

from run_soak import Relay, digest, request, save
from diagnostic_relay import DiagnosticRelay


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--previous', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--frames', type=int, help='独立短预检的帧数；默认使用完整输入。')
    parser.add_argument('--diagnostic', action='store_true', help='记录质量问题并继续完整输入。')
    args = parser.parse_args()
    repo, previous, output = args.repo.resolve(), args.previous.resolve(), args.output.resolve()
    decoded = previous/'input-48k-stereo.wav'
    with wave.open(str(decoded), 'rb') as source:
        total_frames = source.getnframes() // 960
    if args.frames is not None and not 0 < args.frames <= total_frames:
        parser.error('frames must be positive and within the retained input')
    frames = total_frames if args.frames is None else args.frames
    output.mkdir(parents=True, exist_ok=False)
    sys.path[:0] = [str(repo/'tools'), str(repo/'rvc-golden/realtime-patches-20261008')]
    from run_probe import sample
    from run_translated_speech import assert_ports_available, check_services
    lock = (Path.home()/'Mozart/rvc-golden/reliability-20261006/active-test.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert_ports_available([(18090, socket.SOCK_STREAM), (18010, socket.SOCK_DGRAM), (18020, socket.SOCK_DGRAM)])
    config = json.loads((previous/'rvc-backend.json').read_text())
    config['storage']['temp_dir'] = str(output/'temp')
    config['storage']['presets_path'] = str(output/'presets.json')
    save(output/'backend.json', config)
    binary = repo/'build-gpu/state/mozart_stated'
    rnnoise = Path.home()/'Mozart/preprocessor/assets/rnnoise_default.rnnb'
    commands = {'rvc': [str(binary), str(output/'backend.json')],
        'preprocessor': [str(repo/'build-gpu/preprocessor/mozart-pre'), '-i', str(decoded), '--pace',
            '-a', '127.0.0.1', '-p', '18020', '-o', 'null', '-n', str(frames), '--model', str(rnnoise)]}
    protocol = {'commands': commands, 'input': str(decoded), 'input_sha256': digest(decoded),
        'original_protocol': json.loads((previous/'protocol.json').read_text()),
        'expected_frames': frames, 'paced_input_seconds': frames*.02,
        'mode': 'complete-file-rvc-only' if args.frames is None else 'short-preflight-rvc-only',
        'harness_sha256': digest(Path(__file__)), 'relay_sha256': digest(Path(__file__).with_name('run_soak.py')),
        'diagnostic': args.diagnostic, 'diagnostic_relay_sha256': digest(Path(__file__).with_name('diagnostic_relay.py')),
        'binary_sha256': digest(binary), 'preprocessor_sha256': digest(repo/'build-gpu/preprocessor/mozart-pre'),
        'rnnoise_sha256': digest(rnnoise), 'started_at': time.time(),
        'topology': 'Native preprocessing, UDP relay and realtime RVC; ALSA null output; no ASR/translation/TTS.'}
    save(output/'protocol.json', protocol)
    owned, samples = [], []
    relay = DiagnosticRelay(output) if args.diagnostic else Relay(output)
    started = None
    passed = False
    findings = []
    def stop(*_):
        raise KeyboardInterrupt('RVC-only test interrupted')
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    def launch(name):
        environment = dict(os.environ, MOZART_RVC_PROFILE='1',
            MOZART_RVC_DEVICE_CHAIN='1', MOZART_RVC_PARALLEL_FEATURES='1')
        log = (output/(name+'.log')).open('w')
        process = subprocess.Popen(commands[name], cwd=repo, env=environment,
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        owned.append((name, process, log))
        save(output/'pids.json', {'harness': os.getpid(), **{n: p.pid for n, p, _ in owned}})
        return process
    def group_members(group):
        members = []
        for path in Path('/proc').iterdir():
            if not path.name.isdigit():
                continue
            try:
                fields = (path/'stat').read_text().rsplit(')', 1)[1].split()
            except (FileNotFoundError, ProcessLookupError):
                continue
            if int(fields[2]) == group and fields[0] != 'Z':
                members.append(int(path.name))
        return members
    try:
        backend = launch('rvc')
        deadline = time.monotonic()+90
        while time.monotonic() < deadline:
            check_services(owned)
            try:
                request('http://127.0.0.1:18090/api/status')
                break
            except OSError:
                time.sleep(.2)
        else:
            raise TimeoutError('RVC startup timed out')
        active = request('http://127.0.0.1:18090/api/mode/switch', {'mode': 'rt_rvc', 'model_id': 'qiqi-zh-realtime'})
        if active.get('status') != 'active':
            raise RuntimeError('RVC activation failed: '+json.dumps(active))
        relay.thread.start()
        pre = launch('preprocessor')
        started = time.monotonic()
        protocol.update(input_started_at=time.time(), expected_input_end_at=time.time()+frames*.02)
        save(output/'protocol.json', protocol)
        last = {}
        with (output/'telemetry.jsonl').open('w') as telemetry:
            while True:
                check_services([owned[0]])
                if relay.error:
                    raise RuntimeError(relay.error)
                elapsed = time.monotonic()-started
                if elapsed > frames*.02+120:
                    raise TimeoutError('RVC-only replay watchdog expired')
                status = request('http://127.0.0.1:18090/api/status')
                record = sample(last)
                last = record
                record.update(elapsed_seconds=elapsed, relay=relay.status(), stream=status['stream'])
                samples.append(record)
                telemetry.write(json.dumps(record)+'\n')
                telemetry.flush()
                save(output/'status.json', status)
                save(output/'progress.json', {'status': 'running', 'elapsed_seconds': elapsed,
                    'expected_frames': frames, 'relay': relay.status(), 'stream': status['stream'],
                    'available_GiB': record['available_bytes']/1024**3})
                if pre.poll() is not None:
                    if pre.returncode:
                        raise RuntimeError('Preprocessor failed: '+str(pre.returncode))
                    deadline = time.monotonic()+10
                    while relay.received < relay.sent and not relay.error and time.monotonic() < deadline:
                        time.sleep(.1)
                    break
                time.sleep(2)
        relay.close()
        if relay.error:
            raise RuntimeError(relay.error)
        if relay.sent != frames or relay.received != frames:
            findings.append('full_file_packet_count_mismatch')
        indices = np.fromfile(output/'rvc-packet-indices.bin', dtype='<u4')
        if not np.array_equal(indices, np.arange(1, frames+1, dtype=np.uint32)):
            findings.append('output_packet_sequence_mismatch')
        status = request('http://127.0.0.1:18090/api/status')
        save(output/'status.json', status)
        stream = status['stream']
        errors = [key for key in ('inference_errors', 'late_blocks', 'input_overruns',
            'output_overruns', 'resets', 'skipped_blocks') if stream.get(key)]
        if stream['output_underruns'] != stream['startup_output_underruns']:
            errors.append('steady_state_output_underrun')
        findings.extend(errors)
        if not stream['blocks']:
            findings.append('no_inference_blocks')
        findings.extend(key for key, value in relay.status().items() if key in
            ('input_bad', 'input_gaps', 'bad', 'output_gaps', 'duplicate', 'out_of_order', 'nonfinite_samples') and value)
        if findings and not args.diagnostic:
            raise RuntimeError('RVC-only acceptance failed: '+json.dumps(findings))
        passed = True
    finally:
        failure = str(sys.exc_info()[1]) if sys.exc_info()[1] else None
        if relay.thread.ident is not None:
            relay.close()
        else:
            relay.incoming.close()
            relay.backend.close()
        forced = []
        for name, process, log in reversed(owned):
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            if process.poll() is None:
                try:
                    process.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    forced.append(name)
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
            deadline = time.monotonic()+3
            while group_members(process.pid) and time.monotonic() < deadline:
                time.sleep(.1)
            if group_members(process.pid):
                forced.append(name+':descendants')
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            log.close()
        result = {'status': ('completed_with_findings' if findings else 'completed') if passed and not forced else 'failed',
            'exit_code': 0 if passed and not forced else 1, 'failure': failure, 'forced_cleanup': forced,
            'quality_gate_enforced': not args.diagnostic,
            'strict_acceptance_passed': not args.diagnostic and passed and not findings and not forced,
            'findings': findings,
            'elapsed_seconds': time.monotonic()-started if started else None,
            'expected_frames': frames, 'relay': relay.status(),
            'minimum_available_GiB': min(s['available_bytes'] for s in samples)/1024**3 if samples else None}
        save(output/'exit-status.json', result)
        save(output/'progress.json', result)
    if not passed or forced:
        raise RuntimeError('RVC-only test failed; inspect exit-status.json')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
