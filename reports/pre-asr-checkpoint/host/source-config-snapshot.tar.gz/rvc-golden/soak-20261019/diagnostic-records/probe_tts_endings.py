"""固定文本和种子，对照省略号与句号的完整合成输出。"""
import argparse
import json
from pathlib import Path
import time

import numpy as np
import soundfile as sf
import sherpa_onnx as so

from run_soak import digest, save


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    rows = json.loads((args.run/'rows.json').read_text())
    selected = [rows[index] for index in [117, 126]]
    for row in selected:
        if not row['translation'].endswith('...'):
            raise ValueError('Expected source translation ending: '+str(row['index']))
    args.output.mkdir(exist_ok=False)
    home = Path.home()
    model = home/'models/sherpa-onnx/clone-test-downloads/sherpa-onnx-pocket-tts-int8-2026-01-26'
    pocket = so.OfflineTtsPocketModelConfig(**{key: str(model/name) for key, name in {
        'lm_flow': 'lm_flow.int8.onnx', 'lm_main': 'lm_main.int8.onnx', 'encoder': 'encoder.onnx',
        'decoder': 'decoder.int8.onnx', 'text_conditioner': 'text_conditioner.onnx',
        'vocab_json': 'vocab.json', 'token_scores_json': 'token_scores.json'}.items()})
    tts = so.OfflineTts(so.OfflineTtsConfig(model=so.OfflineTtsModelConfig(pocket=pocket, num_threads=2, provider='cpu')))
    reference = home/'Mozart/rvc-golden/clone-tts/qiqi-20261004/reference-qiqi-natural-source.wav'
    ref, rate = sf.read(reference, dtype='float32')
    protocol = {'runtime': so.__version__, 'model': str(model), 'reference_sha256': digest(reference),
        'threads': 2, 'num_steps': 5, 'seed': 42, 'speed': 1, 'early_audio': False,
        'max_frames_override': None, 'harness_sha256': digest(Path(__file__)),
        'change': 'Only final three periods become one period; original text is also synthesized once.'}
    save(args.output/'protocol.json', protocol)
    results = []
    for row in selected:
        for variant, text in [('original', row['translation']), ('period', row['translation'][:-3]+'.')]:
            config = so.GenerationConfig()
            config.reference_audio, config.reference_sample_rate = ref, rate
            config.reference_text = ''
            config.num_steps, config.speed, config.silence_scale = 5, 1, 1
            config.extra = {'seed': '42'}
            record = {'index': row['index'], 'variant': variant, 'text': text}
            began = time.monotonic()
            try:
                audio = tts.generate(text, config)
                pcm = np.asarray(audio.samples, dtype='float32')
                path = args.output/f"{row['index']:05d}-{variant}.wav"
                sf.write(path, pcm, audio.sample_rate, subtype='FLOAT')
                baseline, baseline_rate = sf.read(row['audio'], dtype='float32')
                record.update(audio=str(path), samples=len(pcm), rate=audio.sample_rate,
                    seconds=len(pcm)/audio.sample_rate, sha256=digest(path),
                    exact_baseline_pcm=baseline_rate == audio.sample_rate and np.array_equal(pcm, baseline),
                    nonfinite_samples=int(np.count_nonzero(~np.isfinite(pcm))),
                    over_fullscale_samples=int(np.count_nonzero(np.abs(pcm)>1)))
            except RuntimeError as error:
                record['error'] = str(error)
            record['elapsed_seconds'] = time.monotonic()-began
            results.append(record)
            save(args.output/'rows.json', results)


if __name__ == '__main__':
    main()
