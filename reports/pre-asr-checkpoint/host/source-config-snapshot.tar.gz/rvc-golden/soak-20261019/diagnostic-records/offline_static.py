"""离线识别、整段翻译与完整音频合成；质量标记仅供观察。"""
import argparse
import gc
import fcntl
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

import numpy as np
import soundfile as sf

from run_soak import digest, request, save


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seconds', type=float, help='独立短预检的输入秒数。')
    args = parser.parse_args()
    if args.seconds is not None and (not np.isfinite(args.seconds) or args.seconds <= 0):
        parser.error('seconds must be finite and positive')
    repo, output, home = args.repo.resolve(), args.output.resolve(), Path.home()
    campaign_lock = (home/'Mozart/rvc-golden/reliability-20261006/active-test.lock').open('a')
    fcntl.flock(campaign_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    output.mkdir(parents=True, exist_ok=False)
    (output/'source-segments').mkdir()
    (output/'audio').mkdir()
    sys.path.insert(0, str(repo/'tools'))
    from subtitle_bridge import SYSTEM_PROMPT, missing_numbers, repeated_numbers, added_large_numbers, request_json
    from run_translated_speech import assert_ports_available
    import sherpa_onnx as so
    assets = home/'models/sherpa-onnx/clone-test-downloads'
    recognizer_model = assets/'sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17'
    pocket_model = assets/'sherpa-onnx-pocket-tts-int8-2026-01-26'
    reference = home/'Mozart/rvc-golden/clone-tts/qiqi-20261004/reference-qiqi-natural-source.wav'
    binary = home/'mozart-archive/qwen35/llama.cpp/build-cuda-bin/llama-server'
    decoded = output/'input-16k.wav'
    command = ['ffmpeg', '-v', 'error', '-nostdin', '-i', str(args.input)]
    if args.seconds is not None:
        command += ['-t', str(args.seconds)]
    command += ['-ar', '16000', '-ac', '1', '-c:a', 'pcm_s16le', str(decoded)]
    subprocess.run(command, check=True, timeout=180)
    info = sf.info(decoded)
    protocol = {'input': str(args.input), 'input_sha256': digest(args.input),
        'source_seconds': info.duration, 'source_samples': info.frames, 'mode': 'offline-output-diagnostic',
        'quality_gate_enforced': False, 'strict_acceptance_passed': False,
        'recognizer': str(recognizer_model), 'translator': 'Qwen3.5-0.8B Q4_K_M',
        'tts_model': str(pocket_model), 'reference_sha256': digest(reference), 'runtime': so.__version__,
        'tts': {'threads': 2, 'num_steps': 5, 'seed': 42, 'speed': 1, 'early_audio': False, 'max_frames_override': None},
        'source_segmentation': 'Contiguous 15-25 second file windows; cut at minimum 100 ms RMS; final tail retained.',
        'translation': 'One complete non-streaming request per source window; raw first candidate retained.',
        'combined_audio': 'Concatenated synthesized segments; original timing gaps and omitted segments are not inserted.',
        'started_at': time.time(), 'harness_sha256': digest(Path(__file__))}
    save(output/'protocol.json', protocol)
    rows, translator = [], None
    finished = False
    began = time.monotonic()
    def stop(*_):
        raise KeyboardInterrupt('Offline diagnostic interrupted')
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    def progress(stage, done):
        save(output/'rows.json', rows)
        save(output/'progress.json', {'status': 'running', 'stage': stage, 'done': done, 'segments': len(rows),
            'source_seconds': info.duration, 'elapsed_seconds': time.monotonic()-began,
            'audio_seconds': sum(r.get('audio_seconds', 0) for r in rows),
            'errors': sum(bool(r.get('error')) for r in rows),
            'quality_flags': sum(any(r.get('quality_flags', {}).values()) for r in rows)})
    try:
        recognizer = so.OfflineRecognizer.from_sense_voice(model=str(recognizer_model/'model.int8.onnx'),
            tokens=str(recognizer_model/'tokens.txt'), num_threads=2, language='zh', use_itn=True)
        stream = None
        with sf.SoundFile(decoded) as source:
            position = 0
            while position < info.frames:
                samples = source.read(25*info.samplerate, dtype='float32')
                take = len(samples)
                if position+take < info.frames:
                    bins = samples[:len(samples)//1600*1600].reshape(-1, 1600)
                    quiet = np.sqrt(np.mean(bins[150:]**2, axis=1))
                    take = (150+int(np.argmin(quiet))+1)*1600
                pcm = samples[:take]
                path = output/'source-segments'/f'{len(rows):05d}.wav'
                sf.write(path, pcm, info.samplerate, subtype='FLOAT')
                row = {'index': len(rows), 'source_start_sample': position, 'source_samples': take,
                    'source_start_seconds': position/info.samplerate, 'source_seconds': take/info.samplerate,
                    'source_audio': str(path)}
                tick = time.monotonic()
                try:
                    stream = recognizer.create_stream()
                    stream.accept_waveform(info.samplerate, pcm)
                    recognizer.decode_stream(stream)
                    row['source_text'] = stream.result.text.strip()
                except RuntimeError as error:
                    row.update(source_text='', error='ASR: '+str(error))
                row['asr_seconds'] = time.monotonic()-tick
                rows.append(row)
                position += take
                source.seek(position)
                progress('recognition', len(rows))
        del stream, recognizer
        gc.collect()
        import socket
        assert_ports_available([(18200, socket.SOCK_STREAM)])
        env = dict(os.environ, LD_LIBRARY_PATH=str(binary.parent)+':'+os.environ.get('LD_LIBRARY_PATH', ''))
        translator_log = (output/'translator.log').open('w')
        translator = subprocess.Popen([str(binary), '-m', str(home/'mozart-archive/qwen35/gguf/qwen35-0.8b-text-Q4_K_M.gguf'),
            '-c', '2048', '-b', '256', '-ub', '128', '--cache-ram', '128', '-ngl', '99', '-np', '1',
            '-t', '2', '-tb', '2', '--host', '127.0.0.1', '--port', '18200', '--jinja'],
            stdout=translator_log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
        deadline = time.monotonic()+90
        while time.monotonic() < deadline:
            if translator.poll() is not None:
                raise RuntimeError('Offline translator failed during startup')
            try:
                request('http://127.0.0.1:18200/health')
                break
            except OSError:
                time.sleep(.2)
        else:
            raise TimeoutError('Offline translator readiness timeout')
        for index, row in enumerate(rows):
            if not row['source_text']:
                row['translation'] = ''
                row['omission_reason'] = row.get('error', 'empty_source_text')
                progress('translation', index+1)
                continue
            tick = time.monotonic()
            try:
                response = request_json('http://127.0.0.1:18200/v1/chat/completions', {
                    'messages': [{'role': 'system', 'content': SYSTEM_PROMPT},
                                 {'role': 'user', 'content': row['source_text']}],
                    'chat_template_kwargs': {'enable_thinking': False}, 'temperature': 0, 'max_tokens': 512}, timeout=120)
                choice = response['choices'][0]
                text = choice['message']['content'].strip()
                row.update(translation=text, finish_reason=choice.get('finish_reason'))
                row['quality_flags'] = {'missing_numbers': missing_numbers(row['source_text'], text),
                    'repeated_numbers': repeated_numbers(row['source_text'], text),
                    'added_large_numbers': added_large_numbers(row['source_text'], text),
                    'untranslated_chinese': bool(re.search(r'[\u3400-\u9fff]', text)),
                    'truncated': choice.get('finish_reason') == 'length'}
            except OSError as error:
                row.update(translation='', error='translation: '+str(error))
            row['translation_seconds'] = time.monotonic()-tick
            progress('translation', index+1)
        translator.terminate()
        translator.wait(timeout=20)
        translator_log.close()
        suffix = '.int8.onnx'
        model = so.OfflineTtsPocketModelConfig(**{key: str(pocket_model/name) for key, name in {
            'lm_flow': 'lm_flow'+suffix, 'lm_main': 'lm_main'+suffix, 'encoder': 'encoder.onnx',
            'decoder': 'decoder'+suffix, 'text_conditioner': 'text_conditioner.onnx',
            'vocab_json': 'vocab.json', 'token_scores_json': 'token_scores.json'}.items()})
        tts = so.OfflineTts(so.OfflineTtsConfig(model=so.OfflineTtsModelConfig(pocket=model, num_threads=2, provider='cpu')))
        ref, rate = sf.read(reference, dtype='float32')
        for index, row in enumerate(rows):
            if not row.get('translation'):
                row.setdefault('omission_reason', row.get('error', 'empty_translation'))
                progress('synthesis', index+1)
                continue
            config = so.GenerationConfig()
            config.reference_audio, config.reference_sample_rate = ref, rate
            config.reference_text = ''
            config.num_steps, config.speed, config.silence_scale = 5, 1, 1
            config.extra = {'seed': '42'}
            tick = time.monotonic()
            try:
                audio = tts.generate(row['translation'], config)
                pcm = np.asarray(audio.samples, dtype='float32')
                path = output/'audio'/f'{index:05d}.wav'
                sf.write(path, pcm, audio.sample_rate, subtype='FLOAT')
                finite = np.isfinite(pcm)
                row.update(audio=str(path), audio_samples=len(pcm), audio_rate=audio.sample_rate,
                    audio_seconds=len(pcm)/audio.sample_rate,
                    raw_peak=float(np.max(np.abs(pcm))) if len(pcm) and finite.all() else None,
                    nonfinite_samples=int(np.count_nonzero(~finite)),
                    over_fullscale_samples=int(np.count_nonzero(np.abs(pcm)>1)))
            except RuntimeError as error:
                row['error'] = 'TTS: '+str(error)
            row['synthesis_seconds'] = time.monotonic()-tick
            progress('synthesis', index+1)
        with sf.SoundFile(output/'translated-speech-combined.wav', 'w', tts.sample_rate, 1, subtype='FLOAT') as combined:
            for row in rows:
                if row.get('audio'):
                    pcm, _ = sf.read(row['audio'], dtype='float32')
                    row['combined_start_seconds'] = combined.tell()/tts.sample_rate
                    combined.write(pcm)
        finished = True
    finally:
        failure = str(sys.exc_info()[1]) if sys.exc_info()[1] else None
        if translator is not None and translator.poll() is None:
            translator.terminate()
            try:
                translator.wait(timeout=20)
            except subprocess.TimeoutExpired:
                translator.kill()
                translator.wait()
        flagged = any(r.get('error') or r.get('omission_reason') or any(r.get('quality_flags', {}).values()) or
            r.get('nonfinite_samples') or r.get('over_fullscale_samples') for r in rows)
        result = {'status': ('completed_with_findings' if flagged else 'completed') if finished else 'failed',
            'execution_complete': finished,
            'strict_acceptance_passed': False, 'quality_gate_enforced': False, 'failure': failure,
            'source_seconds': info.duration, 'source_samples_total': info.frames,
            'source_samples_processed': sum(r['source_samples'] for r in rows), 'segments': len(rows),
            'audio_segments': sum('audio' in r for r in rows), 'errors': sum(bool(r.get('error')) for r in rows),
            'quality_flagged_segments': sum(any(r.get('quality_flags', {}).values()) for r in rows),
            'omitted_segments': sum(bool(r.get('omission_reason')) for r in rows),
            'combined_audio': protocol['combined_audio'],
            'audio_seconds': sum(r.get('audio_seconds', 0) for r in rows),
            'elapsed_seconds': time.monotonic()-began}
        save(output/'rows.json', rows)
        save(output/'exit-status.json', result)
        save(output/'progress.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
