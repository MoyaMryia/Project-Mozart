"""保留异常记录并收集后续变声音频，用于强制输出诊断。"""
import json
import select
import struct
import time

import numpy as np
import soundfile as sf

from run_soak import Relay


class DiagnosticRelay(Relay):
    def __init__(self, output):
        super().__init__(output)
        self.input_bad = self.input_gaps = self.output_gaps = self.nonfinite_samples = 0
        self.last_input_index = 0

    def status(self):
        return {**super().status(), **{name: getattr(self, name) for name in
            ('input_bad', 'input_gaps', 'output_gaps', 'nonfinite_samples')}}

    def run(self):
        try:
            with sf.SoundFile(self.output/'processed-input.wav', 'w', 16000, 1, subtype='FLOAT') as source, \
                    sf.SoundFile(self.output/'qiqi-mozart-backend.wav', 'w', 48000, 1, subtype='FLOAT') as audio, \
                    (self.output/'rvc-packet-indices.bin').open('wb') as indices, \
                    (self.output/'packet-anomalies.jsonl').open('w') as events:
                def event(kind, **details):
                    events.write(json.dumps({'at': time.time(), 'kind': kind, **details})+'\n')
                    events.flush()
                self.last_index = 0
                while not self.stopped.is_set():
                    ready, _, _ = select.select([self.incoming, self.backend], [], [], .2)
                    for sock in ready:
                        if sock is self.incoming:
                            packet, self.peer = sock.recvfrom(65536)
                            if len(packet) != 1300 or packet[:4] != b'TRZM':
                                self.input_bad += 1
                                event('bad_input_packet', bytes=len(packet))
                                continue
                            index = struct.unpack_from('<I', packet, 12)[0]
                            if index != self.last_input_index+1:
                                self.input_gaps += max(0, index-self.last_input_index-1)
                                event('input_sequence', previous=self.last_input_index, actual=index)
                            self.last_input_index = index
                            source.write(np.frombuffer(packet, dtype='<f4', offset=20))
                            self.backend.send(packet)
                            self.sent += 1
                        else:
                            packet = sock.recv(65536)
                            if len(packet) != 3860 or packet[:4] != b'TRZM':
                                self.bad += 1
                                event('bad_output_packet', bytes=len(packet))
                                continue
                            index = struct.unpack_from('<I', packet, 12)[0]
                            if index != self.last_index+1:
                                self.output_gaps += max(0, index-self.last_index-1)
                                self.duplicate += int(index == self.last_index)
                                self.out_of_order += int(index < self.last_index)
                                event('output_sequence', previous=self.last_index, actual=index)
                            self.last_index = index
                            samples = np.frombuffer(packet, dtype='<f4', offset=20)
                            nonfinite = int(np.count_nonzero(~np.isfinite(samples)))
                            if nonfinite:
                                self.nonfinite_samples += nonfinite
                                event('nonfinite_output', index=index, samples=nonfinite)
                            indices.write(struct.pack('<I', index))
                            audio.write(samples)
                            self.received += 1
                            if self.peer:
                                self.incoming.sendto(packet, self.peer)
        except (OSError, ValueError, RuntimeError) as error:
            self.error = str(error)
