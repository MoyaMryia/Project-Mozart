import json, os, pathlib, socket, subprocess, tempfile, time, urllib.request
artifacts=pathlib.Path('/home/moyamryia/Mozart/rvc-golden/next-steps-audit-20261002')
with tempfile.TemporaryDirectory(prefix='mozart-audit-api-') as tmp:
    tmp=pathlib.Path(tmp)
    subtitles=tmp/'subtitles.jsonl'; subtitles.write_text('')
    config=tmp/'backend.yaml'
    config.write_text(f'''network:
  audio:
    host: 127.0.0.1
    port: 18113
  control:
    host: 127.0.0.1
    port: 18193
rvc:
  models_dir: {tmp}/models
  hubert_path: {tmp}/missing.onnx
  mock:
    generator: true
    hubert: true
    rmvpe: true
storage:
  temp_dir: {tmp}/storage
  presets_path: {tmp}/presets.json
''')
    env=dict(os.environ, MOZART_SUBTITLES_JSONL=str(subtitles))
    with (artifacts/'sse-daemon.log').open('w') as log:
        p=subprocess.Popen(['/home/moyamryia/Mozart/build-gpu/state/mozart_stated',str(config)],stdout=log,stderr=log,env=env)
        try:
            for _ in range(100):
                try:
                    urllib.request.urlopen('http://127.0.0.1:18193/api/health',timeout=1).close(); break
                except OSError: time.sleep(.1)
            with socket.create_connection(('127.0.0.1',18193),timeout=2) as s:
                s.sendall(b'GET /api/subtitles HTTP/1.1\r\nHost: localhost\r\n\r\n')
                header=s.recv(4096); assert b'200 OK' in header,header
                time.sleep(.3)
                with subtitles.open('a') as f: f.write('{"seq":1,"zh":"first"}\n')
                assert b'"seq":1' in s.recv(4096)
                print('PASS: subtitle SSE delivers appended event')
                replacement=tmp/'replacement.jsonl'; replacement.write_text('{"seq":2,"zh":"after rotation"}\n')
                os.replace(replacement,subtitles)
                with subtitles.open('a') as f: f.write('{"seq":3,"zh":"new append"}\n')
                s.settimeout(3)
                try:
                    result=s.recv(4096)
                    print('ROTATION RESULT:',repr(result))
                except socket.timeout:
                    print('CONFIRMED GAP: SSE does not reopen a replaced subtitle file; no event delivered after rotation')
        finally:
            p.terminate(); p.wait(timeout=10)
