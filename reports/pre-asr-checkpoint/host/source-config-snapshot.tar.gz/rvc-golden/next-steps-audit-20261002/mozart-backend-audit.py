import json, pathlib, subprocess, time, urllib.request
root=pathlib.Path('/home/moyamryia/Mozart')
audit=root/'rvc-golden/next-steps-audit-20261002'
config=audit/'backend-audit.yaml'
text=(root/'rvc-golden/qiqi-zh-run/backend.yaml').read_text()
text=text.replace('/home/moyamryia/Mozart/rvc-golden/qiqi-zh-run/temp',str(audit/'jobs'))
text=text.replace('/home/moyamryia/Mozart/rvc-golden/qiqi-zh-run/presets.json',str(audit/'presets.json'))
config.write_text(text)
with (audit/'backend-daemon.log').open('w') as log:
    proc=subprocess.Popen(['/tmp/mozart-next-steps/build-gpu/state/mozart_stated',str(config)],stdout=log,stderr=log)
    try:
        for _ in range(300):
            if proc.poll() is not None: raise RuntimeError('real backend exited during startup')
            try:
                with urllib.request.urlopen('http://127.0.0.1:18181/api/status',timeout=1) as r:
                    status=json.load(r)
                break
            except OSError: time.sleep(.2)
        else: raise RuntimeError('real backend did not start')
        for endpoint in ['status','models','parameters']:
            with urllib.request.urlopen('http://127.0.0.1:18181/api/'+endpoint,timeout=3) as r:
                (audit/('startup-'+endpoint+'.json')).write_text(json.dumps(json.load(r),indent=2))
        with (audit/'backend-verification.log').open('w') as output:
            result=subprocess.run([str(root/'.venv/bin/python'),'-u',str(root/'rvc-golden/verify_backend.py'),'--api','http://127.0.0.1:18181','--udp','127.0.0.1:18101','--tmp',str(audit)],stdout=output,stderr=subprocess.STDOUT,timeout=300)
        print((audit/'backend-verification.log').read_text(),flush=True)
        raise SystemExit(result.returncode)
    finally:
        proc.terminate(); proc.wait(timeout=15)
