#include "mozart/capture.h"
#include <stdio.h>
int main(void) {
    const char *devices[]={"hw:CARD=Device,DEV=0", "plughw:CARD=Device,DEV=0"};
    for (unsigned i=0;i<2;i++) {
        mozart_capture_config_t cfg={devices[i],48000,2,960,4};
        mozart_capture_t *cap=mozart_capture_open(&cfg);
        printf("48k/S16/stereo configuration: %s -> %s (no samples read)\n", devices[i],cap?"PASS":"REJECTED");
        mozart_capture_close(cap);
        if(i==1 && !cap) return 1;
    }
    return 0;
}
