import json, pathlib, subprocess, time, urllib.request
root=pathlib.Path('/home/moyamryia/Mozart')
audit=root/'rvc-golden/next-steps-audit-20261002'
config=audit/'stream-audit.yaml'
text=(root/'rvc-golden/qiqi-zh-run/backend.yaml').read_text()
models=audit/'stream-models'
for model_id in ['qiqi-zh', 'qiqi-zh-realtime']:
    src=root/'rvc-golden/qiqi-zh-run'/model_id
    dst=models/model_id; dst.mkdir(parents=True,exist_ok=True)
    (dst/'config.json').write_bytes((src/'config.json').read_bytes())
    for asset in src.iterdir():
        if asset.suffix in ['.onnx','.engine']:
            target=dst/asset.name
            if not target.exists(): target.symlink_to(asset.resolve())
text=text.replace('models_dir: /home/moyamryia/Mozart/rvc-golden/qiqi-zh-run','models_dir: '+str(models))
text=text.replace('/home/moyamryia/Mozart/rvc-golden/qiqi-zh-run/temp',str(audit/'stream-jobs'))
text=text.replace('/home/moyamryia/Mozart/rvc-golden/qiqi-zh-run/presets.json',str(audit/'presets.json'))
config.write_text(text)
with (audit/'stream-daemon.log').open('w') as log:
    proc=subprocess.Popen(['/tmp/mozart-next-steps/build-gpu/state/mozart_stated',str(config)],stdout=log,stderr=log)
    try:
        for _ in range(300):
            if proc.poll() is not None: raise RuntimeError('real backend exited during startup')
            try:
                with urllib.request.urlopen('http://127.0.0.1:18181/api/status',timeout=1) as r:
                    status=json.load(r)
                break
            except OSError: time.sleep(.2)
        else: raise RuntimeError('real backend did not start')
        with (audit/'stream-direct.log').open('w') as output:
            result=subprocess.run(['/home/moyamryia/vc_backend_venv/bin/python','-u',str(root/'tools/stream_audio_udp.py'),str(root/'rvc-golden/input/qiqi-espeak-pinyin-zh-en-mixed.wav'),str(audit/'stream-legacy-direct.wav'),'--api','http://127.0.0.1:18181','--backend','127.0.0.1:18101','--model-id','qiqi-zh','--flush-seconds','2','--no-trim-leading'],stdout=output,stderr=subprocess.STDOUT,timeout=120)
        print((audit/'stream-direct.log').read_text(),flush=True)
        if result.returncode == 0:
            import sys
            sys.path.insert(0,str(root/'rvc-golden'))
            from verify_backend import compare
            m=compare(root/'rvc-golden/output/qiqi-zh-espeak-pinyin-mixed-streaming-python-reference-DET.wav',audit/'stream-legacy-direct.wav')
            print(json.dumps(m,indent=2,default=float),flush=True)
            (audit/'stream-legacy-comparison.json').write_text(json.dumps(m,indent=2,default=float))
        raise SystemExit(result.returncode)
    finally:
        proc.terminate(); proc.wait(timeout=15)
