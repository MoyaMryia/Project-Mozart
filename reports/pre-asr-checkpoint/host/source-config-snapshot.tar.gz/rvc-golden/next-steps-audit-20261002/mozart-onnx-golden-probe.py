import json, pathlib, numpy as np, onnxruntime as ort, soundfile as sf
root=pathlib.Path('/home/moyamryia/Mozart/rvc-golden')
tensors=root/'tensors/qiqi_zh_offline_det'
model=root/'qiqi-zh-run/qiqi-zh-full/qiqi-zh-full.onnx'
opts=ort.SessionOptions(); opts.intra_op_num_threads=2; opts.inter_op_num_threads=1
session=ort.InferenceSession(str(model),opts,providers=['CPUExecutionProvider'])
feed={}
for inp in session.get_inputs():
    arr=np.load(tensors/f'generator_00_{inp.name}.npy')
    dtype={'tensor(float)':np.float32,'tensor(int64)':np.int64,'tensor(int32)':np.int32}[inp.type]
    feed[inp.name]=arr.astype(dtype,copy=False)
    print('input',inp.name,feed[inp.name].shape,feed[inp.name].dtype,flush=True)
out=session.run(None,feed)[0]
ref=np.load(tensors/'generator_00_audio.npy')
a=ref.astype(np.float64).ravel(); b=out.astype(np.float64).ravel()
metrics={'golden_shape':list(ref.shape),'onnx_shape':list(out.shape),'golden_dtype':str(ref.dtype),'onnx_dtype':str(out.dtype),'finite':bool(np.isfinite(a).all() and np.isfinite(b).all())}
if a.size==b.size:
    metrics.update(max_abs=float(np.max(np.abs(a-b))),mean_abs=float(np.mean(np.abs(a-b))),cosine=float(a@b/(np.linalg.norm(a)*np.linalg.norm(b))),rms_gold=float(np.sqrt(np.mean(a*a))),rms_onnx=float(np.sqrt(np.mean(b*b))),duration_seconds=b.size/48000)
passed=ref.shape==out.shape and ref.dtype==out.dtype and metrics['finite'] and metrics.get('cosine',0)>=.999 and metrics.get('max_abs',float('inf'))<.01
metrics['pass']=passed
artifacts=root/'next-steps-audit-20261002'
(artifacts/'golden-onnx-generator.json').write_text(json.dumps(metrics,indent=2))
sf.write(artifacts/'qiqi-captured-golden-generator.wav',a,48000,subtype='FLOAT')
sf.write(artifacts/'qiqi-captured-onnx-generator.wav',b,48000,subtype='FLOAT')
print(json.dumps(metrics,indent=2),flush=True)
raise SystemExit(0 if passed else 1)
