#define _POSIX_C_SOURCE 200809L
#include "mozart/dsp.h"
#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <poll.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define HEADER 24
#define BLOCK_MAX 128
#define AUDIO_CAP 2048
#define HEADER_CAP 32
static volatile sig_atomic_t stopping;
static void stop_probe(int sig) { (void)sig; stopping = 1; }
static void fail(const char *message) { perror(message); exit(2); }
static uint32_t get32(const unsigned char *p) {
    return (uint32_t)p[0] | (uint32_t)p[1]<<8 | (uint32_t)p[2]<<16 | (uint32_t)p[3]<<24;
}
static void put32(unsigned char *p, uint32_t value) {
    for (int i=0; i<4; i++) p[i] = (unsigned char)(value >> (8*i));
}
static void write_all(int fd, const unsigned char *data, size_t size) {
    while (size) {
        ssize_t n = write(fd, data, size);
        if (n < 0 && errno == EINTR && !stopping) continue;
        if (n <= 0) fail("endpoint write");
        data += n; size -= (size_t)n;
    }
}
struct state {
    unsigned char headers[HEADER_CAP][HEADER];
    float fifo[AUDIO_CAP];
    size_t fifo_len, head_count;
    uint32_t mode, block, expected, input_samples, output_samples;
    mozart_dsp_t *dsp;
};
static void process_audio(struct state *s, const float *mono, int output) {
    float enhanced[AUDIO_CAP];
    size_t produced = mozart_dsp_enhance(s->dsp,mono,s->block,enhanced,AUDIO_CAP);
    if (produced==SIZE_MAX || produced>AUDIO_CAP-s->fifo_len) {
        fprintf(stderr,"invalid dsp output capacity\n"); exit(2);
    }
    for (size_t i=0; i<produced; i++) {
        if (!isfinite(enhanced[i])) { fprintf(stderr,"nonfinite dsp output\n"); exit(2); }
    }
    memcpy(s->fifo+s->fifo_len,enhanced,produced*sizeof(float));
    s->fifo_len += produced;
    while (s->head_count && s->fifo_len >= s->block) {
        unsigned char response[HEADER+BLOCK_MAX*4];
        memcpy(response,s->headers[0],HEADER);
        memmove(s->headers,s->headers+1,(--s->head_count)*HEADER);
        for (uint32_t i=0; i<s->block; i++) {
            float v = fminf(1.0f,fmaxf(-1.0f,s->fifo[i]));
            int16_t sample = (int16_t)(v*32767.0f);
            for (int ch=0; ch<2; ch++) {
                response[HEADER+4*i+2*ch] = (uint16_t)sample & 255;
                response[HEADER+4*i+2*ch+1] = (uint16_t)sample >> 8;
            }
        }
        s->fifo_len -= s->block;
        memmove(s->fifo,s->fifo+s->block,s->fifo_len*sizeof(float));
        write_all(output,response,HEADER+s->block*4);
        s->output_samples += s->block;
    }
}
int main(void) {
    signal(SIGTERM, stop_probe);
    signal(SIGINT, stop_probe);
    int input = open("/dev/ffs-mozart/ep3", O_RDONLY);
    if (input < 0) fail("open ep3");
    int output = open("/dev/ffs-mozart/ep4", O_WRONLY);
    if (output < 0) fail("open ep4");
    unsigned char pending[131072];
    size_t used = 0;
    struct state s = {0};
    puts("ready"); fflush(stdout);
    while (!stopping) {
        struct pollfd poller = {.fd=input, .events=POLLIN};
        int rc = poll(&poller, 1, 250);
        if (rc < 0 && errno == EINTR) continue;
        if (rc < 0 || (rc > 0 && !(poller.revents & POLLIN))) fail("endpoint poll");
        if (!rc) continue;
        ssize_t n = read(input, pending + used, 65536);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) fail("endpoint read");
        used += (size_t)n;
        while (used >= HEADER) {
            unsigned char *p = pending;
            uint32_t length = get32(p+20), seq = get32(p+8);
            if (p[0]!=0x5a || p[1]!=0x4d || p[2]!=1 || p[4]!=2 || p[6] || p[7]
                || length > BLOCK_MAX*4 || (p[3]!=0 && p[3]!=1)) {
                fprintf(stderr,"invalid probe frame\n"); return 2;
            }
            size_t wire = HEADER + length;
            if (used < wire) break;
            if (p[3] == 1) {
                if (p[5] == 1 && length == 8) {
                    uint32_t mode = get32(p+HEADER), block = get32(p+HEADER+4);
                    if (mode>1 || (block!=64 && block!=128)) {
                        fprintf(stderr,"invalid probe configuration\n"); return 2;
                    }
                    mozart_dsp_free(s.dsp);
                    memset(&s,0,sizeof(s));
                    s.mode = mode; s.block = block;
                    if (mode) {
                        mozart_dsp_config_t cfg = {.denoise=true};
                        s.dsp = mozart_dsp_new(&cfg);
                        if (!s.dsp) fail("dsp allocation");
                    }
                    write_all(output,p,wire);
                } else if (p[5] == 2 && length == 0 && s.block) {
                    uint32_t padding = 0;
                    if (s.mode && s.head_count) {
                        float zeros[BLOCK_MAX] = {0};
                        process_audio(&s,zeros,output);
                        padding = s.block;
                    }
                    if (s.head_count || s.input_samples != s.output_samples) {
                        fprintf(stderr,"incomplete sample coverage\n"); return 2;
                    }
                    unsigned char ack[HEADER+16];
                    memcpy(ack,p,HEADER); put32(ack+20,16);
                    put32(ack+HEADER,s.input_samples);
                    put32(ack+HEADER+4,s.output_samples);
                    put32(ack+HEADER+8,(uint32_t)s.fifo_len);
                    put32(ack+HEADER+12,padding);
                    write_all(output,ack,sizeof(ack));
                    printf("mode=%u block=%u packets=%u input_samples=%u output_samples=%u padding=%u residual_padding_samples=%zu\n",
                        s.mode,s.block,s.expected,s.input_samples,s.output_samples,padding,s.fifo_len);
                    fflush(stdout);
                } else { fprintf(stderr,"invalid probe control\n"); return 2; }
            } else {
                if (!s.block || p[5] || length!=s.block*4 || seq!=s.expected++) {
                    fprintf(stderr,"invalid audio size or sequence\n"); return 2;
                }
                s.input_samples += s.block;
                if (!s.mode) {
                    write_all(output,p,wire);
                    s.output_samples += s.block;
                } else {
                    if (s.head_count == HEADER_CAP) { fprintf(stderr,"header queue full\n"); return 2; }
                    memcpy(s.headers[s.head_count++],p,HEADER);
                    float mono[BLOCK_MAX];
                    for (uint32_t i=0; i<s.block; i++) {
                        uint16_t v = (uint16_t)p[HEADER+4*i] | (uint16_t)p[HEADER+4*i+1]<<8;
                        mono[i] = (float)(int16_t)v / 32768.0f;
                    }
                    process_audio(&s,mono,output);
                }
            }
            used -= wire;
            memmove(pending,pending+wire,used);
        }
    }
    mozart_dsp_free(s.dsp);
    close(input); close(output);
    return 0;
}
