#!/usr/bin/env python3
"""测量专用端点的往返时间，保存全部逐包记录。"""
import argparse
import concurrent.futures
import csv
import ctypes
import json
import math
from pathlib import Path
import struct
import sys
import threading
import time

import usb.core
import usb.util

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'usb-audio'))
import proto

RATE = 48000
WARMUP = 100
TAIL = 16


def summary(values):
    ordered = sorted(values)
    return {name: ordered[math.ceil(len(ordered) * q) - 1]
            for name, q in [('min', 1 / len(ordered)), ('p50', .5),
                            ('p95', .95), ('p99', .99), ('max', 1)]}


class Receiver:
    def __init__(self, endpoint):
        self.endpoint = endpoint
        self.pending = b''
        self.arrived = 0

    def next(self):
        while True:
            frame = proto.decode(self.pending)
            if frame is not None:
                self.pending = self.pending[proto.HEADER_BYTES + len(frame[-1]):]
                return frame, self.arrived
            self.pending += bytes(self.endpoint.read(65536, timeout=2000))
            self.arrived = time.monotonic_ns()


def payload_for(seq, block):
    state = seq + 1
    samples = []
    for _ in range(block):
        state = (1664525 * state + 1013904223) & 0xffffffff
        value = (state >> 17) - 16384
        samples.extend((value, value))
    return struct.pack('<%dh' % len(samples), *samples)


def reference_audio(payloads, block):
    library = ctypes.CDLL(str(Path(__file__).with_name('native-reference.so')))
    class Config(ctypes.Structure):
        _fields_ = [(name, ctypes.c_bool) for name in ('denoise', 'gate', 'agc', 'limiter')]
    library.mozart_dsp_new.argtypes = [ctypes.POINTER(Config)]
    library.mozart_dsp_new.restype = ctypes.c_void_p
    library.mozart_dsp_enhance.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float),
                                         ctypes.c_size_t, ctypes.POINTER(ctypes.c_float),
                                         ctypes.c_size_t]
    library.mozart_dsp_enhance.restype = ctypes.c_size_t
    library.mozart_dsp_free.argtypes = [ctypes.c_void_p]
    instance = library.mozart_dsp_new(ctypes.byref(Config(True, False, False, False)))
    if not instance:
        raise RuntimeError('reference allocation failed')
    result = []
    output = (ctypes.c_float * 2048)()
    try:
        for payload in payloads + [bytes(block * 4)]:
            samples = struct.unpack('<%dh' % (len(payload) // 2), payload)
            source = (ctypes.c_float * block)(*(v / 32768 for v in samples[::2]))
            produced = library.mozart_dsp_enhance(instance, source, block, output, len(output))
            if produced > len(output):
                raise RuntimeError('reference output failed')
            for value in output[:produced]:
                if not math.isfinite(value):
                    raise RuntimeError('nonfinite reference audio')
                result.append(int(min(1, max(-1, value)) * 32767))
    finally:
        library.mozart_dsp_free(instance)
    if len(result) < len(payloads) * block:
        raise RuntimeError('incomplete reference coverage')
    return result[:len(payloads) * block]


def check_dsp(payload, expected):
    samples = struct.unpack('<%dh' % (len(payload) // 2), payload)
    if samples[::2] != samples[1::2]:
        raise RuntimeError('processed stereo mismatch')
    difference = max(abs(a - b) for a, b in zip(samples[::2], expected, strict=True))
    if difference > 1:
        raise RuntimeError(f'processed audio differs from C reference by {difference} LSB')
    return difference


def run(out, receiver, block, mode, count, repeat, directory):
    control = struct.pack('<II', mode, block)
    start = proto.encode(proto.TYPE_CONTROL, 0xffffffff, 0, control,
                         stream=proto.STREAM_FAST, flags=1)
    if out.write(start, timeout=2000) != len(start):
        raise RuntimeError('short start control write')
    ack, _ = receiver.next()
    if ack != proto.decode(start):
        raise RuntimeError('start acknowledgement mismatch')
    total = WARMUP + count + TAIL
    payloads = [payload_for(seq, block) for seq in range(total)]
    reference = reference_audio(payloads, block) if mode else None
    max_difference = 0
    sent = [None] * total
    send_late = [None] * total
    rows = []
    stop = threading.Event()
    epoch = time.monotonic_ns() + 20_000_000

    def transmit():
        for seq, payload in enumerate(payloads):
            target = epoch + seq * block * 1_000_000_000 // RATE
            delay = target - time.monotonic_ns()
            if delay > 0:
                time.sleep(delay / 1e9)
            if stop.is_set():
                return
            now = time.monotonic_ns()
            sent[seq] = now
            send_late[seq] = now - target
            wire = proto.encode(proto.TYPE_PCM, seq, now // 1000, payload,
                                stream=proto.STREAM_FAST)
            if out.write(wire, timeout=2000) != len(wire):
                raise RuntimeError('short audio write')
        end = proto.encode(proto.TYPE_CONTROL, 0xffffffff, 0,
                           stream=proto.STREAM_FAST, flags=2)
        if out.write(end, timeout=2000) != len(end):
            raise RuntimeError('short end control write')

    expected = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
        sender = executor.submit(transmit)
        try:
            while True:
                frame, arrived = receiver.next()
                version, kind, stream, flags, seq, stamp, payload = frame
                if kind == proto.TYPE_CONTROL:
                    if (version, stream, flags, seq, stamp, len(payload)) != (
                            proto.VERSION, proto.STREAM_FAST, 2, 0xffffffff, 0, 16):
                        raise RuntimeError('end acknowledgement mismatch')
                    coverage = struct.unpack('<IIII', payload)
                    expected_coverage = (total * block, total * block,
                                         (block - 64) if mode else 0, block if mode else 0)
                    if coverage != expected_coverage:
                        raise RuntimeError(f'sample coverage mismatch: {coverage}')
                    break
                if (version, kind, stream, flags, seq, len(payload)) != (
                        proto.VERSION, proto.TYPE_PCM, proto.STREAM_FAST, 0,
                        expected, block * 4):
                    raise RuntimeError('audio header or sequence mismatch')
                if sent[seq] is None or stamp != sent[seq] // 1000:
                    raise RuntimeError('audio timestamp mismatch')
                if mode == 0 and payload != payloads[seq]:
                    raise RuntimeError('echo payload mismatch')
                if mode == 1:
                    difference = check_dsp(payload, reference[seq * block:(seq + 1) * block])
                    max_difference = max(max_difference, difference)
                phase = ('warmup' if seq < WARMUP else
                         'measured' if seq < WARMUP + count else 'tail')
                rows.append((seq, phase, sent[seq], arrived,
                             arrived - sent[seq], send_late[seq]))
                expected += 1
        finally:
            stop.set()
    sender.result()
    expected_packets = total
    if expected != expected_packets:
        raise RuntimeError(f'packet coverage {expected}/{expected_packets}')
    measured = [r for r in rows if r[1] == 'measured']
    if len(measured) != count:
        raise RuntimeError(f'measured packet coverage {len(measured)}/{count}')
    label = f'{"echo" if mode == 0 else "dsp"}-{block}-r{repeat}'
    with (directory / f'{label}.csv').open('w') as stream:
        writer = csv.writer(stream)
        writer.writerow(['seq', 'phase', 'send_ns', 'receive_ns', 'rtt_ns', 'send_late_ns'])
        writer.writerows(rows)
    result = dict(label=label, block_samples=block, mode=mode,
                  sent=total, received=expected, measured=len(measured),
                  rtt_ns=summary([r[4] for r in measured]),
                  send_late_ns=summary([r[5] for r in measured]),
                  startup_rtt_ns=rows[0][4], max_reference_error_lsb=max_difference,
                  sample_coverage=coverage,
                  above_10ms=sum(r[4] > 10_000_000 for r in measured))
    print(json.dumps(result), flush=True)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--count', type=int, default=3000)
    parser.add_argument('--repeats', type=int, default=3)
    args = parser.parse_args()
    if not 1 <= args.count <= 10000 or not 1 <= args.repeats <= 10:
        parser.error('count must be 1..10000; repeats must be 1..10')
    args.output.mkdir(parents=True, exist_ok=True)
    device = usb.core.find(idVendor=0x1d6b, idProduct=0x0105)
    if device is None:
        raise RuntimeError('USB device missing')
    interface = device.get_active_configuration()[(1, 0)]
    usb.util.claim_interface(device, 1)
    try:
        out = usb.util.find_descriptor(interface, custom_match=lambda e:
                                      usb.util.endpoint_direction(e.bEndpointAddress) == 0)
        inp = usb.util.find_descriptor(interface, custom_match=lambda e:
                                      usb.util.endpoint_direction(e.bEndpointAddress) == 0x80)
        if out is None or inp is None:
            raise RuntimeError('dedicated endpoints missing')
        receiver = Receiver(inp)
        results = []
        try:
            for repeat in range(1, args.repeats + 1):
                for block in (64, 128):
                    for mode in (0, 1):
                        results.append(run(out, receiver, block, mode, args.count,
                                           repeat, args.output))
        finally:
            (args.output / 'results.json').write_text(
                json.dumps(results, indent=2) + '\n')
    finally:
        usb.util.release_interface(device, 1)
        usb.util.dispose_resources(device)


if __name__ == '__main__':
    main()
