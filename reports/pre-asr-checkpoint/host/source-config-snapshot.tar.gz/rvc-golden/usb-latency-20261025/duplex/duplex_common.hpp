#pragma once
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <exception>
#include <fstream>
#include <mutex>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace duplex {
constexpr unsigned Header=24, Rate=48000, PingEvery=128, HostSeed=0x1234abcd, JetsonSeed=0x93ef6571;
constexpr unsigned IoTimeoutMs=3000, MaxSeconds=60, SmallBlock=64, LargeBlock=128;
constexpr unsigned MaxPayload=LargeBlock*4;
inline bool allowed_block(uint64_t block) { return block==SmallBlock||block==LargeBlock; }
inline int64_t now() { return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count(); }
inline void require(bool ok,const std::string& message) { if(!ok) throw std::runtime_error(message); }
inline uint32_t get32(const uint8_t* p) { return uint32_t(p[0])|uint32_t(p[1])<<8|uint32_t(p[2])<<16|uint32_t(p[3])<<24; }
inline uint64_t get64(const uint8_t* p) { return get32(p)|uint64_t(get32(p+4))<<32; }
inline void put32(uint8_t* p,uint32_t v) { for(int i=0;i<4;i++) p[i]=uint8_t(v>>(8*i)); }
inline std::vector<uint8_t> packet(unsigned type,unsigned flags,uint32_t seq,uint64_t stamp,unsigned bytes) {
    std::vector<uint8_t> p(Header+bytes);
    p[0]=0x5a;p[1]=0x4d;p[2]=1;p[3]=uint8_t(type);p[4]=2;p[5]=uint8_t(flags);
    put32(p.data()+8,seq);put32(p.data()+12,uint32_t(stamp));put32(p.data()+16,uint32_t(stamp>>32));put32(p.data()+20,bytes);
    return p;
}
inline std::vector<uint8_t> audio(unsigned seq,unsigned block,uint32_t seed) {
    auto p=packet(0,0,seq,uint64_t(now()/1000),block*4);
    uint32_t state=seed^seq;
    for(unsigned i=Header;i<p.size();i++) { state=1664525*state+1013904223; p[i]=uint8_t(state>>24); }
    return p;
}
inline void check_audio(const std::vector<uint8_t>& p,unsigned seq,unsigned block,uint32_t seed) {
    require(p[3]==0&&p[5]==0&&get32(p.data()+8)==seq&&p.size()==Header+block*4,"audio sequence or size mismatch");
    uint32_t state=seed^seq;
    for(unsigned i=Header;i<p.size();i++) { state=1664525*state+1013904223; require(p[i]==uint8_t(state>>24),"audio payload corruption"); }
}
struct Failure {
    std::atomic<bool> stopped{false};
    std::mutex mutex;
    std::exception_ptr error;
    void record() { std::lock_guard<std::mutex> lock(mutex); if(!error) error=std::current_exception(); stopped.store(true); }
    void check() { if(stopped.load()) { std::lock_guard<std::mutex> lock(mutex); if(error) std::rethrow_exception(error); throw std::runtime_error("test stopped"); } }
};
struct Frame { std::vector<uint8_t> bytes; int64_t arrived; };
struct Stream {
    std::vector<uint8_t> pending;
    int64_t arrived=0;
    template<class Read> Frame next(Read read) {
        while(true) {
            if(pending.size()>=Header) {
                const auto* p=pending.data();
                require(p[0]==0x5a&&p[1]==0x4d&&p[2]==1&&p[4]==2&&p[6]==0&&p[7]==0,"invalid transport header");
                unsigned length=get32(p+20);
                require(length<=MaxPayload,"transport payload exceeds limit");
                if(pending.size()>=Header+length) {
                    Frame f{{pending.begin(),pending.begin()+Header+length},arrived};
                    pending.erase(pending.begin(),pending.begin()+Header+length);
                    return f;
                }
            }
            std::vector<uint8_t> data=read();
            arrived=now();
            require(!data.empty(),"empty endpoint read");
            pending.insert(pending.end(),data.begin(),data.end());
        }
    }
};
inline void sleep_to(int64_t target) { std::this_thread::sleep_until(std::chrono::steady_clock::time_point(std::chrono::nanoseconds(target))); }
inline void save_times(const std::string& path,const std::vector<int64_t>& times,size_t count) {
    std::ofstream file(path);file<<"seq,time_ns\n";
    for(size_t i=0;i<count;i++) file<<i<<','<<times[i]<<'\n';
    require(bool(file),"failed to save timing file");
}
}
