#include "duplex_common.hpp"
#include <iostream>
using namespace duplex;
template<class Call> void rejects(Call call) {
    try { call(); } catch(const std::runtime_error&) { return; }
    throw std::runtime_error("invalid data passed validation");
}
int main() {
    try {
        require(allowed_block(64)&&allowed_block(128)&&!allowed_block(63)&&!allowed_block(129),"block contract changed");
        for(unsigned block:{64u,128u}) {
            auto first=audio(0,block,HostSeed),second=audio(1,block,HostSeed);
            check_audio(first,0,block,HostSeed);
            auto bad=first;bad.back()^=1;
            rejects([&]{check_audio(bad,0,block,HostSeed);});
            rejects([&]{check_audio(first,1,block,HostSeed);});
            Stream stream;unsigned reads=0;
            auto read=[&] {
                reads++;
                if(reads==1) return std::vector<uint8_t>(first.begin(),first.begin()+7);
                auto rest=std::vector<uint8_t>(first.begin()+7,first.end());
                rest.insert(rest.end(),second.begin(),second.end());return rest;
            };
            require(stream.next(read).bytes==first,"fragmented frame changed");
            require(stream.next(read).bytes==second&&reads==2,"merged frame changed");
            bad=first;bad[0]^=1;Stream bad_header;
            rejects([&]{bad_header.next([&]{return bad;});});
            bad=first;put32(bad.data()+20,MaxPayload+1);Stream bad_length;
            rejects([&]{bad_length.next([&]{return bad;});});
        }
        std::cout<<"payload, sequence, fragment, merge, magic and length checks passed\n";
        return 0;
    } catch(const std::exception& e) { std::cerr<<e.what()<<'\n';return 1; }
}
