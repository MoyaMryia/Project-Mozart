#define _POSIX_C_SOURCE 200809L
#include "duplex_common.hpp"
#include <cerrno>
#include <csignal>
#include <filesystem>
#include <fcntl.h>
#include <iostream>
#include <poll.h>
#include <unistd.h>
using namespace duplex;
namespace {
volatile sig_atomic_t interrupted=0;
void on_signal(int) { interrupted=1; }
struct Endpoints {
    int input=-1,output=-1;
    std::mutex write_mutex;
    Failure& failure;
    explicit Endpoints(Failure& f):failure(f) {
        input=open("/dev/ffs-mozart/ep3",O_RDONLY|O_NONBLOCK);
        require(input>=0,"open ep3 failed");
        output=open("/dev/ffs-mozart/ep4",O_WRONLY|O_NONBLOCK);
        if(output<0) { close(input); throw std::runtime_error("open ep4 failed"); }
    }
    ~Endpoints() { if(input>=0) close(input); if(output>=0) close(output); }
    void check() { require(!interrupted,"probe interrupted"); failure.check(); }
    std::vector<uint8_t> read() {
        auto deadline=std::chrono::steady_clock::now()+std::chrono::milliseconds(IoTimeoutMs);
        while(true) {
            check();require(std::chrono::steady_clock::now()<deadline,"endpoint input timeout");
            pollfd p{input,POLLIN,0};int ready=poll(&p,1,100);
            if(ready<0&&errno==EINTR) continue;
            require(ready>=0,"endpoint input poll failed");
            if(!ready) continue;
            std::vector<uint8_t> bytes(65536);ssize_t n=::read(input,bytes.data(),bytes.size());
            if(n<0&&(errno==EAGAIN||errno==EINTR)) continue;
            require(n>0,"endpoint read failed");bytes.resize(size_t(n));return bytes;
        }
    }
    void write(const std::vector<uint8_t>& bytes) {
        std::lock_guard<std::mutex> lock(write_mutex);
        size_t done=0;auto deadline=std::chrono::steady_clock::now()+std::chrono::milliseconds(IoTimeoutMs);
        while(done<bytes.size()) {
            check();require(std::chrono::steady_clock::now()<deadline,"endpoint output timeout");
            ssize_t n=::write(output,bytes.data()+done,bytes.size()-done);
            if(n<0&&(errno==EAGAIN||errno==EINTR)) { std::this_thread::sleep_for(std::chrono::microseconds(50));continue; }
            require(n>0,"endpoint write failed");done+=size_t(n);
        }
    }
};
void run(const std::string& directory) {
    std::filesystem::create_directories(directory);
    Failure failure;Endpoints io(failure);Stream stream;
    auto start=stream.next([&] { return io.read(); });
    const auto& p=start.bytes;
    require(p[3]==1&&p[5]==1&&get32(p.data()+8)==0xffffffffu&&get64(p.data()+12)==0&&p.size()==Header+8,"invalid start control");
    unsigned block=get32(p.data()+Header),total=get32(p.data()+Header+4);
    require(allowed_block(block)&&total>=1&&total<=MaxSeconds*Rate/SmallBlock,"invalid stream configuration");
    io.write(p);
    std::vector<int64_t> send_late(total),received_at(total);
    unsigned sent=0,received=0,pings=0;
    std::thread sender([&] {
        try {
            int64_t epoch=now()+20'000'000;
            for(unsigned i=0;i<total;i++) {
                int64_t target=epoch+int64_t(i)*block*1'000'000'000/Rate;
                sleep_to(target);io.check();
                auto bytes=audio(i,block,JetsonSeed);
                send_late[i]=now()-target;
                io.write(bytes);sent++;
            }
        } catch(const std::exception&) { failure.record(); }
    });
    try {
        while(true) {
            auto frame=stream.next([&] { return io.read(); });const auto& b=frame.bytes;
            if(b[3]==0) {
                check_audio(b,received,block,HostSeed);require(received<total,"excess host packets");
                received_at[received++]=frame.arrived;
            } else if(b[3]==1&&b[5]==3&&b.size()==Header) {
                require(get32(b.data()+8)==pings&&get64(b.data()+12)>0,"invalid ping sequence");
                io.write(b);pings++;
            } else {
                require(b[3]==1&&b[5]==2&&b.size()==Header&&get32(b.data()+8)==0xffffffffu&&get64(b.data()+12)==0,"invalid end control");
                require(received==total,"missing host audio packets");break;
            }
        }
    } catch(const std::exception&) { failure.record(); }
    sender.join();
    bool success=!failure.stopped.load();
    if(success) {
        auto ack=packet(1,2,0xffffffffu,0,8);put32(ack.data()+Header,received);put32(ack.data()+Header+4,sent);
        try { io.write(ack); } catch(const std::exception&) { failure.record();success=false; }
    }
    save_times(directory+"/send-lateness.csv",send_late,sent);
    save_times(directory+"/received.csv",received_at,received);
    std::ofstream status(directory+"/status.txt");
    status<<"success="<<success<<"\nblock="<<block<<"\ntotal="<<total<<"\nsent="<<sent<<"\nreceived="<<received<<"\npings="<<pings<<'\n';
    if(!success) {
        try { failure.check(); } catch(const std::exception& e) { status<<"error="<<e.what()<<'\n';throw; }
    }
    std::cout<<"success="<<success<<" sent="<<sent<<" received="<<received<<" pings="<<pings<<'\n';
}
}
int main(int argc,char** argv) {
    struct sigaction action{};action.sa_handler=on_signal;sigemptyset(&action.sa_mask);
    sigaction(SIGTERM,&action,nullptr);sigaction(SIGINT,&action,nullptr);
    try { require(argc==2,"usage: duplex-jetson OUTPUT_DIR");run(argv[1]);return 0; }
    catch(const std::exception& e) { std::cerr<<"FAIL: "<<e.what()<<'\n';return 1; }
}
