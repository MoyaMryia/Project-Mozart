#include "host_usb.hpp"
#include <filesystem>
#include <iostream>
using namespace duplex;
namespace {

void run(unsigned block,unsigned seconds,const std::string& directory) {
    std::filesystem::create_directories(directory);
    unsigned total=seconds*Rate/block,ping_count=(total+PingEvery-1)/PingEvery;
    Usb io;Stream stream;
    auto start=packet(1,1,0xffffffffu,0,8);put32(start.data()+Header,block);put32(start.data()+Header+4,total);io.write(start);
    require(stream.next([&]{return io.read();}).bytes==start,"start acknowledgement mismatch");
    Failure failure;
    std::vector<int64_t> send_late(total),received_at(total),ping_sent(ping_count),ping_arrived(ping_count);
    std::vector<uint64_t> ping_stamp(ping_count);
    unsigned sent=0,received=0,pings_sent=0,pings_received=0;
    std::thread sender([&] {
        try {
            int64_t epoch=now()+20'000'000;
            for(unsigned i=0;i<total;i++) {
                int64_t target=epoch+int64_t(i)*block*1'000'000'000/Rate;
                sleep_to(target);failure.check();
                auto bytes=audio(i,block,HostSeed);send_late[i]=now()-target;
                io.write(bytes);sent++;
                if(i%PingEvery==0) {
                    unsigned id=i/PingEvery;ping_sent[id]=now();
                    auto ping=packet(1,3,id,uint64_t(ping_sent[id]/1000),0);
                    io.write(ping);pings_sent++;
                }
            }
            auto end=packet(1,2,0xffffffffu,0,0);io.write(end);
        } catch(const std::exception&) { failure.record(); }
    });
    try {
        while(true) {
            failure.check();auto frame=stream.next([&]{return io.read();});const auto& b=frame.bytes;
            if(b[3]==0) {
                check_audio(b,received,block,JetsonSeed);require(received<total,"excess Jetson audio packets");
                received_at[received++]=frame.arrived;
            } else if(b[3]==1&&b[5]==3&&b.size()==Header) {
                require(get32(b.data()+8)==pings_received&&pings_received<ping_count,"invalid returned ping sequence");
                ping_stamp[pings_received]=get64(b.data()+12);ping_arrived[pings_received++]=frame.arrived;
            } else {
                require(b[3]==1&&b[5]==2&&get32(b.data()+8)==0xffffffffu&&get64(b.data()+12)==0&&b.size()==Header+8,"invalid end acknowledgement");
                require(received==total&&get32(b.data()+Header)==total&&get32(b.data()+Header+4)==total,"audio packet coverage mismatch");
                require(pings_received==ping_count,"missing returned pings");break;
            }
        }
    } catch(const std::exception&) { failure.record(); }
    sender.join();
    bool success=!failure.stopped.load();std::string message;
    if(success) {
        try {
            require(sent==total&&pings_sent==ping_count,"transmit coverage mismatch");
            for(unsigned i=0;i<ping_count;i++) require(ping_stamp[i]==uint64_t(ping_sent[i]/1000)&&ping_arrived[i]>=ping_sent[i],"ping timestamp mismatch");
        } catch(const std::exception&) { failure.record();success=false; }
    }
    if(!success) { try { failure.check(); } catch(const std::exception& e) { message=e.what(); } }
    save_times(directory+"/send-lateness.csv",send_late,sent);save_times(directory+"/received.csv",received_at,received);
    std::ofstream ping_file(directory+"/pings.csv");ping_file<<"seq,send_ns,receive_ns,rtt_ns\n";
    for(unsigned i=0;i<pings_received;i++) ping_file<<i<<','<<ping_sent[i]<<','<<ping_arrived[i]<<','<<ping_arrived[i]-ping_sent[i]<<'\n';
    std::ofstream status(directory+"/status.txt");
    status<<"success="<<success<<"\nerror="<<message<<"\nblock="<<block<<"\nseconds="<<seconds
          <<"\nsent="<<sent<<"\nreceived="<<received<<"\npings_sent="<<pings_sent<<"\npings_received="<<pings_received<<'\n';
    require(bool(status)&&bool(ping_file),"failed to write results");
    std::cout<<"success="<<success<<" sent="<<sent<<" received="<<received<<" pings="<<pings_received<<'\n';
    require(success,message);
}
}
int main(int argc,char** argv) {
    try {
        require(argc==4,"usage: duplex-host BLOCK SECONDS OUTPUT_DIR");
        auto number=[](const std::string& text) {
            size_t end=0;auto value=std::stoul(text,&end);
            require(end==text.size(),"invalid integer argument");return value;
        };
        auto block=number(argv[1]),seconds=number(argv[2]);
        require(allowed_block(block)&&seconds>=1&&seconds<=MaxSeconds,"invalid block or duration");
        run(unsigned(block),unsigned(seconds),argv[3]);return 0;
    } catch(const std::exception& e) { std::cerr<<"FAIL: "<<e.what()<<'\n';return 1; }
}
