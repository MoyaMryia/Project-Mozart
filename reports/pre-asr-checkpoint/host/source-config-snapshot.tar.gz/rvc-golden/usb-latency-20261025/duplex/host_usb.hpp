#pragma once
#include "duplex_common.hpp"
#include <libusb-1.0/libusb.h>
#include <iostream>
namespace duplex {
struct Usb {
    libusb_context* context=nullptr;
    libusb_device_handle* handle=nullptr;
    uint8_t out=0,in=0;
    bool claimed=false;
    Usb() {
        try {
            require(libusb_init(&context)==0,"libusb init failed");
            handle=libusb_open_device_with_vid_pid(context,0x1d6b,0x0105);
            require(handle!=nullptr,"USB 1d6b:0105 not available");
            libusb_device* device=libusb_get_device(handle);
            require(libusb_get_device_speed(device)>=LIBUSB_SPEED_HIGH,"USB high speed required");
            std::cerr<<"bus="<<unsigned(libusb_get_bus_number(device))<<" address="<<unsigned(libusb_get_device_address(device))<<'\n';
            libusb_config_descriptor* config=nullptr;
            require(libusb_get_active_config_descriptor(device,&config)==0,"active configuration unavailable");
            for(unsigned i=0;i<config->bNumInterfaces;i++) for(int a=0;a<config->interface[i].num_altsetting;a++) {
                const auto& alt=config->interface[i].altsetting[a];
                if(alt.bInterfaceNumber!=1||alt.bAlternateSetting!=0) continue;
                for(unsigned e=0;e<alt.bNumEndpoints;e++) {
                    const auto& ep=alt.endpoint[e];
                    if((ep.bmAttributes&3)!=LIBUSB_TRANSFER_TYPE_BULK) continue;
                    if(ep.bEndpointAddress&0x80) in=ep.bEndpointAddress; else out=ep.bEndpointAddress;
                }
            }
            libusb_free_config_descriptor(config);
            require(out&&in,"interface 1 bulk endpoints missing");
            int rc=libusb_claim_interface(handle,1);
            require(rc==0,std::string("claim interface: ")+libusb_error_name(rc));claimed=true;
        } catch(const std::exception&) { release();throw; }
    }
    void release() {
        if(handle) { if(claimed) libusb_release_interface(handle,1);libusb_close(handle);handle=nullptr; }
        if(context) { libusb_exit(context);context=nullptr; }
    }
    ~Usb() { release(); }
    void write(std::vector<uint8_t>& bytes) {
        int count=0,rc=libusb_bulk_transfer(handle,out,bytes.data(),int(bytes.size()),&count,IoTimeoutMs);
        require(rc==0,std::string("USB write: ")+libusb_error_name(rc));require(count==int(bytes.size()),"short USB write");
    }
    std::vector<uint8_t> read() {
        std::vector<uint8_t> bytes(65536);int count=0;
        int rc=libusb_bulk_transfer(handle,in,bytes.data(),int(bytes.size()),&count,IoTimeoutMs);
        require(rc==0,std::string("USB read: ")+libusb_error_name(rc));require(count>0,"empty USB read");bytes.resize(size_t(count));return bytes;
    }
};
}
