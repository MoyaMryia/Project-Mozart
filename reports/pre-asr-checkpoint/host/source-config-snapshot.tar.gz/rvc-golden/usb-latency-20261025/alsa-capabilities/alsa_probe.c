#include <alsa/asoundlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *device = "hw:CARD=sofhdadsp,DEV=%d";
static int first = 1;

static void begin_record(void) { if (!first) puts(","); first = 0; }
static void error_json(const char *call, int err) {
    printf("\"error\":{\"call\":\"%s\",\"code\":%d,\"message\":\"%s\"}", call, err, snd_strerror(err));
}
static int fail(const char *call, int err) {
    error_json(call, err);
    return 0;
}

static void query_device(int dev, const char *direction) {
    char name[128];
    snd_pcm_t *pcm = NULL;
    snd_pcm_hw_params_t *p;
    int err;
    snd_pcm_stream_t stream = !strcmp(direction, "capture") ? SND_PCM_STREAM_CAPTURE : SND_PCM_STREAM_PLAYBACK;
    snprintf(name, sizeof(name), device, dev);
    begin_record();
    printf("{\"kind\":\"capabilities\",\"device\":\"%s\",\"direction\":\"%s\",", name, direction);
    err = snd_pcm_open(&pcm, name, stream, SND_PCM_NONBLOCK);
    if (err < 0) { fail("snd_pcm_open(NONBLOCK)", err); printf("}"); return; }
    snd_pcm_hw_params_alloca(&p);
    err = snd_pcm_hw_params_any(pcm, p);
    if (err < 0) { fail("snd_pcm_hw_params_any", err); snd_pcm_close(pcm); printf("}"); return; }
    unsigned int cmin, cmax, rmin, rmax;
    snd_pcm_uframes_t pmin, pmax, bmin, bmax;
    int dir = 0;
    snd_pcm_hw_params_get_channels_min(p, &cmin); snd_pcm_hw_params_get_channels_max(p, &cmax);
    snd_pcm_hw_params_get_rate_min(p, &rmin, &dir); dir = 0; snd_pcm_hw_params_get_rate_max(p, &rmax, &dir);
    snd_pcm_hw_params_get_period_size_min(p, &pmin, &dir); dir = 0; snd_pcm_hw_params_get_period_size_max(p, &pmax, &dir);
    snd_pcm_hw_params_get_buffer_size_min(p, &bmin); snd_pcm_hw_params_get_buffer_size_max(p, &bmax);
    printf("\"status\":\"ok\",\"channels\":[%u,%u],\"rate_hz\":[%u,%u],\"period_frames\":[%lu,%lu],\"buffer_frames\":[%lu,%lu],\"formats\":{\"S16_LE\":%s,\"S32_LE\":%s}}",
       cmin,cmax,rmin,rmax,(unsigned long)pmin,(unsigned long)pmax,(unsigned long)bmin,(unsigned long)bmax,
       snd_pcm_hw_params_test_format(pcm,p,SND_PCM_FORMAT_S16_LE)==0?"true":"false",
       snd_pcm_hw_params_test_format(pcm,p,SND_PCM_FORMAT_S32_LE)==0?"true":"false");
    snd_pcm_close(pcm);
}

static int call_config(int err, const char *call) { if (err < 0) { fail(call, err); return 0; } return 1; }
static void configure(int dev, const char *direction, snd_pcm_format_t format,
                      const char *format_name, unsigned int channels,
                      unsigned int period_req, unsigned int periods_req, int dmic) {
    char name[128];
    snd_pcm_t *pcm = NULL;
    snd_pcm_hw_params_t *p;
    snd_pcm_stream_t stream = !strcmp(direction, "capture") ? SND_PCM_STREAM_CAPTURE : SND_PCM_STREAM_PLAYBACK;
    snprintf(name, sizeof(name), device, dev);
    begin_record();
    printf("{\"kind\":\"configuration\",\"device\":\"%s\",\"direction\":\"%s\",\"format_requested\":\"%s\",\"rate_requested_hz\":48000,\"channels_requested\":%u,\"period_requested_frames\":%u,\"periods_requested\":%u,\"buffer_requested_frames\":%u,",
           name,direction,format_name,channels,period_req,periods_req,period_req*periods_req);
    int err=snd_pcm_open(&pcm,name,stream,SND_PCM_NONBLOCK);
    if(err<0){fail("snd_pcm_open(NONBLOCK)",err); printf("}");return;}
    snd_pcm_hw_params_alloca(&p);
    err=snd_pcm_hw_params_any(pcm,p);
    if(err<0){fail("snd_pcm_hw_params_any",err);goto done;}
#define TRY(expr,label) do { if(!call_config((expr),(label))) goto done; } while(0)
    TRY(snd_pcm_hw_params_set_access(pcm,p,SND_PCM_ACCESS_RW_INTERLEAVED),"snd_pcm_hw_params_set_access(RW_INTERLEAVED)");
    TRY(snd_pcm_hw_params_set_format(pcm,p,format),"snd_pcm_hw_params_set_format");
    TRY(snd_pcm_hw_params_set_rate(pcm,p,48000,0),"snd_pcm_hw_params_set_rate(48000 exact)");
    TRY(snd_pcm_hw_params_set_channels(pcm,p,channels),"snd_pcm_hw_params_set_channels");
    snd_pcm_uframes_t period=period_req, buffer=(snd_pcm_uframes_t)period_req*periods_req;
    int dir=0;
    TRY(snd_pcm_hw_params_set_period_size_near(pcm,p,&period,&dir),"snd_pcm_hw_params_set_period_size_near");
    TRY(snd_pcm_hw_params_set_buffer_size_near(pcm,p,&buffer),"snd_pcm_hw_params_set_buffer_size_near");
    TRY(snd_pcm_hw_params(pcm,p),"snd_pcm_hw_params");
    snd_pcm_hw_params_get_period_size(p,&period,&dir);
    snd_pcm_hw_params_get_buffer_size(p,&buffer);
    unsigned int rate=0, ch=0; snd_pcm_format_t actual_fmt;
    snd_pcm_hw_params_get_rate(p,&rate,&dir); snd_pcm_hw_params_get_channels(p,&ch); snd_pcm_hw_params_get_format(p,&actual_fmt);
    printf("\"status\":\"configured_no_io\",\"negotiated\":{\"format\":\"%s\",\"rate_hz\":%u,\"channels\":%u,\"period_frames\":%lu,\"buffer_frames\":%lu,\"periods\":%.6f},\"io\":\"no read/write calls; closed immediately\"",
       snd_pcm_format_name(actual_fmt),rate,ch,(unsigned long)period,(unsigned long)buffer,period?(double)buffer/(double)period:0.0);
    if(dmic) printf(",\"note\":\"configuration only; no capture\"");
done:
    if(err<0) { /* parameter call errors were already emitted */ }
    snd_pcm_close(pcm);
    printf("}");
}

int main(void) {
    puts("{\"probe\":\"ALSA hw capability and parameter negotiation\",\"nonblocking\":true,\"records\":[");
    query_device(0,"capture");
    query_device(6,"capture");
    query_device(0,"playback");
    const unsigned int periods[]={2,3,4};
    const unsigned int sizes[]={64,128};
    for(unsigned int s=0;s<2;s++) for(unsigned int n=0;n<3;n++)
        configure(0,"capture",SND_PCM_FORMAT_S16_LE,"S16_LE",2,sizes[s],periods[n],0);
    configure(6,"capture",SND_PCM_FORMAT_S32_LE,"S32_LE",4,64,2,1);
    puts("],\"io_performed\":false}");
    return 0;
}
