#define _GNU_SOURCE
#include "mozart/dsp.h"

#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define RATE 48000u
#define WARMUP_BLOCKS 5000u
#define MEASURE_BLOCKS 100000u
#define PACED_SECONDS 5u
#define OUTPUT_CAP 2048u

typedef struct { uint64_t wall_ns, cpu_ns; } sample_t;

static void fail(const char *what)
{
    fprintf(stderr, "FAIL: %s (errno=%d: %s)\n", what, errno, strerror(errno));
    exit(2);
}

static uint64_t ns_time(clockid_t id)
{
    struct timespec ts;
    if (clock_gettime(id, &ts) != 0) fail("clock_gettime");
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static mozart_dsp_t *new_dsp(int shaping)
{
    const mozart_dsp_config_t cfg = {
        .denoise = true, .gate = shaping != 0,
        .agc = shaping != 0, .limiter = shaping != 0
    };
    mozart_dsp_t *d = mozart_dsp_new(&cfg);
    if (!d) fail("mozart_dsp_new");
    return d;
}

static uint64_t mix64(uint64_t x)
{
    x += 0x9e3779b97f4a7c15ull;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ull;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebull;
    return x ^ (x >> 31);
}

static void fill_input(float *input, size_t n, uint64_t offset)
{
    for (size_t i = 0; i < n; ++i) {
        const uint64_t k = offset + i;
        const double noise = (double)(mix64(k) >> 11) * (1.0 / 9007199254740992.0) * 2.0 - 1.0;
        const double a = 2.0 * 3.14159265358979323846 * 431.0 * (double)k / RATE;
        const double b = 2.0 * 3.14159265358979323846 * 2711.0 * (double)k / RATE;
        const double c = 2.0 * 3.14159265358979323846 * 9137.0 * (double)k / RATE;
        input[i] = (float)(0.12 * noise + 0.12 * sin(a) + 0.08 * sin(b) + 0.05 * sin(c));
        if (!isfinite(input[i])) fail("non-finite deterministic input");
    }
}

static size_t call_once(mozart_dsp_t *d, const float *in, size_t n, float *out)
{
    const size_t written = mozart_dsp_enhance(d, in, n, out, OUTPUT_CAP);
    if (written == SIZE_MAX) fail("mozart_dsp_enhance returned SIZE_MAX");
    if (written > OUTPUT_CAP) fail("enhance output exceeds capacity");
    for (size_t i = 0; i < n; ++i)
        if (!isfinite(in[i])) fail("non-finite input sample");
    for (size_t i = 0; i < written; ++i)
        if (!isfinite(out[i])) fail("non-finite output sample");
    return written;
}

static int cmp_u64(const void *a, const void *b)
{
    const uint64_t x = *(const uint64_t *)a, y = *(const uint64_t *)b;
    return (x > y) - (x < y);
}

static uint64_t percentile(const uint64_t *sorted, size_t n, unsigned pct)
{
    size_t i = (n * pct + 99) / 100;
    if (i == 0) i = 1;
    return sorted[i - 1];
}

static void report_stats(FILE *json, const char *name, const sample_t *s, size_t n,
                         uint64_t late_count, uint64_t max_late)
{
    uint64_t *wall = malloc(n * sizeof(*wall));
    uint64_t *cpu = malloc(n * sizeof(*cpu));
    if (!wall || !cpu) fail("stats allocation");
    for (size_t i = 0; i < n; ++i) { wall[i] = s[i].wall_ns; cpu[i] = s[i].cpu_ns; }
    qsort(wall, n, sizeof(*wall), cmp_u64);
    qsort(cpu, n, sizeof(*cpu), cmp_u64);
    fprintf(json, "    {\"name\":\"%s\",\"blocks\":%zu,", name, n);
    fprintf(json, "\"wall_ns\":{\"p50\":%llu,\"p95\":%llu,\"p99\":%llu,\"max\":%llu},",
            (unsigned long long)percentile(wall,n,50), (unsigned long long)percentile(wall,n,95),
            (unsigned long long)percentile(wall,n,99), (unsigned long long)wall[n-1]);
    fprintf(json, "\"thread_cpu_ns\":{\"p50\":%llu,\"p95\":%llu,\"p99\":%llu,\"max\":%llu},",
            (unsigned long long)percentile(cpu,n,50), (unsigned long long)percentile(cpu,n,95),
            (unsigned long long)percentile(cpu,n,99), (unsigned long long)cpu[n-1]);
    fprintf(json, "\"deadline_misses\":%llu,\"max_lateness_ns\":%llu}%s\n",
            (unsigned long long)late_count, (unsigned long long)max_late, "");
    free(wall); free(cpu);
}

static void write_first(FILE *first, const char *label, size_t n, size_t block,
                        size_t written, const float *out)
{
    for (size_t j = 0; j < written; ++j)
        fprintf(first, "%s,%zu,%zu,%zu,%.9g\n", label, n, block, written, out[j]);
}

static void run_tight(FILE *csv, FILE *first, FILE *json, size_t n, int shaping)
{
    float *in = malloc(n * sizeof(*in)), *out = malloc(OUTPUT_CAP * sizeof(*out));
    sample_t *times = malloc(MEASURE_BLOCKS * sizeof(*times));
    if (!in || !out || !times) fail("tight allocation");
    mozart_dsp_t *d = new_dsp(shaping);
    uint64_t offset = 0;
    int startup_first = 0;
    char startup_label[64];
    snprintf(startup_label, sizeof(startup_label), "startup_%s", shaping ? "shaping" : "denoise_only");
    for (size_t i = 0; i < WARMUP_BLOCKS; ++i) {
        fill_input(in, n, offset); offset += n;
        const size_t written = call_once(d, in, n, out);
        if (!startup_first && written) {
            write_first(first, startup_label, n, i, written, out);
            startup_first = 1;
        }
    }
    if (!startup_first) fail("no startup emission during warmup");
    int got_first = 0;
    const char *label = shaping ? "shaping" : "denoise_only";
    for (size_t i = 0; i < MEASURE_BLOCKS; ++i) {
        fill_input(in, n, offset); offset += n;
        const uint64_t w0 = ns_time(CLOCK_MONOTONIC_RAW);
        const uint64_t c0 = ns_time(CLOCK_THREAD_CPUTIME_ID);
        const size_t written = mozart_dsp_enhance(d, in, n, out, OUTPUT_CAP);
        const uint64_t c1 = ns_time(CLOCK_THREAD_CPUTIME_ID);
        const uint64_t w1 = ns_time(CLOCK_MONOTONIC_RAW);
        if (written == SIZE_MAX) fail("mozart_dsp_enhance returned SIZE_MAX");
        if (written > OUTPUT_CAP) fail("enhance output exceeds capacity");
        if (written != n) fail("steady-state output count differs from input block");
        for (size_t j = 0; j < n; ++j) if (!isfinite(in[j])) fail("non-finite input sample");
        for (size_t j = 0; j < written; ++j) if (!isfinite(out[j])) fail("non-finite output sample");
        times[i] = (sample_t){w1-w0, c1-c0};
        fprintf(csv, "%s,%zu,%zu,%zu,%llu,%llu\n", label, n, i, written,
                (unsigned long long)times[i].wall_ns, (unsigned long long)times[i].cpu_ns);
        if (!got_first && written) {
            write_first(first, label, n, i, written, out);
            got_first = 1;
        }
    }
    if (!got_first) fail("no first emitted output in measured blocks");
    char name[64]; snprintf(name, sizeof(name), "tight_%s_%zu", label, n);
    report_stats(json, name, times, MEASURE_BLOCKS, 0, 0);
    mozart_dsp_free(d); free(in); free(out); free(times);
}

static void run_paced(FILE *csv, FILE *first, FILE *json, size_t n)
{
    const size_t count = (size_t)(RATE / n) * PACED_SECONDS;
    float *in = malloc(n * sizeof(*in)), *out = malloc(OUTPUT_CAP * sizeof(*out));
    sample_t *times = malloc(count * sizeof(*times));
    if (!in || !out || !times) fail("paced allocation");
    mozart_dsp_t *d = new_dsp(0);
    uint64_t offset = 0;
    for (size_t i = 0; i < WARMUP_BLOCKS; ++i) {
        fill_input(in, n, offset); offset += n;
        (void)call_once(d, in, n, out);
    }
    const uint64_t interval = ((uint64_t)n * 1000000000ull) / RATE;
    struct timespec next;
    if (clock_gettime(CLOCK_MONOTONIC, &next) != 0) fail("clock_gettime paced start");
    uint64_t late_count = 0, max_late = 0;
    int got_first = 0;
    for (size_t i = 0; i < count; ++i) {
        next.tv_nsec += (long)interval;
        while (next.tv_nsec >= 1000000000L) { next.tv_sec++; next.tv_nsec -= 1000000000L; }
        int rc;
        do { rc = clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, NULL); } while (rc == EINTR);
        if (rc != 0) { errno = rc; fail("clock_nanosleep"); }
        struct timespec started;
        if (clock_gettime(CLOCK_MONOTONIC, &started) != 0) fail("clock_gettime paced start sample");
        int64_t start_lateness = ((int64_t)started.tv_sec - (int64_t)next.tv_sec) * 1000000000ll + (started.tv_nsec - next.tv_nsec);
        fill_input(in, n, offset); offset += n;
        const uint64_t w0 = ns_time(CLOCK_MONOTONIC_RAW);
        const uint64_t c0 = ns_time(CLOCK_THREAD_CPUTIME_ID);
        const size_t written = mozart_dsp_enhance(d, in, n, out, OUTPUT_CAP);
        const uint64_t c1 = ns_time(CLOCK_THREAD_CPUTIME_ID);
        const uint64_t w1 = ns_time(CLOCK_MONOTONIC_RAW);
        if (written == SIZE_MAX) fail("paced enhance returned SIZE_MAX");
        if (written > OUTPUT_CAP) fail("paced output exceeds capacity");
        if (written != n) fail("paced steady-state output count differs from input block");
        for (size_t j = 0; j < n; ++j) if (!isfinite(in[j])) fail("paced non-finite input");
        for (size_t j = 0; j < written; ++j) if (!isfinite(out[j])) fail("paced non-finite output");
        times[i] = (sample_t){w1-w0,c1-c0};
        struct timespec now;
        if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) fail("clock_gettime paced completion");
        struct timespec deadline = next;
        deadline.tv_nsec += (long)interval;
        while (deadline.tv_nsec >= 1000000000L) { deadline.tv_sec++; deadline.tv_nsec -= 1000000000L; }
        int64_t completion_lateness = ((int64_t)now.tv_sec - (int64_t)deadline.tv_sec) * 1000000000ll + (now.tv_nsec - deadline.tv_nsec);
        if (completion_lateness > 0) { late_count++; if ((uint64_t)completion_lateness > max_late) max_late = (uint64_t)completion_lateness; }
        fprintf(csv, "denoise_only,%zu,%zu,%zu,%llu,%llu,%lld,%lld\n", n, i, written,
                (unsigned long long)times[i].wall_ns, (unsigned long long)times[i].cpu_ns,
                (long long)start_lateness, (long long)completion_lateness);
        if (!got_first && written) {
            write_first(first, "paced_denoise_only", n, i, written, out);
            got_first = 1;
        }
    }
    if (!got_first) fail("paced run produced no output");
    char name[64]; snprintf(name, sizeof(name), "paced_denoise_only_%zu", n);
    report_stats(json, name, times, count, late_count, max_late);
    mozart_dsp_free(d); free(in); free(out); free(times);
}

int main(void)
{
    const char *dir = "/tmp/mozart-pre-cpu-20261025";
    char path[256];
    snprintf(path,sizeof(path),"%s/tight.csv",dir); FILE *tight=fopen(path,"w"); if(!tight) fail("open tight.csv");
    snprintf(path,sizeof(path),"%s/paced.csv",dir); FILE *paced=fopen(path,"w"); if(!paced) fail("open paced.csv");
    snprintf(path,sizeof(path),"%s/first-output.csv",dir); FILE *first=fopen(path,"w"); if(!first) fail("open first-output.csv");
    snprintf(path,sizeof(path),"%s/results.json",dir); FILE *json=fopen(path,"w"); if(!json) fail("open results.json");
    fprintf(tight,"stages,block_samples,block_index,output_samples,wall_ns,thread_cpu_ns\n");
    fprintf(paced,"stages,block_samples,block_index,output_samples,wall_ns,thread_cpu_ns,start_lateness_ns,completion_lateness_ns\n");
    fprintf(first,"run,block_samples,first_emit_block,emitted_samples,sample_value\n");
    fprintf(json,"{\n  \"head\":\"5b20c6029b9a091e43292284c544e8023397669f\",\n  \"rate_hz\":48000,\n  \"warmup_blocks_per_tight_config\":%u,\n  \"paced_warmup_blocks\":%u,\n  \"tight_blocks_per_config\":%u,\n  \"paced_seconds_per_block_size\":%u,\n  \"wall_clock_note\":\"wall_ns includes two CLOCK_THREAD_CPUTIME_ID calls\",\n  \"results\":[\n", WARMUP_BLOCKS, WARMUP_BLOCKS, MEASURE_BLOCKS, PACED_SECONDS);
    run_tight(tight,first,json,64,0); fprintf(json,"    ,");
    run_tight(tight,first,json,128,0); fprintf(json,"    ,");
    run_tight(tight,first,json,64,1); fprintf(json,"    ,");
    run_tight(tight,first,json,128,1); fprintf(json,"    ,");
    run_paced(paced,first,json,64); fprintf(json,"    ,");
    run_paced(paced,first,json,128);
    fprintf(json,"  ]\n}\n");
    if (fclose(tight)||fclose(paced)||fclose(first)||fclose(json)) fail("close output files");
    return 0;
}
