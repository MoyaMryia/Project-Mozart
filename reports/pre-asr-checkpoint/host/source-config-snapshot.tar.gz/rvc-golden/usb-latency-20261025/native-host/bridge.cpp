#include <alsa/asoundlib.h>
#include <libusb-1.0/libusb.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <deque>
#include <limits>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <mutex>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace {
constexpr unsigned Rate = 48000, Header = 24, Warmup = 100, MaxBlock = 128;
constexpr size_t PlaybackQueueCapacity=8;
using Clock = std::chrono::steady_clock;
int64_t now_ns() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now().time_since_epoch()).count();
}
void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}
void alsa_check(int code, const char* operation) {
    if (code < 0) throw std::runtime_error(std::string(operation) + ": " + snd_strerror(code));
}
uint32_t get32(const uint8_t* p) {
    return uint32_t(p[0]) | uint32_t(p[1])<<8 | uint32_t(p[2])<<16 | uint32_t(p[3])<<24;
}
uint64_t get64(const uint8_t* p) {
    return get32(p) | uint64_t(get32(p+4))<<32;
}
void put32(uint8_t* p, uint32_t v) { for (int i=0;i<4;i++) p[i]=uint8_t(v>>(8*i)); }
void make_header(uint8_t* p, unsigned type, unsigned flags, uint32_t seq, uint64_t stamp, uint32_t size) {
    p[0]=0x5a; p[1]=0x4d; p[2]=1; p[3]=uint8_t(type); p[4]=2;
    p[5]=uint8_t(flags); p[6]=p[7]=0; put32(p+8,seq);
    put32(p+12,uint32_t(stamp)); put32(p+16,uint32_t(stamp>>32)); put32(p+20,size);
}
struct Options {
    unsigned block=64, periods=4, prefill=2, seconds=10, mode=0, target=3;
    std::string output="native-output", capture="hw:Loopback,1,2", playback="hw:Loopback,0,3";
    bool fixture=true,queued=false;
};
Options parse(int argc,char** argv) {
    Options o;
    for(int i=1;i<argc;i++) {
        std::string key=argv[i];
        auto value=[&]() { require(++i<argc,"missing argument for "+key); return std::string(argv[i]); };
        auto number=[&]() {
            std::string text=value();size_t end=0;unsigned long result=std::stoul(text,&end);
            require(end==text.size()&&result<=std::numeric_limits<unsigned>::max(),"invalid integer argument");
            return unsigned(result);
        };
        if(key=="--block") o.block=number();
        else if(key=="--periods") o.periods=number();
        else if(key=="--prefill") o.prefill=number();
        else if(key=="--target") o.target=number();
        else if(key=="--seconds") o.seconds=number();
        else if(key=="--mode") { auto s=value(); require(s=="echo"||s=="dsp","invalid mode"); o.mode=s=="dsp"; }
        else if(key=="--output") o.output=value();
        else if(key=="--capture") o.capture=value();
        else if(key=="--playback") o.playback=value();
        else if(key=="--fixture") o.fixture=true;
        else if(key=="--native") o.fixture=false;
        else if(key=="--queued") o.queued=true;
        else throw std::runtime_error("unknown option: "+key);
    }
    require((o.block==64||o.block==128) && o.periods>=3 && o.periods<=16 &&
            o.prefill>=2 && o.prefill<o.periods && (!o.queued||(o.target>=2&&o.target<o.periods)) && o.seconds>=1 && o.seconds<=60,
            "invalid block, periods, prefill or seconds");
    return o;
}
struct Failure {
    std::atomic<bool> failed{false};
    std::mutex mutex;
    std::exception_ptr error;
    void record(std::exception_ptr incoming=std::current_exception()) {
        std::lock_guard<std::mutex> lock(mutex);
        if(!error) error=incoming;
        failed.store(true);
    }
    void check() {
        if(failed.load()) {
            std::lock_guard<std::mutex> lock(mutex);
            std::rethrow_exception(error);
        }
    }
};
struct ThreadJoiner {
    Failure& failure;
    std::array<std::thread*,4> threads;
    ~ThreadJoiner() {
        for(auto* thread:threads) {
            if(thread->joinable()) {
                failure.record(std::make_exception_ptr(std::runtime_error("worker setup interrupted")));
                break;
            }
        }
        for(auto* thread:threads) if(thread->joinable()) thread->join();
    }
};
struct Usb {
    libusb_context* context=nullptr;
    libusb_device_handle* handle=nullptr;
    uint8_t out=0,in=0;
    bool claimed=false;
    Usb() {
        try {
        require(libusb_init(&context)==0,"libusb_init failed");
        handle=libusb_open_device_with_vid_pid(context,0x1d6b,0x0105);
        require(handle!=nullptr,"USB device not available");
        libusb_config_descriptor* config=nullptr;
        require(libusb_get_active_config_descriptor(libusb_get_device(handle),&config)==0,"USB descriptors unavailable");
        for(unsigned i=0;i<config->bNumInterfaces;i++) {
            for(int a=0;a<config->interface[i].num_altsetting;a++) {
                const auto& alt=config->interface[i].altsetting[a];
                if(alt.bInterfaceNumber!=1 || alt.bAlternateSetting!=0) continue;
                for(unsigned e=0;e<alt.bNumEndpoints;e++) {
                    const auto& ep=alt.endpoint[e];
                    if((ep.bmAttributes&3)!=LIBUSB_TRANSFER_TYPE_BULK) continue;
                    if(ep.bEndpointAddress&0x80) in=ep.bEndpointAddress; else out=ep.bEndpointAddress;
                }
            }
        }
        libusb_free_config_descriptor(config);
        require(out&&in,"dedicated bulk endpoints missing");
        int rc=libusb_claim_interface(handle,1);
        require(rc==0,std::string("USB claim: ")+libusb_error_name(rc));
        claimed=true;
        } catch(const std::exception&) { release(); throw; }
    }
    void release() {
        if(handle) { if(claimed) libusb_release_interface(handle,1); libusb_close(handle); handle=nullptr; }
        if(context) { libusb_exit(context); context=nullptr; }
    }
    ~Usb() { release(); }
    void send(uint8_t* data,unsigned bytes) {
        int transferred=0, rc=libusb_bulk_transfer(handle,out,data,int(bytes),&transferred,2000);
        require(rc==0,std::string("USB send: ")+libusb_error_name(rc));
        require(transferred==int(bytes),"short USB send");
    }
    unsigned receive(uint8_t* data,unsigned capacity) {
        int transferred=0, rc=libusb_bulk_transfer(handle,in,data,int(capacity),&transferred,2000);
        require(rc==0,std::string("USB receive: ")+libusb_error_name(rc));
        return unsigned(transferred);
    }
};
struct Pcm {
    snd_pcm_t* pcm=nullptr;
    unsigned block;
    snd_pcm_uframes_t period,buffer;
    std::string name;
    Pcm(const std::string& device,snd_pcm_stream_t direction,unsigned frames,unsigned periods,unsigned prefill)
        :block(frames),period(frames),buffer(frames*periods),name(device) {
        try {
        alsa_check(snd_pcm_open(&pcm,device.c_str(),direction,SND_PCM_NONBLOCK),"PCM open");
        snd_pcm_hw_params_t* hw; snd_pcm_hw_params_alloca(&hw);
        alsa_check(snd_pcm_hw_params_any(pcm,hw),"hw_params_any");
        alsa_check(snd_pcm_hw_params_set_access(pcm,hw,SND_PCM_ACCESS_RW_INTERLEAVED),"access");
        alsa_check(snd_pcm_hw_params_set_format(pcm,hw,SND_PCM_FORMAT_S16_LE),"format");
        alsa_check(snd_pcm_hw_params_set_channels(pcm,hw,2),"channels");
        alsa_check(snd_pcm_hw_params_set_rate(pcm,hw,Rate,0),"rate");
        alsa_check(snd_pcm_hw_params_set_period_size_near(pcm,hw,&period,nullptr),"period");
        alsa_check(snd_pcm_hw_params_set_buffer_size_near(pcm,hw,&buffer),"buffer");
        alsa_check(snd_pcm_hw_params(pcm,hw),"hardware params");
        alsa_check(snd_pcm_hw_params_get_period_size(hw,&period,nullptr),"read period");
        alsa_check(snd_pcm_hw_params_get_buffer_size(hw,&buffer),"read buffer");
        require(period==frames&&buffer==frames*periods,"PCM negotiated different period/buffer");
        snd_pcm_sw_params_t* sw; snd_pcm_sw_params_alloca(&sw);
        alsa_check(snd_pcm_sw_params_current(pcm,sw),"current sw params");
        alsa_check(snd_pcm_sw_params_set_avail_min(pcm,sw,frames),"avail_min");
        alsa_check(snd_pcm_sw_params_set_start_threshold(pcm,sw,direction==SND_PCM_STREAM_PLAYBACK?frames*prefill:1),"start threshold");
        alsa_check(snd_pcm_sw_params_set_stop_threshold(pcm,sw,buffer),"stop threshold");
        alsa_check(snd_pcm_sw_params(pcm,sw),"software params");
        alsa_check(snd_pcm_prepare(pcm),"prepare");
        std::cerr<<device<<" period="<<period<<" buffer="<<buffer<<"\n";
        } catch(const std::exception&) { if(pcm) snd_pcm_close(pcm); throw; }
    }
    ~Pcm() { if(pcm) snd_pcm_close(pcm); }
    void set_target(unsigned periods) {
        snd_pcm_sw_params_t* sw;snd_pcm_sw_params_alloca(&sw);
        alsa_check(snd_pcm_sw_params_current(pcm,sw),"target sw params");
        alsa_check(snd_pcm_sw_params_set_avail_min(pcm,sw,buffer-periods*block+block),"target avail_min");
        alsa_check(snd_pcm_sw_params(pcm,sw),"apply playback target");
    }
    void start() { alsa_check(snd_pcm_start(pcm),"capture start"); }
    long delay() { snd_pcm_sframes_t value=0; alsa_check(snd_pcm_delay(pcm,&value),"PCM delay"); return value; }
    void transfer(int16_t* data,bool capture,Failure& failure) {
        unsigned offset=0;
        auto deadline=Clock::now()+std::chrono::seconds(3);
        while(offset<block) {
            failure.check();
            auto n=capture?snd_pcm_readi(pcm,data+offset*2,block-offset):snd_pcm_writei(pcm,data+offset*2,block-offset);
            if(n==-EAGAIN||n==-EINTR) {
                require(Clock::now()<deadline,"PCM transfer timeout: "+name);
                int rc=snd_pcm_wait(pcm,50);
                if(rc<0&&rc!=-EINTR) alsa_check(rc,"PCM wait");
                continue;
            }
            alsa_check(int(n),capture?"PCM capture":"PCM playback");
            require(n>0,"zero PCM transfer");
            offset+=unsigned(n);
        }
    }
    void drain(Failure& failure) {
        int rc=snd_pcm_drain(pcm);
        if(rc==0) return;
        if(rc!=-EAGAIN) alsa_check(rc,"PCM drain");
        auto deadline=Clock::now()+std::chrono::seconds(3);
        // 非阻塞 drain 只启动一次，随后等待状态完成。
        while(snd_pcm_state(pcm)!=SND_PCM_STATE_SETUP) {
            failure.check();
            require(snd_pcm_state(pcm)==SND_PCM_STATE_DRAINING,"unexpected PCM drain state");
            require(Clock::now()<deadline,"PCM drain timeout");
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
    }
};
struct Trace {
    int64_t capture_end=0,capture_delay=0,receive=0,write_end=0,playback_delay=0;
    bool running=false;
};
struct SinkTrace { size_t start; int64_t end,delay; unsigned count; };
struct PlaybackItem { unsigned seq;std::array<int16_t,MaxBlock*2> samples; };
void save_raw(const std::string& path,const std::vector<int16_t>& samples) {
    std::ofstream output(path,std::ios::binary);
    output.write(reinterpret_cast<const char*>(samples.data()),std::streamsize(samples.size()*2));
    require(bool(output),"failed to save "+path);
}
void run(const Options& o) {
    std::filesystem::create_directories(o.output);
    Usb usb;
    Pcm capture(o.capture,SND_PCM_STREAM_CAPTURE,o.block,o.periods,0);
    Pcm playback(o.playback,SND_PCM_STREAM_PLAYBACK,o.block,o.periods,o.prefill);
    if(o.queued) playback.set_target(o.target);
    std::unique_ptr<Pcm> source,sink;
    if(o.fixture) {
        source=std::make_unique<Pcm>("hw:Loopback,0,2",SND_PCM_STREAM_PLAYBACK,o.block,16,2);
        sink=std::make_unique<Pcm>("hw:Loopback,1,3",SND_PCM_STREAM_CAPTURE,o.block,16,0);
    }
    std::array<uint8_t,Header+8> start{};
    make_header(start.data(),1,1,0xffffffffu,0,8); put32(start.data()+Header,o.mode); put32(start.data()+Header+4,o.block);
    usb.send(start.data(),unsigned(start.size()));
    std::array<uint8_t,Header+8> ack{};
    require(usb.receive(ack.data(),unsigned(ack.size()))==ack.size()&&ack==start,"start acknowledgement mismatch");
    const unsigned total=Warmup+o.seconds*Rate/o.block;
    std::vector<Trace> trace(total);
    std::vector<int16_t> input(size_t(total)*o.block*2),output(size_t(total-Warmup)*o.block*2);
    std::vector<int16_t> generated(input.size()),recorded;
    std::vector<SinkTrace> sink_trace;
    recorded.reserve(input.size()+Rate*2); sink_trace.reserve(total+Rate/o.block);
    uint32_t random=0x16a8bc91;
    for(size_t i=0;i<generated.size()/2;i++) {
        random=1664525*random+1013904223;
        int16_t value=int16_t(int(random>>18)-8192);
        generated[i*2]=generated[i*2+1]=value;
    }
    Failure failure;
    std::atomic<unsigned> submitted{0};
    std::atomic<bool> sink_started{false},sink_finished{false},playback_ready{!o.queued};
    std::mutex queue_mutex;
    std::condition_variable queue_changed;
    std::deque<PlaybackItem> playback_queue;
    bool receive_done=false;
    size_t queue_high_water=0;
    uint64_t startup_silence_frames=0;
    unsigned played=0;
    std::thread source_thread,sink_thread,playback_thread,sender;
    ThreadJoiner joiner{failure,{&source_thread,&sink_thread,&playback_thread,&sender}};
    if(source) source_thread=std::thread([&] {
        try {
            while(!playback_ready.load()) { failure.check();std::this_thread::sleep_for(std::chrono::microseconds(50)); }
            for(unsigned i=0;i<total;i++) source->transfer(generated.data()+size_t(i)*o.block*2,false,failure);
            source->drain(failure);
        } catch(const std::exception&) { failure.record(); }
    });
    if(sink) sink_thread=std::thread([&] {
        try {
            while(!sink_started.load()) { failure.check(); std::this_thread::sleep_for(std::chrono::microseconds(50)); }
            std::array<int16_t,MaxBlock*2> block{};
            while(!sink_finished.load()) {
                auto n=snd_pcm_readi(sink->pcm,block.data(),o.block);
                if(n==-EAGAIN||n==-EINTR) {
                    int rc=snd_pcm_wait(sink->pcm,50);
                    if(rc<0&&rc!=-EINTR) alsa_check(rc,"sink wait");
                    failure.check(); continue;
                }
                alsa_check(int(n),"sink capture"); require(n>0,"empty sink capture");
                int64_t end=now_ns(); long delay=sink->delay();
                sink_trace.push_back({recorded.size()/2,end,delay,unsigned(n)});
                recorded.insert(recorded.end(),block.begin(),block.begin()+n*2);
                require(recorded.size()<=input.size()+Rate*2,"fixture sink exceeds bound");
            }
            auto remaining=snd_pcm_avail_update(sink->pcm);
            alsa_check(int(remaining),"sink trailing availability");
            while(remaining>0) {
                auto n=snd_pcm_readi(sink->pcm,block.data(),std::min<long>(remaining,o.block));
                alsa_check(int(n),"sink tail capture"); require(n>0,"empty sink tail");
                sink_trace.push_back({recorded.size()/2,now_ns(),sink->delay(),unsigned(n)});
                recorded.insert(recorded.end(),block.begin(),block.begin()+n*2);
                remaining-=n;
            }
        } catch(const std::exception&) { failure.record(); }
    });
    if(o.queued) playback_thread=std::thread([&] {
        try {
            if(sink) { sink->start();sink_started.store(true); }
            std::array<int16_t,MaxBlock*2> zeros{};
            for(unsigned i=0;i<o.prefill;i++) {
                playback.transfer(zeros.data(),false,failure);startup_silence_frames+=o.block;
            }
            playback.delay();
            playback_ready.store(true);
            bool live=false;
            const snd_pcm_sframes_t threshold=playback.buffer-o.target*o.block+o.block;
            while(true) {
                failure.check();
                {
                    std::lock_guard<std::mutex> lock(queue_mutex);
                    if(receive_done&&playback_queue.empty()) break;
                }
                auto available=snd_pcm_avail_update(playback.pcm);
                alsa_check(int(available),"playback availability");
                if(available<threshold) { alsa_check(snd_pcm_wait(playback.pcm,50),"target wait");continue; }
                PlaybackItem item{};bool has_item=false;
                {
                    std::unique_lock<std::mutex> lock(queue_mutex);
                    while(live&&playback_queue.empty()&&!receive_done) {
                        queue_changed.wait_for(lock,std::chrono::microseconds(100));
                        lock.unlock();failure.check();playback.delay();lock.lock();
                    }
                    if(!playback_queue.empty()) {
                        item=playback_queue.front();playback_queue.pop_front();has_item=true;
                    } else if(receive_done) break;
                }
                if(!has_item) {
                    playback.transfer(zeros.data(),false,failure);startup_silence_frames+=o.block;continue;
                }
                require(item.seq==Warmup+played,"playback queue sequence mismatch");
                auto* destination=output.data()+size_t(played)*o.block*2;
                memcpy(destination,item.samples.data(),o.block*4);
                playback.transfer(destination,false,failure);
                trace[item.seq].playback_delay=playback.delay();trace[item.seq].write_end=now_ns();
                trace[item.seq].running=snd_pcm_state(playback.pcm)==SND_PCM_STATE_RUNNING;
                played++;live=true;
            }
            playback.drain(failure);
        } catch(const std::exception&) { failure.record(); }
    });
    sender=std::thread([&] {
        try {
            while(!playback_ready.load()) { failure.check();std::this_thread::sleep_for(std::chrono::microseconds(50)); }
            capture.start();
            for(unsigned seq=0;seq<total;seq++) {
                auto* samples=input.data()+size_t(seq)*o.block*2;
                capture.transfer(samples,true,failure);
                trace[seq].capture_end=now_ns(); trace[seq].capture_delay=capture.delay();
                std::array<uint8_t,Header+MaxBlock*4> frame{};
                make_header(frame.data(),0,0,seq,uint64_t(trace[seq].capture_end/1000),o.block*4);
                memcpy(frame.data()+Header,samples,o.block*4);
                submitted.store(seq+1,std::memory_order_release);
                usb.send(frame.data(),Header+o.block*4);
            }
            std::array<uint8_t,Header> end{}; make_header(end.data(),1,2,0xffffffffu,0,0);
            usb.send(end.data(),unsigned(end.size()));
        } catch(const std::exception&) { failure.record(); }
    });
    unsigned received=0;
    bool success=false;
    std::string failure_message;
    try {
        while(true) {
            failure.check();
            std::array<uint8_t,Header+MaxBlock*4> frame{};
            unsigned bytes=usb.receive(frame.data(),Header+o.block*4);
            int64_t arrived=now_ns();
            require(bytes>=Header,"short USB response");
            require(frame[0]==0x5a&&frame[1]==0x4d&&frame[2]==1&&frame[4]==2&&!frame[6]&&!frame[7],"invalid response header");
            unsigned length=get32(frame.data()+20);
            require(bytes==Header+length,"USB response length mismatch");
            if(frame[3]==1) {
                require(frame[5]==2&&get32(frame.data()+8)==0xffffffffu&&get64(frame.data()+12)==0&&length==16,"invalid end acknowledgement");
                require(received==total,"incomplete received packet coverage");
                require(get32(frame.data()+Header)==total*o.block&&get32(frame.data()+Header+4)==total*o.block&&
                        get32(frame.data()+Header+8)==(o.mode?o.block-64:0)&&get32(frame.data()+Header+12)==(o.mode?o.block:0),"incomplete sample coverage");
                break;
            }
            unsigned seq=get32(frame.data()+8);
            require(frame[3]==0&&!frame[5]&&seq==received&&length==o.block*4,"audio sequence mismatch");
            require(submitted.load(std::memory_order_acquire)>seq,"response before submission");
            require(get64(frame.data()+12)==uint64_t(trace[seq].capture_end/1000),"timestamp mismatch");
            trace[seq].receive=arrived; received++;
            if(seq<Warmup) continue;
            if(o.queued) {
                PlaybackItem item{};item.seq=seq;memcpy(item.samples.data(),frame.data()+Header,o.block*4);
                {
                    std::lock_guard<std::mutex> lock(queue_mutex);
                    require(playback_queue.size()<PlaybackQueueCapacity,"playback queue full");
                    playback_queue.push_back(item);queue_high_water=std::max(queue_high_water,playback_queue.size());
                }
                queue_changed.notify_one();continue;
            }
            auto* destination=output.data()+size_t(played)*o.block*2;
            memcpy(destination,frame.data()+Header,o.block*4);
            if(sink&&!sink_started.load()) { sink->start(); sink_started.store(true); }
            playback.transfer(destination,false,failure);
            trace[seq].playback_delay=playback.delay(); trace[seq].write_end=now_ns();
            trace[seq].running=snd_pcm_state(playback.pcm)==SND_PCM_STATE_RUNNING;
            played++;
        }
        if(!o.queued) playback.drain(failure);
        success=true;
    } catch(const std::exception& e) { failure_message=e.what(); failure.record(); }
    {
        std::lock_guard<std::mutex> lock(queue_mutex);receive_done=true;
    }
    queue_changed.notify_one();
    sender.join();
    if(playback_thread.joinable()) playback_thread.join();
    sink_finished.store(true);
    if(source_thread.joinable()) source_thread.join();
    if(sink_thread.joinable()) sink_thread.join();
    if(failure.failed.load()) {
        success=false;
        if(failure_message.empty()) { try { failure.check(); } catch(const std::exception& e) { failure_message=e.what(); } }
    }
    if(success&&played!=total-Warmup) { success=false;failure_message="incomplete played packet coverage"; }
    std::ofstream csv(o.output+"/blocks.csv");
    csv<<"seq,capture_read_end_ns,capture_delay_frames,usb_receive_ns,playwrite_end_ns,playback_delay_frames,running,queue_estimate_ns\n";
    for(unsigned i=0;i<total;i++) {
        const auto& t=trace[i];
        int64_t estimate=t.write_end?t.write_end-t.capture_end+(t.capture_delay+t.playback_delay)*1000000000LL/Rate:0;
        csv<<i<<','<<t.capture_end<<','<<t.capture_delay<<','<<t.receive<<','<<t.write_end<<','<<t.playback_delay<<','<<t.running<<','<<estimate<<'\n';
    }
    std::ofstream sink_csv(o.output+"/sink.csv"); sink_csv<<"sample_start,read_end_ns,delay_frames,samples\n";
    for(const auto& t:sink_trace) sink_csv<<t.start<<','<<t.end<<','<<t.delay<<','<<t.count<<'\n';
    input.resize(size_t(submitted.load())*o.block*2); output.resize(size_t(played)*o.block*2);
    save_raw(o.output+"/capture.raw",input); save_raw(o.output+"/playback.raw",output);
    if(source) { save_raw(o.output+"/source.raw",generated); save_raw(o.output+"/sink.raw",recorded); }
    std::ofstream status(o.output+"/status.txt");
    status<<"success="<<success<<"\nerror="<<failure_message<<"\nblock="<<o.block<<"\nperiods="<<o.periods
          <<"\nprefill="<<o.prefill<<"\nmode="<<o.mode<<"\nfixture="<<o.fixture<<"\nsubmitted="<<submitted.load()
          <<"\nreceived="<<received<<"\nplayed="<<played<<"\nwarmup_excluded="<<Warmup
          <<"\ncapture_buffer="<<capture.buffer<<"\nplayback_buffer="<<playback.buffer
          <<"\nqueued="<<o.queued<<"\ntarget_periods="<<o.target<<"\nqueue_high_water="<<queue_high_water
          <<"\nstartup_silence_frames="<<startup_silence_frames<<'\n';
    require(bool(csv)&&bool(sink_csv)&&bool(status),"output write failed");
    std::cerr<<"success="<<success<<" submitted="<<submitted.load()<<" received="<<received<<" played="<<played<<"\n";
    require(success,failure_message);
}
}
int main(int argc,char** argv) {
    try { run(parse(argc,argv)); return 0; }
    catch(const std::exception& e) { std::cerr<<"FAIL: "<<e.what()<<'\n'; return 1; }
}
