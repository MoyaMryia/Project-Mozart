#define _POSIX_C_SOURCE 200809L
#include <alloca.h>
#include <alsa/asoundlib.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define RATE 48000
#define BLOCKS 300
static void checked(int rc,const char *name) {
    if(rc<0) { fprintf(stderr,"FAIL %s: %s\n",name,snd_strerror(rc));exit(2); }
}
static unsigned integer(const char *text) {
    char *end;errno=0;unsigned long value=strtoul(text,&end,10);
    if(errno||!*text||*end||value>1000) { fprintf(stderr,"invalid integer\n");exit(2); }
    return (unsigned)value;
}
static uint64_t now_ns(void) {
    struct timespec t;checked(clock_gettime(CLOCK_MONOTONIC,&t)==0?0:-errno,"clock_gettime");
    return (uint64_t)t.tv_sec*1000000000ull+t.tv_nsec;
}
int main(int argc,char **argv) {
    if(argc!=5) { fprintf(stderr,"usage: start-probe BLOCK PREFILL PERIODS PREPARED_WAIT_MS\n");return 2; }
    unsigned block=integer(argv[1]),prefill=integer(argv[2]),periods=integer(argv[3]),wait_ms=integer(argv[4]);
    if((block!=64&&block!=128)||periods<3||periods>16||prefill<2||prefill>periods||wait_ms>200) return 2;
    snd_pcm_t *pcm;checked(snd_pcm_open(&pcm,"hw:CARD=sofhdadsp,DEV=0",SND_PCM_STREAM_PLAYBACK,SND_PCM_NONBLOCK),"open");
    snd_pcm_hw_params_t *hw; snd_pcm_hw_params_alloca(&hw);
    checked(snd_pcm_hw_params_any(pcm,hw),"hw_any");
    checked(snd_pcm_hw_params_set_access(pcm,hw,SND_PCM_ACCESS_RW_INTERLEAVED),"access");
    checked(snd_pcm_hw_params_set_format(pcm,hw,SND_PCM_FORMAT_S16_LE),"format");
    checked(snd_pcm_hw_params_set_channels(pcm,hw,2),"channels");
    checked(snd_pcm_hw_params_set_rate(pcm,hw,RATE,0),"rate");
    checked(snd_pcm_hw_params_set_period_size(pcm,hw,block,0),"period");
    checked(snd_pcm_hw_params_set_buffer_size(pcm,hw,block*periods),"buffer");
    checked(snd_pcm_hw_params(pcm,hw),"hw_params");
    snd_pcm_sw_params_t *sw;snd_pcm_sw_params_alloca(&sw);
    checked(snd_pcm_sw_params_current(pcm,sw),"sw_current");
    checked(snd_pcm_sw_params_set_avail_min(pcm,sw,block),"avail_min");
    checked(snd_pcm_sw_params_set_start_threshold(pcm,sw,block*prefill),"start_threshold");
    checked(snd_pcm_sw_params_set_stop_threshold(pcm,sw,block*periods),"stop_threshold");
    checked(snd_pcm_sw_params(pcm,sw),"sw_params");checked(snd_pcm_prepare(pcm),"prepare");
    snd_output_t *output;checked(snd_output_stdio_attach(&output,stdout,0),"output_attach");
    checked(snd_pcm_dump(pcm,output),"dump");
    if(wait_ms) { struct timespec pause={0,(long)wait_ms*1000000};while(nanosleep(&pause,&pause)<0&&errno==EINTR) {} }
    int16_t zero[256]={0};uint64_t start=now_ns();int failed=0;
    for(unsigned i=0;i<BLOCKS;i++) {
        uint64_t target=start+(uint64_t)i*block*1000000000ull/RATE;
        struct timespec wake={(time_t)(target/1000000000ull),(long)(target%1000000000ull)};
        int slept;do { slept=clock_nanosleep(CLOCK_MONOTONIC,TIMER_ABSTIME,&wake,NULL); } while(slept==EINTR);
        checked(-slept,"clock_nanosleep");
        uint64_t write_begin=now_ns();
        unsigned offset=0;int write_error=0;
        while(offset<block) {
            snd_pcm_sframes_t part=snd_pcm_writei(pcm,zero+2*offset,block-offset);
            if(part==-EAGAIN||part==-EINTR) {
                if(now_ns()-write_begin>1000000000ull) { write_error=-ETIMEDOUT;break; }
                int waited=snd_pcm_wait(pcm,50);
                if(waited<0&&waited!=-EINTR) { write_error=waited;break; }
                continue;
            }
            if(part<=0) { write_error=part<0?(int)part:-EIO;break; }
            offset+=(unsigned)part;
        }
        uint64_t write_end=now_ns();snd_pcm_sframes_t delay=0;
        int rc=snd_pcm_delay(pcm,&delay);uint64_t delay_end=now_ns();
        if(i<8||write_error||rc<0) printf("block=%u write_ns=%llu delay_ns=%llu wrote=%u write_error=%d delay_result=%d delay=%ld state=%s\n",i,(unsigned long long)(write_end-write_begin),(unsigned long long)(delay_end-write_end),offset,write_error,rc,(long)delay,snd_pcm_state_name(snd_pcm_state(pcm)));
        if(write_error||rc<0) {
            snd_pcm_status_t *status;snd_pcm_status_alloca(&status);
            checked(snd_pcm_status(pcm,status),"status");checked(snd_pcm_status_dump(status,output),"status_dump");
            failed=1;break;
        }
    }
    printf("failed=%d duration_ns=%llu\n",failed,(unsigned long long)(now_ns()-start));
    checked(snd_pcm_drop(pcm),"drop");checked(snd_pcm_close(pcm),"close");checked(snd_output_close(output),"output_close");
    return failed?1:0;
}
