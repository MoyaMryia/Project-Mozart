# 原生 ALSA／USB 测试泵

本目录保存本机 ALSA 接入试验。当前结果见[原生 WOLA 报告](../../../reports/native-wola-20261025/RESULTS.md)。
早期失败记录见[全双工报告](../../../reports/usb-full-duplex-20261025/RESULTS.md)。

## 构建

执行构建脚本：

```sh
./build.sh
```

构建使用系统 ALSA 头文件和解包的 libusb 头文件，并链接已安装的运行库。

## 测试路径

```text
原生源线程 → Loopback 子流 2 → 采集线程 → USB OUT
                                             ↓
                                      板端 echo／DSP
                                             ↓
原生回录线程 ← Loopback 子流 3 ← 播放线程 ← USB IN
```

主机采集线程负责发送。原串行分支在主线程接收和播放。
`--queued` 分支由主线程接收，再交给独立播放线程。
该分支在开始采集前完成静音启动，并按 `--target` 控制运行水位。
进入实时段后，空队列等待数据，ALSA 欠载保持失败。
fixture 输入为固定种子的宽带随机信号。
接收端将前 100 包计入启动预热，此后逐包播放。
ALSA 错误、USB 超时、错序或计数不符均使测试失败。

运行前停止本机 USB 桥，并启动板端 `endpoint_probe`。
为退出流程设置服务恢复处理。

```sh
./bridge --fixture --block 64 --periods 6 --prefill 3 \
  --mode echo --seconds 3 --output run
```

`--mode dsp` 使用板端现有高通和 WOLA。
`--native` 关闭源线程和回录线程，设备名由 `--capture` 和 `--playback` 指定。
当前硬件候选命令见[原生 WOLA 复现步骤](../../../reports/native-wola-20261025/RESULTS.md#工件与复现)。
运行后停止板端测试泵，并恢复本机 USB 桥。

## 工件

- `capture.raw`：采集输入，包含预热。
- `playback.raw`：预热后播放的全部负载。
- `source.raw`、`sink.raw`：测试源和 Loopback 回录。
- `blocks.csv`：逐包采集、USB 回传、播放提交时间和队列估算。
- `sink.csv`：回录块的样本位置、读取时间和剩余帧数。
- `status.txt`、`run.log`：计数、错误和协商后的周期／缓冲。

所有 raw 文件使用 48 kHz、双声道 S16_LE。
队列估算为 `(playwrite_end - capture_read_end) + (capture_delay + playback_delay) / 48000`。
两个 delay 字段的单位均为采样帧。

非阻塞 drain 只启动一次，随后等待 PCM 状态完成。
修复后的收尾检查保存在 `echo-draincheck/`。

## 适用范围

配置、样本数、失败项与物理验收范围见[实测报告](../../../reports/native-wola-20261025/RESULTS.md#适用范围)。
