#!/bin/sh
set -eu
cd "$(dirname "$0")"
c++ -std=c++17 -O2 -Wall -Wextra -Werror \
  -Ideps/extracted/usr/include \
  bridge.cpp -o bridge \
  -lasound -L/lib/x86_64-linux-gnu -Wl,-l:libusb-1.0.so.0 -pthread
