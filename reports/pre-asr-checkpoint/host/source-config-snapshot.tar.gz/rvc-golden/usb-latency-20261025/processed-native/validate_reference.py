#!/usr/bin/env python3
"""将原生 USB 输出与当前 C 参考逐样本比较。"""
import argparse
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
import host_probe


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("block", type=int, choices=(64, 128))
    args = parser.parse_args()
    raw = args.input.read_bytes()
    result = args.output.read_bytes()
    frame_bytes = args.block * 4
    if len(raw) == 0 or len(raw) % frame_bytes or len(result) != len(raw):
        raise ValueError("input/output files must contain equal whole stereo packets")
    packets = [raw[i:i + frame_bytes] for i in range(0, len(raw), frame_bytes)]
    expected = host_probe.reference_audio(packets, args.block)
    maximum = 0
    for index, offset in enumerate(range(0, len(result), frame_bytes)):
        packet = result[offset:offset + frame_bytes]
        target = expected[index * args.block:(index + 1) * args.block]
        maximum = max(maximum, host_probe.check_dsp(packet, target))
    print(f"packets={len(packets)} maxdiff_lsb={maximum}")


if __name__ == "__main__":
    main()
