#pragma once
#include "../duplex/host_usb.hpp"
namespace native_usb {
using duplex::Usb;
}
