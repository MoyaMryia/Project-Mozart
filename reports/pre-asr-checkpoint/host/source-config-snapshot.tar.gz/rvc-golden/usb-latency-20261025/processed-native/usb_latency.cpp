#include "usb_io.hpp"
#include <cmath>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <numeric>

using namespace duplex;
using native_usb::Usb;
namespace {
constexpr unsigned Warmup=100,Tail=16;
constexpr int64_t DigitalBudgetNs=10'000'000;
struct Rx { uint32_t seq; uint64_t stamp; int64_t arrived; std::vector<uint8_t> bytes; };
int16_t sample(uint64_t n) {
    constexpr double pi=3.14159265358979323846;
    double t=double(n)/Rate;
    uint32_t state=uint32_t(n)^0x91e10da5u;
    state^=state>>16;state*=0x7feb352du;state^=state>>15;state*=0x846ca68bu;state^=state>>16;
    double noise=double(state)/4294967295.0*2.0-1.0;
    double x=0.20*sin(2*pi*317*t)+0.16*sin(2*pi*997*t)+0.12*sin(2*pi*4211*t)+0.05*noise;
    return int16_t(std::lround(x*32767));
}
uint64_t integer(const char* s) {
    require(s&&*s,"empty integer argument"); uint64_t v=0;
    for(const char* p=s;*p;p++) { require(*p>='0'&&*p<='9',"arguments must be unsigned decimal integers");
        unsigned d=unsigned(*p-'0'); require(v<=(UINT64_MAX-d)/10,"integer argument overflow"); v=v*10+d; }
    return v;
}
void run(unsigned block,unsigned seconds,const std::string& dir) {
    std::filesystem::create_directories(dir);
    const unsigned measured=seconds*Rate/block,total=Warmup+measured+Tail;
    std::vector<std::vector<uint8_t>> packets(total);
    std::vector<int64_t> sent(total),late(total);
    for(unsigned seq=0;seq<total;seq++) {
        auto p=packet(0,0,seq,0,block*4);
        for(unsigned i=0;i<block;i++) { int16_t v=sample(uint64_t(seq)*block+i); for(int ch=0;ch<2;ch++) {
            size_t o=Header+4*i+2*ch; p[o]=uint8_t(v); p[o+1]=uint8_t(uint16_t(v)>>8);
        }} packets[seq]=std::move(p);
    }
    std::ofstream input(dir+"/input.raw",std::ios::binary);
    require(bool(input),"cannot create input.raw");
    for(const auto& p:packets) input.write(reinterpret_cast<const char*>(p.data()+Header),std::streamsize(block*4));
    input.close(); require(bool(input),"cannot write input.raw");
    Usb io; Stream stream;
    auto start=packet(1,1,0xffffffffu,0,8); put32(start.data()+Header,1); put32(start.data()+Header+4,block); io.write(start);
    require(stream.next([&]{return io.read();}).bytes==start,"start acknowledgement mismatch");
    std::vector<Rx> received; received.reserve(total); Failure failure;
    std::thread sender([&] { try {
        int64_t epoch=now()+20'000'000;
        for(unsigned i=0;i<total;i++) {
            int64_t target=epoch+int64_t(i)*block*1'000'000'000/Rate; sleep_to(target);failure.check();
            int64_t stamp=now(); sent[i]=stamp; late[i]=stamp-target;
            put32(packets[i].data()+12,uint32_t(uint64_t(stamp/1000)));
            put32(packets[i].data()+16,uint32_t(uint64_t(stamp/1000)>>32)); io.write(packets[i]);
        }
        auto end=packet(1,2,0xffffffffu,0,0); io.write(end);
    } catch(const std::exception&) { failure.record(); }});
    uint32_t ack[4]={}; bool got_end=false; std::string error;
    try {
        while(!got_end) {
            failure.check(); auto frame=stream.next([&]{return io.read();}); const auto& b=frame.bytes;
            if(b[3]==0) {
                require(b[5]==0&&b.size()==Header+block*4,"invalid response audio frame");
                require(received.size()<total&&get32(b.data()+8)==received.size(),"response sequence or coverage mismatch");
                received.push_back({get32(b.data()+8),get64(b.data()+12),frame.arrived,std::move(frame.bytes)});
            } else {
                require(b[3]==1&&b[5]==2&&get32(b.data()+8)==0xffffffffu&&get64(b.data()+12)==0&&b.size()==Header+16,"invalid end acknowledgement");
                for(unsigned i=0;i<4;i++) ack[i]=get32(b.data()+Header+4*i);
                got_end=true;
            }
        }
    } catch(const std::exception& e) { error=e.what(); failure.record(); }
    // join 返回后才读取发送时间数组。
    sender.join();
    if(error.empty()) { try { failure.check(); } catch(const std::exception& e) { error=e.what(); } }
    if(error.empty()) try {
        require(received.size()==total,"response packet coverage mismatch");
        for(unsigned i=0;i<total;i++) require(received[i].seq==i&&sent[i]>0&&received[i].stamp==uint64_t(sent[i]/1000)&&received[i].arrived>=sent[i],"response sequence or timestamp mismatch");
        require(ack[0]==total*block&&ack[1]==total*block&&ack[2]==block-64&&ack[3]==block,"END sample counts or padding mismatch");
    } catch(const std::exception& e) { error=e.what(); }
    std::ofstream output(dir+"/output.raw",std::ios::binary); require(bool(output),"cannot create output.raw");
    for(const auto& r:received) output.write(reinterpret_cast<const char*>(r.bytes.data()+Header),std::streamsize(block*4));
    output.close(); require(bool(output),"cannot write output.raw");
    std::ofstream csv(dir+"/packets.csv"); require(bool(csv),"cannot create packets.csv");
    csv<<"seq,phase,send_ns,receive_ns,rtt_ns,send_late_ns\n";
    std::vector<int64_t> rtts; unsigned over=0;
    for(size_t i=0;i<received.size();i++) { const auto& r=received[i]; auto phase=i<Warmup?"warmup":i<Warmup+measured?"measured":"tail";
        int64_t rtt=r.arrived-sent[i]; csv<<i<<','<<phase<<','<<sent[i]<<','<<r.arrived<<','<<rtt<<','<<late[i]<<'\n';
        if(i>=Warmup&&i<Warmup+measured) { rtts.push_back(rtt); if(rtt>DigitalBudgetNs) over++; }
    }
    auto sorted=rtts; std::sort(sorted.begin(),sorted.end());
    auto percentile=[&](double q){ return sorted.empty()?int64_t(0):sorted[size_t(std::ceil(q*sorted.size()))-1]; };
    csv.close();require(bool(csv),"cannot write packets.csv");
    if(error.empty()&&over) error="steady-state digital segment RTT exceeded 10 ms budget";
    std::ofstream status(dir+"/status.txt");
    status<<"success="<<(error.empty()?"true":"false")<<"\nerror="<<error<<"\nmode=1\nblock="<<block<<"\nseconds="<<seconds
      <<"\npackets_expected="<<total<<"\npackets_received="<<received.size()<<"\nmeasured_packets="<<rtts.size()
      <<"\ninput_samples="<<ack[0]<<"\noutput_samples="<<ack[1]<<"\nresidual_padding="<<ack[2]<<"\npadding="<<ack[3]
      <<"\nstartup_rtt_ns="<<((!received.empty()&&sent[0])?received[0].arrived-sent[0]:0)
      <<"\nsteady_p50_ns="<<percentile(.50)<<"\nsteady_p95_ns="<<percentile(.95)<<"\nsteady_p99_ns="<<percentile(.99)
      <<"\nsteady_max_ns="<<(sorted.empty()?0:sorted.back())<<"\nsteady_over_10ms="<<over<<"\nbudget=10ms digital segment RTT\n";
    require(bool(status),"cannot write status.txt");
    std::cout<<"success="<<(error.empty()?"true":"false")<<" received="<<received.size()<<" error="<<error<<'\n';
    require(error.empty(),error);
}
}
int main(int argc,char** argv) {
    try { require(argc==4,"usage: usb-latency BLOCK SECONDS OUTPUT_DIR");
        uint64_t b=integer(argv[1]),s=integer(argv[2]); require(allowed_block(b)&&s>=1&&s<=MaxSeconds,"invalid block or seconds");
        run(unsigned(b),unsigned(s),argv[3]); return 0;
    } catch(const std::exception& e) { std::cerr<<"FAIL: "<<e.what()<<'\n'; return 1; }
}
