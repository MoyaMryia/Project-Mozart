#!/bin/sh
set -eu
cd "$(dirname "$0")"
DEPS=../native-host/deps/extracted/usr
c++ -std=c++17 -O2 -Wall -Wextra -Werror \
  -I"$DEPS/include" usb_latency.cpp -o usb-latency \
  -L/lib/x86_64-linux-gnu -Wl,-l:libusb-1.0.so.0 -pthread
