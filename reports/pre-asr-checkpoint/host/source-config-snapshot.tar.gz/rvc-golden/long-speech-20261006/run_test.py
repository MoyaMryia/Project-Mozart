"""Own one bounded, paced Jetson soak; archive results before history eviction."""
import collections
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import statistics
import subprocess
import sys
import time
import urllib.request
import wave

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
TERMINAL = {'completed', 'failed', 'cancelled', 'expired'}


def save(path, value):
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2))
    temporary.replace(path)


def stats(values):
    if not values:
        return None
    ordered = sorted(values)
    return {'min': min(values), 'median': statistics.median(values),
            'p95': ordered[min(len(ordered)-1, int(.95*len(ordered)))], 'max': max(values)}


def main():
    for filename in ['progress.json', 'exit-status.json', 'summary.json']:
        if (HERE/filename).exists():
            raise RuntimeError('This run directory already has results; never overwrite a run')
    (HERE/'archive').mkdir(exist_ok=True)
    command = [sys.executable, str(ROOT/'tools/run_translated_speech.py'),
        '--backend-config', str(ROOT/'state/translated-speech.yaml'),
        '--reference', str(ROOT/'rvc-golden/clone-tts/qiqi-20261004/reference-qiqi-natural-source.wav'),
        '--reference-name', 'zh-qiqi longer test', '--input', '/tmp/test-audio.mp4',
        '--start', '720', '--seconds', '1800', '--playback-device', 'null',
        '--final-model', '/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17',
        '--run-dir', str(HERE/'runtime'), '--data-dir', str(HERE/'speech')]
    start = time.time()
    save(HERE/'protocol.json', {'command': command, 'started_at': start,
        'source_start_seconds': 720, 'source_seconds': 1800,
        'input_sha256': hashlib.sha256(Path('/tmp/test-audio.mp4').read_bytes()).hexdigest(),
        'reference_sha256': hashlib.sha256(Path(command[command.index('--reference')+1]).read_bytes()).hexdigest(),
        'output': 'ALSA null paced to each generated WAV duration; no physical-speaker soak',
        'rvc_enabled': False, 'queue_limit': 4, 'playback_wait_limit_seconds': 12,
        'live_deadline_seconds': 30, 'watchdog_seconds': 2160})
    jobs = {}
    hashes = {}
    samples = []
    stopped = False
    def signal_stop(*_):
        nonlocal stopped
        stopped = True
    signal.signal(signal.SIGTERM, signal_stop)
    signal.signal(signal.SIGINT, signal_stop)
    log = (HERE/'launcher.log').open('w')
    process = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    save(HERE/'pids.json', {'harness': os.getpid(), 'supervisor': process.pid})
    failure = None
    def capture(current):
        for job in current:
            jobs[job['id']] = dict(job)
            if job['status'] == 'completed' and job['id'] not in hashes:
                source = HERE/'speech/results'/(job['id']+'.wav')
                if source.exists():
                    target = HERE/'archive'/source.name
                    shutil.copyfile(source, target)
                    hashes[job['id']] = hashlib.sha256(target.read_bytes()).hexdigest()
                    save(target.with_suffix('.json'), job)
    try:
        with (HERE/'telemetry.jsonl').open('w') as telemetry:
            while process.poll() is None:
                now = time.time()
                if stopped or now-start > 2160:
                    failure = 'Stopped by signal' if stopped else 'Harness watchdog exceeded 2160 seconds'
                    break
                mem = {line.split(':')[0]: int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines()}
                record = {'at': now, 'available_bytes': mem['MemAvailable'],
                          'swap_used_bytes': mem['SwapTotal']-mem['SwapFree']}
                try:
                    with urllib.request.urlopen('http://127.0.0.1:18080/api/speech/status', timeout=2) as response:
                        state = json.load(response)
                    capture(state['jobs'])
                    record.update(unfinished=sum(job['status'] not in TERMINAL for job in state['jobs']),
                                  playback_wait_seconds=sum(job.get('duration_seconds',0) for job in state['jobs'] if job['status']=='ready'),
                                  job_states=dict(collections.Counter(job['status'] for job in state['jobs'])))
                except OSError as error:
                    record['api_error'] = str(error)
                telemetry.write(json.dumps(record)+'\n');telemetry.flush()
                samples.append(record)
                if len(samples)%5 == 1:
                    save(HERE/'jobs.json', sorted(jobs.values(), key=lambda job: job['created_at']))
                    save(HERE/'progress.json', {'status':'running', 'elapsed_seconds': now-start,
                        'observed_job_states':dict(collections.Counter(job['status'] for job in jobs.values())),
                        'archived_completed_wavs':len(hashes), 'available_GiB':mem['MemAvailable']/1024**3,
                        'latest_sample':record})
                time.sleep(2)
    except Exception as error:
        failure = str(error)
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=90)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL);process.wait()
        log.close()
        # Terminal records can finish between the last poll and service shutdown.
        for path in (HERE/'speech/results').glob('*.json'):
            capture([json.loads(path.read_text())])
        completed = sorted([job for job in jobs.values() if job['status']=='completed'], key=lambda job:job['created_at'])
        missing = [job['id'] for job in completed if job['id'] not in hashes]
        if missing:
            failure = 'Completed audio missing from archive: '+', '.join(missing)
        combined = HERE/'qiqi-translated-30min-combined.wav'
        segments = []
        offset = 0
        if completed and not missing:
            with wave.open(str(combined),'wb') as writer:
                settings = None
                for job in completed:
                    path = HERE/'archive'/(job['id']+'.wav')
                    with wave.open(str(path),'rb') as source:
                        actual = (source.getnchannels(),source.getsampwidth(),source.getframerate())
                        if settings is None:
                            settings = actual
                            writer.setnchannels(actual[0]);writer.setsampwidth(actual[1]);writer.setframerate(actual[2])
                        if actual != settings:
                            raise RuntimeError('Cannot combine mismatched WAV formats')
                        duration = source.getnframes()/source.getframerate()
                        writer.writeframes(source.readframes(source.getnframes()))
                    segments.append({'job_id':job['id'], 'start_seconds':offset,
                        'duration_seconds':duration, 'text':job['text'], 'source_text':job.get('source_text','')})
                    offset += duration
        captions_path = HERE/'runtime/subtitles.jsonl'
        captions = [json.loads(line) for line in captions_path.read_text().splitlines() if line] if captions_path.exists() else []
        summary = {'status':'finished' if process.returncode==0 and not failure else 'failed',
            'exit_code':process.returncode, 'failure':failure, 'elapsed_seconds':time.time()-start,
            'source_start_seconds':720, 'source_seconds':1800, 'caption_count':len(captions),
            'job_states':dict(collections.Counter(job['status'] for job in jobs.values())),
            'speech_admission_errors':dict(collections.Counter(c['speech_error'] for c in captions if c.get('speech_error'))),
            'translation_errors':[c for c in captions if c.get('translation_error')],
            'failed_jobs':[job for job in jobs.values() if job['status']=='failed'],
            'archived_completed_wavs':len(hashes), 'missing_completed_wavs':missing,
            'combined_seconds':offset, 'combined_sha256':hashlib.sha256(combined.read_bytes()).hexdigest() if combined.exists() else None,
            'minimum_available_GiB':min(r['available_bytes'] for r in samples)/1024**3 if samples else None,
            'swap_used_bytes':stats([r['swap_used_bytes'] for r in samples]),
            'max_unfinished':max((r.get('unfinished',0) for r in samples), default=0),
            'max_waiting_playback_seconds':max((r.get('playback_wait_seconds',0) for r in samples), default=0),
            'synthesis_RTF':stats([j['synthesis_seconds']/j['duration_seconds'] for j in completed]),
            'enqueue_to_audio_ready_seconds':stats([j['audio_ready_at']-j['created_at'] for j in completed]),
            'ready_to_playback_seconds':stats([j['playback_started_at']-j['audio_ready_at'] for j in completed]),
            'translation_ms':stats([c['translate_ms'] for c in captions if 'translate_ms' in c]),
            'original_silence_and_playback_timing_preserved_in_combined':False}
        save(HERE/'combined-segments.json', segments)
        save(HERE/'jobs.json', sorted(jobs.values(),key=lambda job:job['created_at']))
        save(HERE/'archive-sha256.json', hashes)
        save(HERE/'summary.json', summary)
        save(HERE/'exit-status.json', {'code':process.returncode,'failure':failure})
        save(HERE/'progress.json',summary)
        print(json.dumps(summary,ensure_ascii=False),flush=True)


if __name__ == '__main__':
    main()
