"""Verify transfer and all archived completed WAVs before reporting results."""
import hashlib
import json
from pathlib import Path
import tarfile
import wave

HERE = Path(__file__).resolve().parent
bundle = Path('/tmp/mozart-long-speech-20261006.tar.gz')
expected = '9ae7c361093e752023891cbd6dfdb16473e8f03bfd95410c7c6003b060764675'
actual = hashlib.sha256(bundle.read_bytes()).hexdigest()
assert actual == expected, 'Archive transfer SHA-256 mismatch or incomplete transfer'
with tarfile.open(bundle) as archive:
    for member in archive.getmembers():
        path = Path(member.name)
        assert not path.is_absolute() and '..' not in path.parts
        assert path.parts[0] == HERE.name
    archive.extractall(HERE.parent, filter='data')
hashes = json.loads((HERE/'archive-sha256.json').read_text())
for job, digest in hashes.items():
    assert hashlib.sha256((HERE/'archive'/(job+'.wav')).read_bytes()).hexdigest() == digest, job
summary = json.loads((HERE/'summary.json').read_text())
combined = HERE/'qiqi-translated-30min-combined.wav'
assert hashlib.sha256(combined.read_bytes()).hexdigest() == summary['combined_sha256']
with wave.open(str(combined)) as source:
    seconds = source.getnframes()/source.getframerate()
    assert abs(seconds-summary['combined_seconds']) < .001
    assert source.getnchannels() == 1 and source.getframerate() == 24000
assert len(hashes) == summary['archived_completed_wavs'] == 244
receipt = {'download_archive_sha256':actual, 'completed_WAVs_verified':len(hashes),
           'combined_WAV_sha256':summary['combined_sha256'], 'combined_seconds':seconds,
           'all_checks_passed':True}
(HERE/'collection-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
