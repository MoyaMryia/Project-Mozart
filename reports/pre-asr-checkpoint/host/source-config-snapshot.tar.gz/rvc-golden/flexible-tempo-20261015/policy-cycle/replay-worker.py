import json,sys,shutil,wave
print(json.dumps({'ready':True}),flush=True)
for line in sys.stdin:
 job=json.loads(line);shutil.copyfile(sys.argv[1],job['output'])
 with wave.open(job['output'],'rb') as w:
  duration=w.getnframes()/w.getframerate();rate=w.getframerate()
 print(json.dumps({'duration_seconds':duration,'sample_rate':rate}),flush=True)
