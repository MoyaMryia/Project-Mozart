"""One bounded offline context experiment; never alters production endpoints."""
import array, fcntl, hashlib, json, os, resource, sys, time, wave
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from asr_checks import refine_with_numeric_check
import sherpa_onnx

source = ROOT / 'rvc-golden/reliability-20261006/short-v5'
here = BASE / sys.argv[1]
here.mkdir(exist_ok=False)
lock = (ROOT / 'rvc-golden/reliability-20261006/active-test.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert json.loads((source / 'postprocess-exit-status.json').read_text())['all_quality_inference_finished']
captions = [json.loads(l) for l in (source / 'runtime/subtitles.jsonl').read_text().splitlines()]
pcm = array.array('h')
offsets = [0]
for c in captions:
    path = source / 'runtime/utterances' / Path(c['source_audio']).name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == c['source_audio_sha256']
    with wave.open(str(path)) as w:
        assert (w.getnchannels(), w.getsampwidth(), w.getframerate()) == (1, 2, 16000)
        values = array.array('h', w.readframes(w.getnframes()))
    if sys.byteorder != 'little': values.byteswap()
    pcm.extend(values)
    offsets.append(len(pcm))
assert len(pcm) == 120 * 16000
model = Path('/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17')
(here / 'pid.json').write_text(json.dumps({'pid': os.getpid()}) + '\n')
started = time.monotonic()
recognizer = sherpa_onnx.OfflineRecognizer.from_sense_voice(
    model=str(model / 'model.int8.onnx'), tokens=str(model / 'tokens.txt'),
    num_threads=2, language='zh', use_itn=True)
rows = []
try:
    # Whole adjacent windows are diagnostic upper bounds, not a live policy.
    for first, last in [(1, 2), (7, 8), (12, 13), (16, 17), (19, 20), (23, 24)]:
        begin, end = offsets[first-1], offsets[last]
        assert (end-begin) <= 20 * 16000
        values = pcm[begin:end]
        path = here / f'{first:02d}-{last:02d}-joint.wav'
        output = array.array('h', values)
        if sys.byteorder != 'little': output.byteswap()
        with wave.open(str(path), 'wb') as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000)
            w.writeframes(output.tobytes())
        tick = time.monotonic()
        text, audit = refine_with_numeric_check(recognizer, [v/32768 for v in values],
                            ''.join(c['online_text'] for c in captions[first-1:last]))
        row = {'source_seqs': list(range(first, last+1)), 'source_texts': [c['zh'] for c in captions[first-1:last]],
               'joint_text': text, 'numeric_audit': audit, 'seconds': len(values)/16000,
               'added_wait_for_next_endpoint_seconds': captions[last-1]['source_audio_seconds'],
               'decode_seconds': time.monotonic()-tick, 'wav': path.name,
               'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
               'human_source_transcript_verified': False}
        rows.append(row)
        (here / 'results.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2)+'\n')
        print(json.dumps(row, ensure_ascii=False), flush=True)
    (here / 'summary.json').write_text(json.dumps({'elapsed_seconds':time.monotonic()-started,
        'max_RSS_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        'source_PCM_sha256':hashlib.sha256(pcm.tobytes()).hexdigest(), 'source_seconds':120,
        'production_changed':False, 'max_diagnostic_window_seconds':20,
        'human_source_transcript_verified':False, 'cases':len(rows)},indent=2)+'\n')
finally:
    (here / 'exit-status.json').write_text(json.dumps({'complete':(here/'summary.json').exists(), 'process_finished':True})+'\n')
