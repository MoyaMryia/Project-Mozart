"""Score a reviewed source reference; refuse automatic draft references."""
import argparse, hashlib, json, re, sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from translation_checks import required_number_counts

def edits(reference, hypothesis):
    previous=list(range(len(hypothesis)+1))
    for i,a in enumerate(reference,1):
        current=[i]
        for j,b in enumerate(hypothesis,1):
            current.append(min(previous[j]+1,current[j-1]+1,previous[j-1]+(a!=b)))
        previous=current
    return previous[-1]

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('reference',type=Path)
    ap.add_argument('captions',type=Path,help='Retained subtitle JSONL to evaluate')
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    reference=json.loads(args.reference.read_text())
    source=json.loads((BASE/'source-reference-draft.json').read_text())
    if not reference.get('human_source_transcript_verified') or not reference.get('reviewer','').strip():
        raise SystemExit('Reference is not reviewed. Use source-review.html; automatic captions are not ground truth.')
    assert reference['source_wav_sha256']==source['source_wav_sha256']
    assert hashlib.sha256((BASE/'processed-source-120s.wav').read_bytes()).hexdigest()==source['source_wav_sha256']
    expected={r['seq']:r for r in source['captions']}
    assert len(reference['captions'])==len(expected)
    assert {r['seq'] for r in reference['captions']}==set(expected)
    captions={c['seq']:c for c in [json.loads(l) for l in args.captions.read_text().splitlines() if l]}
    assert set(captions)==set(expected),'Different segmentation requires a separately aligned reference.'
    rows=[]
    for r in reference['captions']:
        seq=r['seq'];c=captions[seq]
        assert r['reviewed'] and r['audio_sha256']==expected[seq]['audio_sha256']==c['source_audio_sha256']
        assert (r['begin_seconds'],r['end_seconds'])==(expected[seq]['begin_seconds'],expected[seq]['end_seconds'])
        row={'seq':seq,'unclear':bool(r['unclear_spans'].strip()),'reviewed_chinese':r['reviewed_chinese'],
             'automatic_chinese':c['zh'],'generated_english':c['en'],'faithful_english_reference':r['reviewed_english']}
        if not row['unclear']:
            assert r['reviewed_chinese'].strip() and r['reviewed_english'].strip(),seq
            chars=lambda t:re.findall(r'[\u3400-\u9fffA-Za-z0-9]',t)
            truth,actual=chars(r['reviewed_chinese']),chars(c['zh'])
            row.update(character_edits=edits(truth,actual),reference_characters=len(truth),
                       reviewed_quantities=required_number_counts(r['reviewed_chinese']),
                       recognized_quantities=required_number_counts(c['zh']))
            row['quantity_inventory_matches']=row['reviewed_quantities']==row['recognized_quantities']
        rows.append(row)
    scored=[r for r in rows if not r['unclear']]
    report={'reviewer_assertion':reference['reviewer'],'independently_certified':False,
            'source_rows':len(rows),'unclear_rows':len(rows)-len(scored),
            'CER':sum(r['character_edits'] for r in scored)/max(1,sum(r['reference_characters'] for r in scored)),
            'quantity_mismatch_rows':[r['seq'] for r in scored if not r['quantity_inventory_matches']],
            'translation_semantics_automatically_verified':False,'rows':rows}
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='rows'}))

if __name__=='__main__':main()
