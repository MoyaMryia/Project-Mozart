"""Launch one detached replay with the project's virtual-environment interpreter."""
import fcntl
import json
from pathlib import Path
import subprocess
import sys
import time

BASE=Path(__file__).absolute().parent
ROOT=BASE.parents[1]
if len(sys.argv)!=3 or '/' in sys.argv[1] or int(sys.argv[2]) not in (120,1800):
    raise SystemExit('Usage: launch_attempt.py UNIQUE_ATTEMPT 120|1800')
name=sys.argv[1];seconds=int(sys.argv[2])
# Do not resolve this symlink: resolving .venv/bin/python loses its venv prefix.
python=ROOT/'.venv/bin/python'
subprocess.run([str(python),'-c','import numpy, soundfile, sherpa_onnx'],check=True)
with (ROOT/'rvc-golden/reliability-20261006/active-test.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    state=json.loads((BASE/'campaign-state.json').read_text())
    active=state.get('active_attempt')
    if active and not (BASE/active/'exit-status.json').exists():
        raise RuntimeError('An existing attempt has not exited: '+active)
    here=BASE/name;here.mkdir(exist_ok=False)
    # run_test obtains this same lock; close it before dispatching the child.
with (here/'harness.log').open('w') as log:
    process=subprocess.Popen([str(python),str(BASE/'run_test.py'),name,str(seconds)],
        cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
state.update(phase='running-short' if seconds==120 else 'running-long',active_attempt=name,
             active_control=None,harness_pid=process.pid,updated_at=time.time())
state.setdefault('attempts',[]).append({'name':name,'seconds':seconds,'status':'running','harness_pid':process.pid})
temporary=BASE/'campaign-state.json.tmp';temporary.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n');temporary.replace(BASE/'campaign-state.json')
print(json.dumps({'attempt':name,'seconds':seconds,'harness_pid':process.pid,'python':str(python)}))
