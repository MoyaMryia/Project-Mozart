"""Sequential source-semantic controls on the existing pinned 4B candidate."""
import fcntl, hashlib, json, os, socket, subprocess, sys, threading, time, urllib.request
from pathlib import Path
BASE=Path(__file__).resolve().parent; ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from subtitle_bridge import translate
from run_translated_speech import assert_ports_available

here=BASE/sys.argv[1];here.mkdir(exist_ok=False)
lock=(ROOT/'rvc-golden/reliability-20261006/active-test.lock').open('a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert_ports_available([(18220,socket.SOCK_STREAM)])
fixtures=json.loads((BASE/'semantic-fixtures.json').read_text())
captions=[json.loads(l) for l in (ROOT/'rvc-golden/reliability-20261006/short-v5/runtime/subtitles.jsonl').read_text().splitlines()]
fixtures += [{'id':f'retained-{seq}','zh':captions[seq-1]['zh'],'reference':None} for seq in [19,23]]
model=Path('/home/moyamryia/models/mozart-translation/Qwen3.5-4B-Q4_K_M.gguf')
h=hashlib.sha256()
with model.open('rb') as f:
    for data in iter(lambda:f.read(1048576),b''):h.update(data)
assert h.hexdigest()=='00fe7986ff5f6b463e62455821146049db6f9313603938a70800d1fb69ef11a4'
binary=Path.home()/'mozart-archive/qwen35/llama.cpp/build-cuda-bin/llama-server'
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(binary.parent)+':'+env.get('LD_LIBRARY_PATH','')
command=[str(binary),'-m',str(model),'-c','2048','-ngl','99','-np','1','-t','2','-tb','2','-b','256','-ub','128','--cache-ram','128','--host','127.0.0.1','--port','18220','--jinja']
readings=[];stop=threading.Event()
with (here/'server.log').open('w') as log:
    p=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env)
    (here/'pids.json').write_text(json.dumps({'control':os.getpid(),'server':p.pid})+'\n')
    def monitor():
        while not stop.is_set():
            try:
                memory={l.split(':')[0]:int(l.split()[1])*1024 for l in Path('/proc/meminfo').read_text().splitlines()}
                status={l.split(':')[0]:l.split(':')[1].strip() for l in Path('/proc',str(p.pid),'status').read_text().splitlines() if ':' in l}
                readings.append({'at':time.time(),'available_bytes':memory['MemAvailable'],'RSS_bytes':int(status['VmRSS'].split()[0])*1024})
                if memory['MemAvailable']<768*1024**2:p.terminate()
            except (OSError,KeyError):pass
            stop.wait(.2)
    watcher=threading.Thread(target=monitor,daemon=True);watcher.start()
    try:
        until=time.monotonic()+90
        while time.monotonic()<until:
            if p.poll() is not None:raise RuntimeError('Translator exited before readiness')
            try:
                with urllib.request.urlopen('http://127.0.0.1:18220/health',timeout=1) as r:
                    if r.status==200:break
            except OSError:time.sleep(.2)
        else:raise RuntimeError('Translator readiness timeout')
        (here/'protocol.json').write_text(json.dumps({'command':command,'model_sha256':h.hexdigest(),
            'source_hashes':{name:hashlib.sha256((ROOT/'tools'/name).read_bytes()).hexdigest() for name in ['subtitle_bridge.py','translation_checks.py']},
            'authored_fixture_reference_not_human_audio_transcript':True},indent=2)+'\n')
        rows=[]
        for fixture in fixtures:
            row=dict(fixture,audit=[])
            try:row['translation'],row['seconds']=translate('http://127.0.0.1:18220',fixture['zh'],audit=row['audit']);row['error']=None
            except Exception as e:row['error']=str(e)
            rows.append(row);(here/'results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
            print(json.dumps(row,ensure_ascii=False),flush=True)
    finally:
        p.terminate()
        try:p.wait(timeout=15)
        except subprocess.TimeoutExpired:p.kill();p.wait()
        stop.set();watcher.join(timeout=1)
        (here/'memory-samples.json').write_text(json.dumps(readings)+'\n')
        (here/'exit-status.json').write_text(json.dumps({'server_stopped':p.poll() is not None,'returncode':p.returncode})+'\n')
