"""Verify shutdown, then run sequential quality once for a finished attempt."""
import fcntl, hashlib, json, shutil, subprocess, sys, time
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
here=BASE/sys.argv[1]
assert json.loads((here/'exit-status.json').read_text())['code']==0
assert not (here/'postprocess-exit-status.json').exists(),'Do not repeat completed scoring'
assert not (here/'postprocess-running.json').exists(),'Do not duplicate already dispatched scoring'
pids=set(json.loads((here/'pids.json').read_text()).values())
for l in (here/'telemetry.jsonl').read_text().splitlines():pids.update(int(pid) for pid in json.loads(l).get('processes',{}))
assert not [pid for pid in pids if Path('/proc',str(pid)).exists()], 'Owned workload process still exists'
with (ROOT/'rvc-golden/reliability-20261006/active-test.lock').open('a') as f:
    fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
    fcntl.flock(f,fcntl.LOCK_UN)
(here/'postprocess-running.json').write_text(json.dumps({'began_at':time.time()})+'\n')
(here/'shutdown-receipt.json').write_text(json.dumps({'recorded_pids_checked':sorted(pids),'all_recorded_pids_gone':True,'workload_lock_free_before_quality':True},indent=2)+'\n')
for helper in ['verify_attempt.py','analyze_attempt.py']:
    with (here/(helper+'.log')).open('w') as log:
        subprocess.run([sys.executable,str(BASE/helper),sys.argv[1]],stdout=log,stderr=subprocess.STDOUT,check=True)
shutil.copyfile(BASE/'score_outputs.py',here/'score_outputs.py')
python='/home/moyamryia/vc_backend_venv/bin/python'
for script,argv,label in [(here/'score_outputs.py',[],'ordinary'),(BASE/'score_targeted_outputs.py',[sys.argv[1]],'targeted')]:
    with (here/(label+'-quality.log')).open('w') as log:
        subprocess.run([python,str(script),*argv],stdout=log,stderr=subprocess.STDOUT,check=True)
old=ROOT/'rvc-golden/reliability-20261006/short-v5'
read_caps=lambda p:[json.loads(l) for l in (p/'runtime/subtitles.jsonl').read_text().splitlines()]
before,after=read_caps(old),read_caps(here)
assert len(before)==len(after) and all(a['source_audio_sha256']==b['source_audio_sha256'] and a['zh']==b['zh'] for a,b in zip(before,after))
source_scores=old/'source-recognition-controls.json'
(here/'source-quality-reuse.json').write_text(json.dumps({'origin':str(source_scores.relative_to(ROOT)),
    'sha256':hashlib.sha256(source_scores.read_bytes()).hexdigest(),'identical_source_WAVs_and_Chinese_captions':len(after),
    'new_source_inference_performed':False,'human_source_transcript_verified':False},indent=2)+'\n')
(here/'postprocess-exit-status.json').write_text(json.dumps({'complete':True,'all_quality_inference_finished':True})+'\n')
print('Postprocessing complete; source scoring reused only after exact input hash/text comparison.',flush=True)
