"""Package finished evidence once, including protocol-matched source snapshots."""
from pathlib import Path
import hashlib,json,shutil,sys,tarfile
root=Path(__file__).resolve().parents[2];base=root/'rvc-golden/sentence-context-20261007';label=sys.argv[1]
assert '/' not in label
if label=='asr-controls':
 names=['asr-boundary-v1','asr-endpoint-v2','asr-itn-v1','asr-numeric-v1']
 for n in names:assert json.loads((base/n/'exit-status.json').read_text()).get('complete'),n
 paths=[base/n for n in names]+[p for n in names for p in base.glob(n+'*.log')]
else:
 a=base/label;assert json.loads((a/'summary.json').read_text())['exit_code']==0
 assert (a/'postprocess-exit-status.json').exists(),'Complete sequential quality before packaging'
 for relative,expected in json.loads((a/'protocol.json').read_text())['source_sha256'].items():
  source=root/relative
  target=a/'source-final'/relative;target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():assert hashlib.sha256(target.read_bytes()).hexdigest()==expected,relative
  else:
   assert hashlib.sha256(source.read_bytes()).hexdigest()==expected,relative
   shutil.copyfile(source,target)
 paths=[a]
archive=Path('/tmp')/('mozart-sentence-context-'+label+'.tar.gz');receipt=base/('package-'+label+'.json')
def file_hash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
if archive.exists():
 saved=json.loads(receipt.read_text());assert archive.stat().st_size==saved['bytes'] and file_hash(archive)==saved['sha256'];print(json.dumps(saved));sys.exit()
manifest={str(p.relative_to(base)):file_hash(p) for path in paths for p in (sorted(path.rglob('*')) if path.is_dir() else [path]) if p.is_file()}
manifest_path=base/('evidence-manifest-'+label+'.json');manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'w:gz') as tar:
 for path in paths+[manifest_path]:tar.add(path,arcname=str(path.relative_to(base)))
saved={'label':label,'archive':archive.name,'bytes':archive.stat().st_size,'sha256':file_hash(archive),'manifest_regular_files':len(manifest),'source_final_protocol_hashes_verified':label!='asr-controls'}
Path(str(archive)+'.sha256').write_text(saved['sha256']+'  '+archive.name+'\n');receipt.write_text(json.dumps(saved,indent=2)+'\n');print(json.dumps(saved))
