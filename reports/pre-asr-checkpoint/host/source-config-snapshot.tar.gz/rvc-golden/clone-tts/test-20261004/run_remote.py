#!/usr/bin/env python3
import hashlib, json, subprocess, sys, tarfile, time
from pathlib import Path, PurePosixPath
root=Path(__file__).resolve().parent
assets=Path('/home/moyamryia/models/sherpa-onnx/clone-test-downloads')
engine=sys.argv[1]
if engine=='zipvoice':
 archive=assets/'mozart-zipvoice.tar.bz2'; size=109162785
 digest='77219c8b40f4ee8d73a7f902305ff6c1128ef9b54461c41b4ca6ed890b6c2803'
 model='sherpa-onnx-zipvoice-distill-int8-zh-en-emilia'
else:
 archive=assets/'pocket.tar.bz2'; size=98336520
 digest='2f3b88823cbbb9bf0b2477ec8ae7b3fec417b3a87b6bb5f256dba66f2ad967cb'
 model='sherpa-onnx-pocket-tts-int8-2026-01-26'
print('Waiting for verified assets for '+engine,flush=True)
for i in range(300):
 if archive.exists() and archive.stat().st_size==size and (engine!='zipvoice' or (assets/'vocos_24khz.onnx').exists()): break
 time.sleep(2)
else: raise RuntimeError('asset transfer did not finish within 10 minutes')
assert hashlib.sha256(archive.read_bytes()).hexdigest()==digest
if not (assets/model).exists():
 with tarfile.open(archive) as t:
  for m in t.getmembers():
   p=PurePosixPath(m.name)
   assert p.parts[0]==model and not p.is_absolute() and '..' not in p.parts and not m.issym() and not m.islnk()
  t.extractall(assets)
if engine=='zipvoice':
 z=assets/model/'test_wavs'
 for source,target in [('leijun-1.wav','reference-zh-male.wav'),('news-female-2.wav','reference-zh-female.wav')]:
  (root/target).write_bytes((z/source).read_bytes())
 subprocess.run(['espeak-ng','-v','en-us','-s','150','-w',str(root/'reference-en-espeak.wav'),'This is a clean reference recording for the Mozart voice cloning experiment.'],check=True)
 meta={'archive_sha256':digest,'engine':engine,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
 for label,cmd in [('uname',['uname','-a']),('memory',['free','-m']),('commit',['git','-C','/home/moyamryia/Mozart','rev-parse','HEAD']),('nvpmodel',['nvpmodel','-q'])]:
  r=subprocess.run(cmd,capture_output=True,text=True);meta[label]=r.stdout+r.stderr
 (root/'hardware.json').write_text(json.dumps(meta,indent=2))
print('Starting '+engine,flush=True)
cmd=['/home/moyamryia/Mozart/.venv/bin/python',str(root/'benchmark.py'),'--engine',engine,'--assets',str(assets),'--fixtures',str(root/'fixtures.json'),'--output',str(root/engine),'--threads','2']
with (root/(engine+'-run.log')).open('w') as f:
 process=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 for line in process.stdout:
  print(line,end='',flush=True);f.write(line);f.flush()
 rc=process.wait()
print(engine+' exit='+str(rc),flush=True)
sys.exit(rc)
