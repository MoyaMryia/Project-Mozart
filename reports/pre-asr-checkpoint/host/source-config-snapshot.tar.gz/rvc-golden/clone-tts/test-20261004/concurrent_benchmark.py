#!/usr/bin/env python3
"""Bounded ASR + Qwen translation + Pocket benchmark; cleans up its own server."""
import ctypes, hashlib, json, os, signal, socket, subprocess, sys, threading, time, urllib.request
from pathlib import Path
import numpy as np
import soundfile as sf
import sherpa_onnx
import benchmark
root=Path(__file__).resolve().parent
assets=Path('/home/moyamryia/models/sherpa-onnx/clone-test-downloads')
out=root/'concurrent-pocket';out.mkdir(exist_ok=True)
stop=threading.Event();samples=[];asr_runs=[];llm_runs=[];errors=[];workers=[];server=None
report={'baseline':benchmark.memory(),'rvc_active':False,'playback_active':False,'live_microphone':False}
def translation(text):
 body={'chat_template_kwargs':{'enable_thinking':False},'messages':[{'role':'system','content':'Translate the Chinese input into English. Output only the English translation. /no_think'},{'role':'user','content':text}],'max_tokens':128,'temperature':0}
 req=urllib.request.Request('http://127.0.0.1:18204/v1/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
 start=time.monotonic()
 with urllib.request.urlopen(req,timeout=30) as r:d=json.loads(r.read())
 translated=d['choices'][0]['message']['content'].strip()
 if not translated:raise RuntimeError('empty translation')
 return {'source':text,'translation':translated,'elapsed_seconds':time.monotonic()-start}
def monitor():
 while not stop.is_set():
  m=benchmark.memory()
  if server is not None:
   try:
    status=Path('/proc/'+str(server.pid)+'/status').read_text().splitlines()
    m['llm_rss_bytes']=int(next(x for x in status if x.startswith('VmRSS:')).split()[1])*1024
   except (FileNotFoundError,StopIteration):pass
  samples.append(m)
  if m['available_bytes']<768*1024**2:
   errors.append('memory headroom below 768 MiB')
   if server is not None:server.terminate()
   stop.set()
  stop.wait(.1)
def recognize(pace=False):
 st=rec.create_stream();start=time.monotonic();decode_s=0;fed_samples=0
 for index in range(0,len(pcm),320):
  if stop.is_set():break
  chunk=pcm[index:index+320];st.accept_waveform(16000,chunk);fed_samples+=len(chunk);t=time.monotonic()
  while rec.is_ready(st):rec.decode_stream(st)
  decode_s+=time.monotonic()-t
  if pace:stop.wait(max(0,start+(index+320)/16000-time.monotonic()))
 st.accept_waveform(16000,np.zeros(12800,dtype='float32'));st.input_finished();t=time.monotonic()
 while rec.is_ready(st):rec.decode_stream(st)
 decode_s+=time.monotonic()-t
 return {'text':rec.get_result(st),'elapsed_seconds':time.monotonic()-start,'decode_seconds':decode_s,'input_duration_seconds':len(pcm)/16000,'paced':pace,'interrupted':fed_samples<len(pcm)}
def asr_loop():
 try:
  while not stop.is_set():asr_runs.append(recognize(True));stop.wait(.3)
 except Exception as e:errors.append('ASR: '+repr(e));stop.set()
def llm_loop(text):
 try:
  while not stop.is_set():llm_runs.append(translation(text));stop.wait(1.0)
 except Exception as e:errors.append('LLM: '+repr(e));stop.set()
def parent_cleanup():ctypes.CDLL(None).prctl(1,signal.SIGTERM)
try:
 with socket.socket() as s:
  if s.connect_ex(('127.0.0.1',18204))==0:raise RuntimeError('test port 18204 already occupied')
 bindir=Path('/home/moyamryia/mozart-archive/qwen35/llama.cpp/build-cuda-bin')
 model='/home/moyamryia/mozart-archive/qwen35/gguf/qwen35-0.8b-text-Q4_K_M.gguf'
 report['llm_model']=model;report['llm_model_sha256']=hashlib.sha256(Path(model).read_bytes()).hexdigest()
 env=os.environ.copy();env['LD_LIBRARY_PATH']=str(bindir)+':'+env.get('LD_LIBRARY_PATH','')
 log=(out/'llama-server.log').open('w')
 server=subprocess.Popen([str(bindir/'llama-server'),'-m',model,'-c','2048','-ngl','99','-np','1','-t','2','-tb','2','--host','127.0.0.1','--port','18204','--jinja'],env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=parent_cleanup)
 watcher=threading.Thread(target=monitor);watcher.start();workers.append(watcher)
 for i in range(180):
  if server.poll() is not None:raise RuntimeError('LLM exited during startup')
  if stop.is_set():raise RuntimeError('resource guard stopped startup')
  try:
   with urllib.request.urlopen('http://127.0.0.1:18204/health',timeout=1) as r:
    if r.status==200:break
  except Exception:pass
  stop.wait(.5)
 else:raise RuntimeError('LLM readiness timeout')
 print('LLM ready',flush=True)
 m=Path('/home/moyamryia/models/sherpa-onnx/zipformer-zh-14M')
 rec=sherpa_onnx.OnlineRecognizer.from_transducer(tokens=str(m/'tokens.txt'),encoder=str(m/'encoder-epoch-99-avg-1.onnx'),decoder=str(m/'decoder-epoch-99-avg-1.onnx'),joiner=str(m/'joiner-epoch-99-avg-1.onnx'),num_threads=2,sample_rate=16000,feature_dim=80,decoding_method='greedy_search',provider='cpu')
 src=out/'source-zh-male-16k.wav'
 subprocess.run(['ffmpeg','-loglevel','error','-y','-i',str(root/'reference-zh-male.wav'),'-ar','16000','-ac','1',str(src)],check=True)
 pcm,sr=sf.read(src,dtype='float32');assert sr==16000
 report['asr_initial']=recognize(False)
 report['initial_translation']=translation(report['asr_initial']['text'])
 print(json.dumps(report['initial_translation'],ensure_ascii=False),flush=True)
 original=json.loads((root/'fixtures.json').read_text())['cases']
 base_cases=[original[1],original[3],dict(id='translated_source',reference='reference-zh-male.wav',reference_text=original[1]['reference_text'],text=report['initial_translation']['translation'])]
 cases=[dict(case,id=case['id']+'_round_'+str(round+1)) for round in range(5) for case in base_cases]
 (root/'fixtures-concurrent.json').write_text(json.dumps({'cases':cases},indent=2,ensure_ascii=False))
 for func,arg in [(asr_loop,()),(llm_loop,(report['asr_initial']['text'],))]:
  t=threading.Thread(target=func,args=arg);t.start();workers.append(t)
 sys.argv=['benchmark.py','--engine','pocket','--assets',str(assets),'--fixtures',str(root/'fixtures-concurrent.json'),'--output',str(out),'--threads','2','--silence-scale','1']
 benchmark.main();report['success']=not errors
finally:
 stop.set()
 for worker in workers:worker.join(timeout=35)
 if server is not None:
  server.terminate()
  try:server.wait(timeout=10)
  except subprocess.TimeoutExpired:server.kill();server.wait()
  log.close()
 report.update({'asr_runs':asr_runs,'llm_runs':llm_runs,'errors':errors,'final_after_cleanup':benchmark.memory()})
 if samples:
  report['minimum_available_bytes']=min(x['available_bytes'] for x in samples)
  report['maximum_swap_used_bytes']=max(x['swap_used_bytes'] for x in samples)
  report['peak_llm_rss_bytes']=max(x.get('llm_rss_bytes',0) for x in samples)
 with (out/'fullstack-memory.jsonl').open('w') as f:
  for m in samples:f.write(json.dumps(m)+'\n')
 (out/'fullstack.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));print(json.dumps(report,ensure_ascii=False),flush=True)
