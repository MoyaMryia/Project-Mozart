#!/usr/bin/env python3
"""Create bounded, hash-traced prompts from existing Qiqi PyTorch Golden WAVs."""
import hashlib,json,time
from pathlib import Path
import numpy as np,soundfile as sf,librosa,torch
from transformers import WhisperFeatureExtractor,WhisperTokenizerFast,WhisperForConditionalGeneration
root=Path(__file__).resolve().parent
project=root.parents[2]
golden=project/'rvc-golden'
manifest=json.loads((golden/'golden_manifest.json').read_text())
records=manifest['standards']+manifest['reference_cases']
selected=[('espeak','offline-audible'),('natural-source','preprocessor-sample-mp4-30s-offline-audible')]
torch.set_num_threads(2)
snapshot=next(Path('/home/moyamryia/mozart-archive/seedVC/checkpoints/hf_cache/models--openai--whisper-small/snapshots').iterdir())
feature=WhisperFeatureExtractor.from_pretrained(snapshot,local_files_only=True)
tokenizer=WhisperTokenizerFast.from_pretrained(root.parent/'test-20261004/mozart-whisper-tokenizer',local_files_only=True)
model=WhisperForConditionalGeneration.from_pretrained(snapshot,local_files_only=True,torch_dtype=torch.float16).to('cuda').eval()
references=[]
for label,id in selected:
 rec=next(r for r in records if r['id']==id);source=golden/rec['output']
 digest=hashlib.sha256(source.read_bytes()).hexdigest();assert digest==rec['output_sha256']
 audio,sr=sf.read(source,dtype='float32');assert audio.ndim==1 and np.isfinite(audio).all()
 # Choose an existing quiet phrase boundary between 4 and 8 seconds.
 hop=sr//100;frame_count=min(len(audio)//hop,800)
 rms=np.sqrt(np.mean(audio[:frame_count*hop].reshape(frame_count,hop).astype('float64')**2,axis=1))
 quiet=rms<max(.001,float(rms.max())*.035)
 runs=[];start=None
 for i,v in enumerate(quiet):
  if v and start is None:start=i
  if start is not None and (not v or i==len(quiet)-1):
   end=i if not v else i+1
   if end-start>=18 and start>=400:runs.append((start,end))
   start=None
 end_sample=(runs[-1][0]+min(10,runs[-1][1]-runs[-1][0]))*hop if runs else min(len(audio),8*sr)
 ref=audio[:end_sample]
 ref=librosa.resample(ref,orig_sr=sr,target_sr=24000)
 target=root/('reference-qiqi-'+label+'.wav');sf.write(target,ref,24000,subtype='FLOAT')
 pcm=librosa.resample(ref,orig_sr=24000,target_sr=16000)
 features=feature(pcm,sampling_rate=16000,return_tensors='pt',return_attention_mask=True)
 forced=tokenizer.get_decoder_prompt_ids(language='zh',task='transcribe')
 with torch.inference_mode():ids=model.generate(features.input_features.to('cuda',dtype=torch.float16),attention_mask=features.attention_mask.to('cuda'),max_new_tokens=128,do_sample=False,forced_decoder_ids=forced)
 text=tokenizer.batch_decode(ids,skip_special_tokens=True)[0].strip()
 if not text:raise ValueError('empty reference transcript')
 source_input=golden/manifest['context']['input'] if label=='espeak' else golden/'input/preprocessor-sample-mp4-first-30s.wav'
 source_input_hash=hashlib.sha256(source_input.read_bytes()).hexdigest()
 expected_input_hash=manifest['context']['input_sha256'] if label=='espeak' else rec['input_extraction']['output_sha256']
 assert source_input_hash==expected_input_hash
 original,original_sr=sf.read(source_input,dtype='float32')
 original=original[:round(end_sample/sr*original_sr)]
 if original_sr!=16000:original=librosa.resample(original,orig_sr=original_sr,target_sr=16000)
 sf.write(root/('source-input-'+label+'-span.wav'),original,16000,subtype='FLOAT')
 features=feature(original,sampling_rate=16000,return_tensors='pt',return_attention_mask=True)
 with torch.inference_mode():ids=model.generate(features.input_features.to('cuda',dtype=torch.float16),attention_mask=features.attention_mask.to('cuda'),max_new_tokens=128,do_sample=False,forced_decoder_ids=forced)
 source_text=tokenizer.batch_decode(ids,skip_special_tokens=True)[0].strip()
 if not source_text:raise ValueError('empty source transcript')
 entry={'id':label,'source':str(source),'golden_id':id,'source_sha256':digest,'reference':target.name,'reference_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'start_seconds':0,'end_seconds':end_sample/sr,'reference_duration_seconds':len(ref)/24000,'sample_rate':24000,'reference_text':source_text,'converted_reference_asr_text':text,'source_input':str(source_input),'source_input_sha256':source_input_hash,'transcript_source':'Whisper-small ASR on original source audio over the matching time span; not manually verified','rms':float(np.sqrt(np.mean(ref.astype('float64')**2))),'peak':float(np.max(np.abs(ref)))}
 references.append(entry);print(json.dumps(entry,ensure_ascii=False),flush=True)
 (root/'references.json').write_text(json.dumps({'checkpoint_metadata':manifest['context']['model']['metadata'],'references':references},indent=2,ensure_ascii=False))
cases=[]
for ref in references:
 for suffix in ['cold','warm']:
  cases.append({'id':ref['id']+'_'+suffix,'reference':ref['reference'],'reference_text':ref['reference_text'],'language':'en','text':'Hello, this is Mozart, and this translation is spoken using a reference voice.'})
(root/'fixtures.json').write_text(json.dumps({'cases':cases},indent=2,ensure_ascii=False))
zh=[]
for ref in references:
 zh.append({'id':ref['id']+'_zh','reference':ref['reference'],'reference_text':ref['reference_text'],'language':'zh','text':'你好，这里是莫扎特，现在用参考声音播报翻译后的文本。'})
(root/'fixtures-bilingual.json').write_text(json.dumps({'cases':cases+zh},indent=2,ensure_ascii=False))
