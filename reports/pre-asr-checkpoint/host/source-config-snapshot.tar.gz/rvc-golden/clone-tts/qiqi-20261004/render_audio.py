#!/usr/bin/env python3
"""PCM16 audition copies with explicitly recorded gain; original outputs preserved."""
import hashlib,json
from pathlib import Path
import numpy as np,soundfile as sf
root=Path(__file__).resolve().parent
out=root/'audition';out.mkdir(exist_ok=True)
files={
'reference-qiqi.wav':'reference-qiqi-natural-source.wav',
'reference-qiqi-espeak.wav':'reference-qiqi-espeak.wav',
'qiqi-pocket-english.wav':'pocket/pocket-natural-source_warm.wav',
'qiqi-pocket-espeak-english.wav':'pocket/pocket-espeak_warm.wav',
'qiqi-zipvoice-english.wav':'zipvoice-wav-transcript/zipvoice-natural-source_warm.wav',
'qiqi-zipvoice-chinese.wav':'zipvoice-wav-transcript/zipvoice-natural-source_zh.wav',
'qiqi-zipvoice-espeak-english.wav':'zipvoice-wav-transcript/zipvoice-espeak_warm.wav',
'qiqi-zipvoice-initial-english.wav':'zipvoice/zipvoice-natural-source_warm.wav',
}
records=[]
for target,source in files.items():
 path=root/source
 pcm,sr=sf.read(path,dtype='float32');peak=float(np.max(np.abs(pcm)));gain=min(1.,.95/max(peak,1e-12))
 dest=out/target;sf.write(dest,pcm*gain,sr,subtype='PCM_16')
 records.append({'source':source,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'audition':target,'audition_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'gain':gain,'original_peak':peak,'duration_seconds':len(pcm)/sr})
(out/'manifest.json').write_text(json.dumps(records,indent=2))
print(json.dumps(records,indent=2))
