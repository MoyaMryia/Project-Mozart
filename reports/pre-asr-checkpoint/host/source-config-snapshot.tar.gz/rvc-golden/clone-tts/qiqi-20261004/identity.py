#!/usr/bin/env python3
"""Exploratory CAMPPlus similarity; no calibrated voice-identity pass threshold."""
import hashlib,json,sys,time
from pathlib import Path
import numpy as np
import soundfile as sf
import librosa
import torch
root=Path(__file__).resolve().parent
torch.set_num_threads(2)
sys.path.insert(0,'/home/moyamryia/mozart-archive/seedVC')
from modules.campplus.DTDNN import CAMPPlus
# fbank uses pure Torch. Avoid the package's incompatible CUDA extension loader;
# the only torchaudio call in this file is in unused MFCC/DCT code, not fbank.
kaldi_path=Path('/home/moyamryia/vc_backend_venv/lib/python3.12/site-packages/torchaudio/compliance/kaldi.py')
source=kaldi_path.read_text();assert source.count('import torchaudio\n')==1
namespace={};exec(compile(source.replace('import torchaudio\n','',1),str(kaldi_path),'exec'),namespace)
fbank=namespace['fbank']
ckpt=next(Path('/home/moyamryia/mozart-archive/seedVC/checkpoints/models--funasr--campplus/snapshots').glob('*/campplus_cn_common.bin'))
model=CAMPPlus(feat_dim=80,embedding_size=192).eval()
model.load_state_dict(torch.load(ckpt,map_location='cpu',weights_only=True),strict=True)
def embed(path):
 a,sr=sf.read(path,dtype='float32')
 if sr!=16000:a=librosa.resample(a,orig_sr=sr,target_sr=16000)
 features=fbank(torch.from_numpy(a).unsqueeze(0),num_mel_bins=80,dither=0,sample_frequency=16000)
 features-=features.mean(dim=0,keepdim=True)
 with torch.inference_mode():e=model(features.unsqueeze(0)).squeeze(0).numpy()
 assert e.shape==(192,) and np.isfinite(e).all()
 return e/np.linalg.norm(e)
refs={r['id']:embed(root/r['reference']) for r in json.loads((root/'references.json').read_text())['references']}
refs['unrelated-zh-male']=embed(root.parent/'test-20261004/reference-zh-male.wav')
refs['unrelated-zh-female']=embed(root.parent/'test-20261004/reference-zh-female.wav')
results=[]
for engine in ['zipvoice','pocket','zipvoice-wav-transcript']:
 p=root/engine/'results.json'
 if not p.exists():continue
 for run in json.loads(p.read_text())['runs']:
  if '_round_' in run['case'] and not run['case'].endswith('_round_1'):continue
  if run['case'] in ['zh_male_cold','zh_male_warm_2']:continue
  v=embed(run['output']);scores={k:float(np.dot(v,e)) for k,e in refs.items()}
  result={'engine':engine,'case':run['case'],'cosine_to_references':scores}
  results.append(result);print(json.dumps(result),flush=True)
report={'model':'funasr/campplus_cn_common','embedding_size':192,'checkpoint_sha256':hashlib.sha256(ckpt.read_bytes()).hexdigest(),'kaldi_source_sha256':hashlib.sha256(kaldi_path.read_bytes()).hexdigest(),'preprocessing':'16k mono, official pure-Torch fbank, 80 mel bins, dither 0, temporal mean subtraction; torchaudio package import omitted to avoid CUDA mismatch; no MFCC called','references_cross_similarity':float(np.dot(refs['espeak'],refs['natural-source'])),'not_a_calibrated_acceptance_test':True,'results':results}
(root/'identity-evaluation.json').write_text(json.dumps(report,indent=2))
np.savez(root/'reference-embeddings.npz',**refs)
