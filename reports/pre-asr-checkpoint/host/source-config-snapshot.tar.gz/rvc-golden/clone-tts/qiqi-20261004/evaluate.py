#!/usr/bin/env python3
"""Offline English ASR check; run only after TTS benchmarks have exited."""
import json, re, time
from pathlib import Path
import numpy as np
import soundfile as sf
import librosa
import torch
from transformers import WhisperFeatureExtractor, WhisperTokenizerFast, WhisperForConditionalGeneration
root=Path(__file__).resolve().parent
torch.set_num_threads(2)
snapshot=next(Path('/home/moyamryia/mozart-archive/seedVC/checkpoints/hf_cache/models--openai--whisper-small/snapshots').iterdir())
feature=WhisperFeatureExtractor.from_pretrained(snapshot,local_files_only=True)
tokenizer=WhisperTokenizerFast.from_pretrained(root.parent/'test-20261004/mozart-whisper-tokenizer',local_files_only=True)
device='cuda'
model=WhisperForConditionalGeneration.from_pretrained(snapshot,local_files_only=True,torch_dtype=torch.float16).to(device).eval()
# Explicit decoder prefix avoids needing another downloaded generation configuration.
forced=tokenizer.get_decoder_prompt_ids(language='en',task='transcribe')
model.generation_config.forced_decoder_ids=forced

def words(s): return re.findall(r"[a-z]+(?:'[a-z]+)?|[0-9]+",s.lower())
ZH_VARIANTS=str.maketrans({'這':'这','裡':'里','聲':'声','參':'参','譯':'译','後':'后','報':'报','現':'现'})
def wer(ref,hyp,language):
 if language=='zh':
  r,h=re.findall(r'[\u4e00-\u9fff]',ref.translate(ZH_VARIANTS)),re.findall(r'[\u4e00-\u9fff]',hyp.translate(ZH_VARIANTS))
 else:r,h=words(ref),words(hyp)
 prev=list(range(len(h)+1))
 for i,a in enumerate(r,1):
  cur=[i]
  for j,b in enumerate(h,1):cur.append(min(prev[j]+1,cur[j-1]+1,prev[j-1]+(a!=b)))
  prev=cur
 return prev[-1]/len(r)
results=[]
for engine in ['zipvoice','pocket','zipvoice-wav-transcript']:
 p=root/engine/'results.json'
 if not p.exists():continue
 for run in json.loads(p.read_text())['runs']:
  if '_round_' in run['case'] and not run['case'].endswith('_round_1'):continue
  if run['case'] in ['zh_male_cold','zh_male_warm_2']:continue
  language=run.get('language','en')
  forced=tokenizer.get_decoder_prompt_ids(language=language,task='transcribe')
  wav,sr=sf.read(run['output'],dtype='float32')
  if sr!=16000:wav=librosa.resample(wav,orig_sr=sr,target_sr=16000)
  features=feature(wav,sampling_rate=16000,return_tensors='pt',return_attention_mask=True)
  inputs=features.input_features.to(device,dtype=model.dtype)
  mask=features.attention_mask.to(device)
  t0=time.monotonic()
  try:
   with torch.inference_mode(): ids=model.generate(inputs,attention_mask=mask,max_new_tokens=128,do_sample=False,forced_decoder_ids=forced)
  except RuntimeError:
   if device=='cpu':raise
   print('GPU ASR unavailable; retrying on CPU without changing the environment.',flush=True)
   device='cpu';model=model.to(device).float();torch.cuda.empty_cache();inputs=inputs.to(device,dtype=model.dtype)
   with torch.inference_mode():ids=model.generate(inputs,attention_mask=mask.cpu(),max_new_tokens=128,do_sample=False,forced_decoder_ids=forced)
  text=tokenizer.batch_decode(ids,skip_special_tokens=True)[0]
  result={'engine':engine,'case':run['case'],'language':language,'expected':run['text'],'transcribed':text,'error_rate':wer(run['text'],text,language),'metric':'CER' if language=='zh' else 'WER','asr_seconds':time.monotonic()-t0}
  results.append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
  (root/'asr-evaluation.json').write_text(json.dumps({'model':'cached openai/whisper-small','torch':torch.__version__,'device':device,'chinese_character_normalization':'The observed traditional variants 這裡聲參譯後報現 are mapped to 这里声参译后报现; Mozart name 札 vs 扎 is retained as a surface difference. This is not a general Traditional Chinese converter.','results':results},indent=2,ensure_ascii=False))
