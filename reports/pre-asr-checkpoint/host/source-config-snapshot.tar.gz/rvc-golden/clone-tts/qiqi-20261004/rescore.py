#!/usr/bin/env python3
"""Recompute scores from saved transcripts without rerunning recognition."""
import json,re
from pathlib import Path
root=Path(__file__).resolve().parent
p=root/'asr-evaluation.json';r=json.loads(p.read_text())
variants=str.maketrans({'這':'这','裡':'里','聲':'声','參':'参','譯':'译','後':'后','報':'报','現':'现'})
def error_rate(ref,hyp,language):
 if language=='zh':
  a,b=re.findall(r'[\u4e00-\u9fff]',ref.translate(variants)),re.findall(r'[\u4e00-\u9fff]',hyp.translate(variants))
 else:
  a,b=[re.findall(r"[a-z]+(?:'[a-z]+)?|[0-9]+",x.lower()) for x in [ref,hyp]]
 prev=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  cur=[i]
  for j,y in enumerate(b,1):cur.append(min(prev[j]+1,cur[-1]+1,prev[j-1]+(x!=y)))
  prev=cur
 return prev[-1]/len(a)
for run in r['results']:run['error_rate']=error_rate(run['expected'],run['transcribed'],run['language'])
r['chinese_character_normalization']='The observed traditional variants 這裡聲參譯後報現 are mapped to 这里声参译后报现; Mozart name 札 vs 扎 is retained as a surface difference. This is not a general Traditional Chinese converter.'
p.write_text(json.dumps(r,indent=2,ensure_ascii=False))
print([(x['engine'],x['case'],x['error_rate']) for x in r['results'] if x['language']=='zh'])
