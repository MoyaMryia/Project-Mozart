#!/usr/bin/env python3
"""Standalone cloning benchmark. No microphone, playback or Mozart mode changes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import threading
import time


def memory():
    values = {}
    for line in Path('/proc/meminfo').read_text().splitlines():
        k, v = line.split(':', 1)
        values[k] = int(v.split()[0]) * 1024
    status = {}
    for line in Path('/proc/self/status').read_text().splitlines():
        if line.startswith(('VmRSS:', 'VmHWM:')):
            k, v = line.split(':', 1)
            status[k] = int(v.split()[0]) * 1024
    return {'monotonic_s': time.monotonic(), 'available_bytes': values['MemAvailable'],
            'used_unavailable_bytes': values['MemTotal'] - values['MemAvailable'],
            'swap_used_bytes': values['SwapTotal'] - values['SwapFree'],
            'rss_bytes': status.get('VmRSS', 0), 'hwm_bytes': status.get('VmHWM', 0)}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--engine', choices=['zipvoice', 'pocket'], required=True)
    p.add_argument('--assets', type=Path, required=True)
    p.add_argument('--fixtures', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--threads', type=int, default=2)
    p.add_argument('--steps', type=int)
    p.add_argument('--silence-scale', type=float)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    baseline = memory()
    samples, phase, stopped = [], ['imports'], threading.Event()

    def monitor():
        while not stopped.is_set():
            m = memory()
            m['phase'] = phase[0]
            samples.append(m)
            if m['available_bytes'] < 768 * 1024**2:
                (args.output / 'resource-stop.json').write_text(json.dumps(m, indent=2))
                os._exit(75)
            stopped.wait(.1)

    watcher = threading.Thread(target=monitor, daemon=True)
    watcher.start()
    report = {'engine': args.engine, 'threads': args.threads, 'provider': 'cpu',
              'baseline': baseline, 'runs': []}
    try:
        import numpy as np
        import soundfile as sf
        import sherpa_onnx
        report['sherpa_onnx'] = sherpa_onnx.__version__
        a = args.assets
        if args.engine == 'zipvoice':
            m = a / 'sherpa-onnx-zipvoice-distill-int8-zh-en-emilia'
            model = sherpa_onnx.OfflineTtsModelConfig(
                zipvoice=sherpa_onnx.OfflineTtsZipvoiceModelConfig(
                    tokens=str(m/'tokens.txt'), encoder=str(m/'encoder.int8.onnx'),
                    decoder=str(m/'decoder.int8.onnx'), data_dir=str(m/'espeak-ng-data'),
                    lexicon=str(m/'lexicon.txt'), vocoder=str(a/'vocos_24khz.onnx')),
                num_threads=args.threads, provider='cpu', debug=False)
            steps = args.steps or 4
        else:
            m = a / 'sherpa-onnx-pocket-tts-int8-2026-01-26'
            model = sherpa_onnx.OfflineTtsModelConfig(
                pocket=sherpa_onnx.OfflineTtsPocketModelConfig(
                    lm_flow=str(m/'lm_flow.int8.onnx'), lm_main=str(m/'lm_main.int8.onnx'),
                    encoder=str(m/'encoder.onnx'), decoder=str(m/'decoder.int8.onnx'),
                    text_conditioner=str(m/'text_conditioner.onnx'), vocab_json=str(m/'vocab.json'),
                    token_scores_json=str(m/'token_scores.json')),
                num_threads=args.threads, provider='cpu', debug=False)
            steps = args.steps or 5
        cfg = sherpa_onnx.OfflineTtsConfig(model=model)
        if not cfg.validate():
            raise RuntimeError('invalid TTS configuration')
        phase[0] = 'load'
        t0 = time.monotonic()
        tts = sherpa_onnx.OfflineTts(cfg)
        report['load_seconds'] = time.monotonic() - t0
        report['after_load'] = memory()
        fixture = json.loads(args.fixtures.read_text())
        report['fixture_sha256'] = hashlib.sha256(args.fixtures.read_bytes()).hexdigest()
        for test in fixture['cases']:
            phase[0] = test['id']
            ref = args.fixtures.parent / test['reference']
            audio_ref, sr = sf.read(ref, dtype='float32')
            if audio_ref.ndim != 1:
                raise ValueError('references must be mono')
            gen = sherpa_onnx.GenerationConfig()
            gen.reference_audio = audio_ref
            gen.reference_sample_rate = sr
            gen.num_steps = steps
            gen.speed = 1.0
            if args.silence_scale is not None:
                gen.silence_scale = args.silence_scale
            if args.engine == 'zipvoice':
                gen.reference_text = test['reference_text']
            else:
                gen.extra = {'seed': '42'}
            callbacks = []
            started = time.monotonic()
            cpu0 = time.process_time()

            def callback(audio, progress):
                callbacks.append({'seconds': time.monotonic()-started,
                                  'samples': len(audio), 'progress': float(progress)})
                return 1  # Native Pocket/ZipVoice implementations: nonzero continues.

            out = tts.generate(test['text'], gen, callback)
            elapsed = time.monotonic() - started
            cpu_s = time.process_time() - cpu0
            pcm = np.asarray(out.samples, dtype=np.float32)
            if not len(pcm) or not np.isfinite(pcm).all():
                raise RuntimeError('empty or nonfinite generated audio')
            rate = int(out.sample_rate)
            duration = len(pcm) / rate
            filename = args.output / (args.engine+'-'+test['id']+'.wav')
            sf.write(filename, pcm, rate, subtype='FLOAT')
            spectrum = np.abs(np.fft.rfft(pcm))
            frequencies = np.fft.rfftfreq(len(pcm), 1/rate)
            centroid = float(np.sum(spectrum*frequencies)/max(float(spectrum.sum()), 1e-12))
            run = {'case': test['id'], 'text': test['text'], 'language': test.get('language', 'en'), 'reference': str(ref),
                   'reference_sha256': hashlib.sha256(ref.read_bytes()).hexdigest(),
                   'reference_duration_seconds': len(audio_ref)/sr, 'steps': steps,
                   'silence_scale': gen.silence_scale,
                   'elapsed_seconds': elapsed, 'cpu_seconds': cpu_s,
                   'duration_seconds': duration, 'rtf': elapsed/duration,
                   'first_callback_seconds': callbacks[0]['seconds'] if callbacks else None,
                   'callbacks': callbacks, 'sample_rate': rate, 'samples': len(pcm),
                   'rms': float(np.sqrt(np.mean(pcm.astype(np.float64)**2))),
                   'peak': float(np.max(np.abs(pcm))),
                   'clipped_percent': float(np.mean(np.abs(pcm)>=1.0)*100),
                   'spectral_centroid_hz': centroid, 'finite': True,
                   'output': str(filename), 'output_sha256': hashlib.sha256(filename.read_bytes()).hexdigest(),
                   'memory_after': memory()}
            report['runs'].append(run)
            (args.output/'results.json').write_text(json.dumps(report, indent=2, ensure_ascii=False))
            print(json.dumps({k:v for k,v in run.items() if k not in ['callbacks']}, ensure_ascii=False), flush=True)
        report['success'] = True
    finally:
        stopped.set()
        watcher.join(timeout=2)
        report['peak_rss_bytes'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
        if samples:
            report['minimum_available_bytes'] = min(s['available_bytes'] for s in samples)
            report['maximum_swap_used_bytes'] = max(s['swap_used_bytes'] for s in samples)
        (args.output/'results.json').write_text(json.dumps(report, indent=2, ensure_ascii=False))
        with (args.output/'memory.jsonl').open('w') as f:
            for s in samples:
                f.write(json.dumps(s)+'\n')


if __name__ == '__main__':
    main()
