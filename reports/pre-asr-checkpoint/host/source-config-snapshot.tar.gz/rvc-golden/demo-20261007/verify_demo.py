from pathlib import Path
import hashlib,json,re,wave
import numpy as np
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent;RUN=BASE/'mock-v1'
summary=json.loads((RUN/'summary.json').read_text());piecehashes=json.loads((RUN/'piece-hashes.json').read_text())
old=ROOT/'rvc-golden/sentence-context-20261007/short-v2'
previous=json.loads((old/'jobs.json').read_text())
bytext={j['text']:j for j in previous if j['status']=='completed'}
newcaptions=[json.loads(l) for l in (RUN/'runtime/subtitles.jsonl').read_text().splitlines() if l]
oldcaptions=[json.loads(l) for l in (old/'runtime/subtitles.jsonl').read_text().splitlines() if l]
assert [(c['seq'],c['zh'],c['en']) for c in newcaptions]==[(c['seq'],c['zh'],c['en']) for c in oldcaptions]
assert '6000' in (RUN/'runtime/microphone.log').read_text() and 'overruns=0' in (RUN/'runtime/microphone.log').read_text()
words=lambda text:re.findall(r'\w+',text)
def read(p):
 with wave.open(str(p),'rb') as w:return (w.getnchannels(),w.getsampwidth(),w.getframerate()),w.readframes(w.getnframes())
matched=0;totalpieces=0;segments=[];peaks=[]
completed=sorted(summary['jobs'],key=lambda j:j['created_at'])
settings=None
for j in completed:
 p=RUN/'archive'/(j['id']+'.wav');digest=hashlib.sha256(p.read_bytes()).hexdigest()
 assert digest==j['collected_audio_sha256'];params,pcm=read(p)
 if settings is None:settings=params
 assert params==settings
 pieces=[]
 for chunk in j['chunks']:
  cp=RUN/'archive-chunks'/chunk['filename'];assert hashlib.sha256(cp.read_bytes()).hexdigest()==piecehashes[cp.name]
  cparams,cpcm=read(cp);assert cparams==params;pieces.append(cpcm);totalpieces+=1
 assert b''.join(pieces)==pcm
 assert words(' '.join(c['text'] for c in j['chunks']))==words(j['text'])
 for c in j['chunks']:assert words(c.get('synthesis_text',c['text']))==words(c['text'])
 x=np.frombuffer(pcm,dtype=np.int16).astype(float)/32768
 assert np.isfinite(x).all() and np.max(np.abs(x))<1;peaks.append(float(np.max(np.abs(x))))
 before=bytext[j['text']];matched+=hashlib.sha256((old/'archive'/(before['id']+'.wav')).read_bytes()).hexdigest()==digest
 segments.append(pcm)
combined=RUN/'qiqi-translated-combined.wav'
with wave.open(str(combined),'wb') as w:
 w.setnchannels(settings[0]);w.setsampwidth(settings[1]);w.setframerate(settings[2]);w.writeframes(b''.join(segments))
_,joined=read(combined);assert joined==b''.join(segments)
seconds=len(joined)/(settings[0]*settings[1]*settings[2]);assert seconds==summary['speech_seconds']
checks=json.loads((BASE/'functional-v1/checks.json').read_text());assert checks['failure'] is None
ui=json.loads((RUN/'ui-checks.json').read_text());p=RUN/'archive'/(ui['UI_preview']['id']+'.wav');assert hashlib.sha256(p.read_bytes()).hexdigest()==ui['UI_preview_sha256']
for preview in checks['checks']['previews_after_cancellation']:
 p=BASE/'functional-v1'/(preview['job']['id']+'.wav');assert hashlib.sha256(p.read_bytes()).hexdigest()==preview['audio']['sha256']
receipt={'parents_verified':len(completed),'pieces_verified':totalpieces,'exact_ordered_PCM':True,'source_and_synthesis_words_preserved':True,'recognition_translation_matches_previous_captions':24,'matching_previous_parent_WAVs':matched,'combined_seconds':seconds,'combined_sha256':hashlib.sha256(combined.read_bytes()).hexdigest(),'peak_max':max(peaks),'UI_preview_verified':True,'functional_preview_hashes_verified':2,'semantic_translation_accuracy_claim':False,'english_fixture_fact_review':{'passed':['from-passage-9','from-passage-10','clause-from-passage-8'],'awkward_fragment':['from-passage-18'],'basis':'assistant comparison to user-confirmed Chinese; not human voice approval'}}
(RUN/'verification-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt))
