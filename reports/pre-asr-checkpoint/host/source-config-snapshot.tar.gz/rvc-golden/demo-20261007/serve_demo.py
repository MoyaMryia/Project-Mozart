"""Own a live demo stack and the cross-campaign workload lock."""
from pathlib import Path
import fcntl, json, os, signal, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(sys.argv[1]);HERE.mkdir(parents=True,exist_ok=True)
lock=(ROOT/'rvc-golden/reliability-20261006/active-test.lock').open('a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
command=[str(ROOT/'.venv/bin/python'),str(ROOT/'tools/run_translated_speech.py'),
 '--backend-config',str(ROOT/'state/translated-speech.yaml'),
 '--llama-model','/home/moyamryia/models/mozart-translation/Qwen3.5-4B-Q4_K_M.gguf',
 '--final-model','/home/moyamryia/models/sherpa-onnx/clone-test-downloads/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2024-07-17',
 '--input','/tmp/test-audio.mp4','--start','720','--seconds','120','--keep-open',
 '--playback-device','null',
 '--reference',str(ROOT/'rvc-golden/clone-tts/qiqi-20261004/reference-qiqi-natural-source.wav'),
 '--reference-name','Qiqi · mock demo',
 '--data-dir',str(ROOT/'rvc-golden/demo-20261007/speech'), '--run-dir',str(HERE/'runtime')]
stop=False
def request_stop(*args):
 global stop
 stop=True
signal.signal(signal.SIGTERM,request_stop);signal.signal(signal.SIGINT,request_stop)
with (HERE/'supervisor.log').open('x') as log:
 child=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (HERE/'pids.json').write_text(json.dumps({'owner':os.getpid(),'supervisor':child.pid,'command':command,'started_at':time.time()},indent=2)+'\n')
 try:
  while child.poll() is None and not stop:time.sleep(.2)
 finally:
  if child.poll() is None:
   child.terminate()
   try:child.wait(timeout=70)
   except subprocess.TimeoutExpired:
    os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
  (HERE/'exit-status.json').write_text(json.dumps({'returncode':child.returncode,'stop_requested':stop,'finished_at':time.time()},indent=2)+'\n')
