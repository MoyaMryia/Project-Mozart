"""Sequential functional checks against the already-running demo stack."""
from pathlib import Path
import base64,hashlib,json,sys,time,urllib.request,urllib.error,wave
import numpy as np
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from subtitle_bridge import translate_recognized_event
OUT=BASE/'functional-v1';OUT.mkdir()
checks={};failed=None
API='http://127.0.0.1:18080'
def req(path,body=None,method=None):
 r=urllib.request.Request(API+path,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json'},method=method)
 with urllib.request.urlopen(r,timeout=20) as response:return json.load(response)
def wait_job(jid,limit=50):
 end=time.monotonic()+limit
 while time.monotonic()<end:
  j=req('/api/speech/jobs/'+jid)
  if j['status'] in ('completed','failed','expired','cancelled'):return j
  time.sleep(.15)
 raise RuntimeError('Job did not finish within check deadline')
def archive(j):
 assert j['status']=='completed',j
 with urllib.request.urlopen(API+j['result_url'],timeout=10) as response:data=response.read()
 p=OUT/(j['id']+'.wav');p.write_bytes(data)
 with wave.open(str(p),'rb') as w:
  assert w.getsampwidth()==2 and w.getnchannels()==1
  x=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).astype(np.float64)/32768
  info={'seconds':len(x)/w.getframerate(),'sample_rate':w.getframerate(),'peak':float(np.max(np.abs(x))),'rms':float(np.sqrt(np.mean(x*x))),'sha256':hashlib.sha256(data).hexdigest()}
 assert info['seconds']>0 and 0<info['peak']<1 and np.isfinite(x).all(),info
 return info
try:
 status=req('/api/speech/status');assert status.get('runtime') and not status.get('warmup_error')
 checks['warmup_ready']=True
 req('/api/speech/session',{'enabled':False,'playback':False})
 ref=ROOT/'rvc-golden/clone-tts/qiqi-20261004/reference-qiqi-natural-source.wav'
 voice=req('/api/voices',{'name':'Qiqi · demo','audio_base64':base64.b64encode(ref.read_bytes()).decode(),'language':'zh'})
 checks['voice']=voice
 for label,body,expected in [('empty-text',{'text':'','voice_id':voice['id'],'language':'en'},[400,422]),('unsupported-output',{'text':'测试','voice_id':voice['id'],'language':'zh'},[422]),('missing-voice',{'text':'Hello.','voice_id':'missing-demo-voice','language':'en'},[404])]:
  try:req('/api/speech/jobs',body);raise AssertionError('Unexpected admission: '+label)
  except urllib.error.HTTPError as e:assert e.code in expected,(label,e.code);checks[label]={'http_status':e.code}
 fixtures=json.loads((BASE/'demo-text-fixtures.json').read_text())['fixtures'];translated=[]
 for fixture in fixtures:
  audit=[];text,elapsed=translate_recognized_event('http://127.0.0.1:18200',{'text':fixture['source']},audit)
  translated.append({**fixture,'generated_english':text,'translation_seconds':elapsed,'audit':audit});print(json.dumps({'fixture':fixture['id'],'english':text},ensure_ascii=False),flush=True)
 checks['translations']=translated
 blockers=[('numeric',{'text':'11万块','asr_numeric_audit':{'issues':['itn_quantity_disagreement']}}),('polarity',{'text':'不可能又赢','asr_polarity_audit':{'issues':['modal_polarity_disagreement']}}),('unfinished-clause',{'text':'他不管对面是谁，不管自己啊在。'}),('mother-boundary',{'text':'妈妈已经有点不相信了妈妈。'})]
 checks['uncertainty_controls']=[]
 for label,event in blockers:
  audit=[]
  try:translate_recognized_event('http://127.0.0.1:18200',event,audit);raise AssertionError('Uncertainty accepted')
  except ValueError as e:
   assert not audit
   checks['uncertainty_controls'].append({'id':label,'rejected_before_translation':True,'reason':str(e)})
 cancel_text='This is a cancellation check. The queue should stop and recover cleanly. We are checking that the reference voice can return to normal generation after this job is cancelled, without restarting the whole application.'
 a=req('/api/speech/jobs',{'text':cancel_text,'voice_id':voice['id'],'language':'en','playback':False})
 end=time.monotonic()+5
 while time.monotonic()<end:
  before=req('/api/speech/jobs/'+a['id'])
  if before['status']=='processing':break
  time.sleep(.05)
 b=req('/api/speech/jobs',{'text':'This second queued check should also be cleared.','voice_id':voice['id'],'language':'en','playback':False})
 stopped=req('/api/speech/stop',{})
 ca=req('/api/speech/jobs/'+a['id']);cb=req('/api/speech/jobs/'+b['id'])
 assert ca['status']=='cancelled' and cb['status']=='cancelled',(ca,cb)
 assert not req('/api/speech/status')['session']['enabled']
 checks['stop_queue']={'processing_observed':before['status']=='processing','first_status':ca['status'],'second_status':cb['status'],'session_disabled':True}
 previews=[]
 for row in [translated[1],translated[3]]:
  job=req('/api/speech/jobs',{'text':row['generated_english'],'voice_id':voice['id'],'language':'en','playback':False})
  completed=wait_job(job['id']);audio=archive(completed)
  previews.append({'fixture':row['id'],'job':completed,'audio':audio});print(json.dumps({'preview':row['id'],**audio}),flush=True)
 checks['previews_after_cancellation']=previews
 checks['selected_session']=req('/api/speech/session',{'enabled':False,'voice_id':voice['id'],'language':'en','playback':False})
 checks['status']=req('/api/speech/status')
 checks['available_memory_bytes']=next(int(l.split()[1])*1024 for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:'))
 checks['physical_io']='Previously tested by user; these previews are downloads only.'
except Exception as error:
 failed=str(error);raise
finally:
 (OUT/'checks.json').write_text(json.dumps({'completed_at':time.time(),'failure':failed,'checks':checks},ensure_ascii=False,indent=2)+'\n')
