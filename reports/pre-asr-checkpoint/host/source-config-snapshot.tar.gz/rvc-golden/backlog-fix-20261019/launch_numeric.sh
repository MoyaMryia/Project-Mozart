#!/usr/bin/env bash
set -u
cd /home/moyamryia/mozart-backlog-fix-20261019/candidate-numeric
bash tools/ci-local.sh python > ../python-regression-numeric-reviewed.log 2>&1
numeric_code=$?
if [ "$numeric_code" -eq 0 ]; then
    cd ..
    /home/moyamryia/Mozart/.venv/bin/python trace_probe_numeric.py --base /home/moyamryia/mozart-backlog-fix-20261019 --repo /home/moyamryia/mozart-backlog-fix-20261019/candidate-numeric --cases /home/moyamryia/mozart-backlog-fix-20261019/trace-cases.json --only-after --after-name after-numeric-trace --paced > console-numeric-trace.log 2>&1
    numeric_code=$?
fi
printf '%s\n' "$numeric_code" > /home/moyamryia/mozart-backlog-fix-20261019/numeric-controller-exit-code
exit "$numeric_code"
