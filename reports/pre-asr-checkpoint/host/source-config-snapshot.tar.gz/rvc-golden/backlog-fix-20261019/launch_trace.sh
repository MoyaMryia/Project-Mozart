#!/usr/bin/env bash
set -u
cd /home/moyamryia/mozart-backlog-fix-20261019
/home/moyamryia/Mozart/.venv/bin/python trace_probe.py --base /home/moyamryia/mozart-backlog-fix-20261019 --cases /home/moyamryia/mozart-backlog-fix-20261019/trace-cases.json --paced > console-trace-v2-paced.log 2>&1
trace_code=$?
printf '%s\n' "$trace_code" > trace-controller-exit-code
exit "$trace_code"
