"""核对175段字幕重放的完整分母、PCM、时序和独立变速参考。"""
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import subprocess
import wave

ROOT = Path('/home/moyamryia/mozart-backlog-fix-20261019')
PHASES = ['before-trace-v2-paced', 'after-trace-v2-paced', 'after-numeric-trace-paced']


def save(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')


def stats(values):
    values = sorted(values)
    if not values:
        return {'count': 0}
    index = .95*(len(values)-1)
    lo = int(index)
    hi = min(lo+1, len(values)-1)
    return {'count':len(values),'median':statistics.median(values),
        'p95':values[lo]+(values[hi]-values[lo])*(index-lo), 'max':max(values)}


def main():
    spec = importlib.util.spec_from_file_location('collector',ROOT/'collect-reviewed.py')
    collector = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(collector)
    cases = json.loads((ROOT/'trace-cases.json').read_text())
    target = ROOT/'trace-analysis'
    target.mkdir(exist_ok=False)
    outcomes = {}
    manifests = []
    for phase in PHASES:
        root = ROOT/phase
        result = json.loads((root/'result.json').read_text())
        rows = json.loads((root/'rows.json').read_text())
        status = json.loads((root/'status.json').read_text())
        assert result['execution_complete'] and status['unfinished_jobs']==0
        assert len(rows)==len(cases) and [r['case'] for r in rows]==cases
        expected_utterances = {f'{phase}:{i+1}': i for i in range(len(cases))}
        jobs = {expected_utterances[j['utterance_id']]:j for j in status['jobs']}
        assert len(jobs)==len(status['jobs'])
        assert len({j['id'] for j in jobs.values()})==len(jobs)
        records = []
        for i,row in enumerate(rows):
            update = row['updates'][-1]
            job = jobs.get(i)
            if update.get('speech') is not None:
                assert job is not None and update['speech']==job['id'], (phase,i,'missing or mismatched admitted job')
            elif job is not None:
                assert update.get('speech_error'), (phase,i,'orphan job without request error')
            elif update['translation_status']=='completed':
                assert update.get('speech_error'), (phase,i,'accepted translation without admission outcome')
            record = {**row['case'], 'translation_status':update['translation_status'],
                'translation':update['en'], 'translation_error':update.get('translation_error'),
                'speech_skipped_reason':update.get('speech_skipped_reason'),
                'speech_request_error':update.get('speech_error')}
            if job is not None and update.get('speech_error'):
                record['admitted_with_request_error'] = True
            if job:
                record.update(job_id=job['id'],job_status=job['status'],job_error=job.get('error'),
                    generated_seconds=job.get('duration_seconds',0),
                    played_source_audio_seconds=job.get('played_duration_seconds',0),
                    queue_seconds=job.get('queue_seconds'),tempo=job.get('playback_tempo'))
                if job.get('playback_started_at') is not None:
                    record['source_final_to_first_pcm_seconds']=job['playback_started_at']-job['source_emitted_at']
                if job['status']=='completed':
                    audio = root/'speech/results'/f"{job['id']}.wav"
                    params,data,seconds = collector.read_audio(audio)
                    chunks = []
                    for index,chunk in enumerate(job['chunks']):
                        assert chunk['index']==index
                        cp,cd,cs=collector.read_audio(root/'speech/results'/chunk['filename'])
                        assert cp[:3]==params[:3]
                        chunks.append(cd)
                    assert b''.join(chunks)==data, (phase,job['id'],'ordered chunks differ')
                    assert abs(seconds-job['duration_seconds'])<1e-6
                    record['raw_audio_seconds']=seconds
                    output = audio
                    if job['playback_tempo']>1:
                        output = root/'speech/results'/job['playback_audio_filename']
                    op,od,os = collector.read_audio(output)
                    assert op[:3]==params[:3]
                    record['actual_playback_pcm_seconds']=os
                    manifests.append({'phase':phase,'case':row['case']['id'],'raw':str(audio),
                        'raw_sha256':hashlib.sha256(audio.read_bytes()).hexdigest(),
                        'raw_frames':params.nframes,'playback':str(output),
                        'playback_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
                        'playback_frames':op.nframes,'sample_rate':params.framerate})
            records.append(record)
        verify = target/phase
        verify.mkdir()
        (verify/'speech').mkdir()
        (verify/'speech/results').symlink_to((root/'speech/results').resolve(),target_is_directory=True)
        save(verify/'jobs.json',[j for j in status['jobs'] if j['status']=='completed'])
        with (verify/'verify-console.log').open('w') as log:
            code=subprocess.run(['python3',str(ROOT/'verify_tempo_playback.py'),
                '--replay',str(verify),'--output',str(verify/'verification.json')],
                stdout=log,stderr=subprocess.STDOUT).returncode
        save(verify/'verify-exit-code.json',{'exit_code':code})
        # 独立参考失败保留结果，报告阶段按原验收条件判断。
        outcomes[phase]={'result':result,'rows':records,'ffmpeg_verifier_exit_code':code,
            'first_pcm_wait':stats([r['source_final_to_first_pcm_seconds'] for r in records if 'source_final_to_first_pcm_seconds' in r]),
            'queue_wait':stats([r['queue_seconds'] for r in records if r.get('queue_seconds') is not None]),
            'completed_actual_playback_pcm_seconds':sum(r.get('actual_playback_pcm_seconds',0) for r in records)}
        save(target/(phase+'-rows.json'),records)
    common=[i for i in range(len(cases)) if all(outcomes[p]['rows'][i].get('job_status')=='completed' for p in (PHASES[0], PHASES[-1]))]
    paired={'source_cases':len(cases),'completed_both':len(common),'case_ids':[cases[i]['id'] for i in common]}
    for phase in (PHASES[0], PHASES[-1]):
        records=outcomes[phase]['rows']
        paired[phase]={'first_pcm_wait':stats([records[i]['source_final_to_first_pcm_seconds'] for i in common]),
            'generated_seconds':sum(records[i]['raw_audio_seconds'] for i in common),
            'actual_playback_pcm_seconds':sum(records[i]['actual_playback_pcm_seconds'] for i in common)}
    save(target/'audio-manifest.json',manifests)
    save(target/'comparison.json',{'phases':outcomes,'paired_completed':paired})
    print(json.dumps({'paired':paired,'phases':{p:{k:v for k,v in outcomes[p].items() if k!='rows'} for p in PHASES}},ensure_ascii=False))
    if any(outcomes[p]['ffmpeg_verifier_exit_code'] for p in PHASES):
        raise SystemExit(1)


if __name__=='__main__':
    main()
