"""复核已归档的父段时长、候选重叠和首音等待。"""
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import re
import statistics


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
PHASE = 'after-numeric-trace-paced'
OVERLAP_WORDS = 5
TIMING_TOLERANCE_SECONDS = 1e-6
inputs = {}


def read(path):
    data = path.read_bytes()
    inputs[str(path.relative_to(REPO))] = hashlib.sha256(data).hexdigest()
    return data


def summary(values):
    ordered = sorted(values)
    position = (len(ordered)-1)*.95
    low = int(position)
    high = min(low+1, len(ordered)-1)
    return {'count': len(values), 'median': statistics.median(values),
            'p95': ordered[low]+(ordered[high]-ordered[low])*(position-low),
            'maximum': max(values)}


def longest_overlap(left, right):
    a = re.findall(r'[a-z]+', left.casefold())
    b = re.findall(r'[a-z]+', right.casefold())
    best = []
    for i in range(len(a)):
        for j in range(len(b)):
            length = 0
            while i+length < len(a) and j+length < len(b) and a[i+length] == b[j+length]:
                length += 1
            if length > len(best):
                best = a[i:i+length]
    return best


def main():
    comparison = json.loads(read(ROOT/'trace-analysis/comparison.json'))
    rows = comparison['phases'][PHASE]['rows']
    tempo_max = comparison['phases'][PHASE]['result']['playback_tempo_max']
    cases = json.loads(read(ROOT/'trace-cases.json'))
    if [r['id'] for r in rows] != [c['id'] for c in cases] or len({c['id'] for c in cases}) != len(cases):
        raise ValueError('源段标识或顺序与归档输入不一致')
    latest = {}
    for line in read(REPO/'rvc-golden/soak-20261019/full/runtime/subtitles.jsonl').splitlines():
        item = json.loads(line)
        latest[item['utterance_id']] = item
    groups = defaultdict(list)
    for number, row in enumerate(rows, 1):
        groups[row['parent_id']].append((number, row))
    parents, overlaps, pairs = [], [], 0
    boundary_reasons = Counter()
    metrics = defaultdict(list)
    accounting_deltas = []
    for parent_id, group in groups.items():
        original = latest[parent_id]
        original_parts = {p['index']: p for p in original['translation_segments']}
        for _, row in group:
            part = original_parts[row['part_index']]
            if part['source_text'] != row['source_text'] or part['source_duration_seconds'] != row['source_seconds']:
                raise ValueError('父段源文或观测时长映射不一致')
            if part['early']:
                boundary_reasons[part['boundary_classifier']['cut']['reason']] += 1
        source_ns = original['audio_end_pts_ns']-original['audio_start_pts_ns']
        assigned_ns = sum(round(row['source_seconds']*1e9) for _, row in group)
        complete_text = ''.join(row['source_text'] for _, row in group) == original['zh']
        all_completed = all(row.get('job_status') == 'completed' for _, row in group)
        cohort = (original['final'] and source_ns == assigned_ns and complete_text and all_completed
                  and not any(row['source_correction'] for _, row in group))
        parent = {'parent_id': parent_id, 'seq': original['seq'], 'final': original['final'],
                  'case_numbers': [n for n, _ in group], 'complete_text': complete_text,
                  'all_speech_completed': all_completed, 'cohort': cohort,
                  'parent_source_seconds': source_ns/1e9, 'assigned_source_seconds': assigned_ns/1e9,
                  'source_text': original['zh'], 'parts': []}
        for number, row in group:
            parent['parts'].append({key: row.get(key) for key in (
                'id', 'part_index', 'source_text', 'source_seconds', 'translation',
                'translation_status', 'job_status', 'raw_audio_seconds', 'actual_playback_pcm_seconds')}
                | {'case_number': number})
        if all_completed:
            parent['raw_audio_seconds'] = sum(r['raw_audio_seconds'] for _, r in group)
            parent['actual_playback_pcm_seconds'] = sum(r['actual_playback_pcm_seconds'] for _, r in group)
        parents.append(parent)
        for (a_number, a), (b_number, b) in zip(group, group[1:]):
            pairs += 1
            overlap = longest_overlap(a['translation'], b['translation'])
            if len(overlap) >= OVERLAP_WORDS:
                overlaps.append({'parent_id': parent_id, 'cases': [a_number, b_number],
                                 'overlap': ' '.join(overlap), 'previous_source': a['source_text'],
                                 'current_source': b['source_text'],
                                 'previous_translation': a['translation'], 'current_translation': b['translation']})
    for row in rows:
        if row.get('job_status') != 'completed':
            continue
        job = json.loads(read(ROOT/PHASE/'speech/results'/f"{row['job_id']}.json"))
        if job['id'] != row['job_id'] or job['source_text'] != row['source_text']:
            raise ValueError('播报任务与源段映射不一致')
        timestamps = [job[key] for key in ('source_emitted_at', 'created_at', 'started_at',
                                         'audio_ready_at', 'playback_started_at')]
        archived_total = row['source_final_to_first_pcm_seconds']
        if any(type(value) not in (int, float) or not math.isfinite(value)
               for value in timestamps+[archived_total]):
            raise ValueError('播报计时字段必须为有限数值')
        if any(left > right for left, right in zip(timestamps, timestamps[1:])):
            raise ValueError('播报时间戳顺序错误')
        stages = {'source_to_job_seconds': job['created_at']-job['source_emitted_at'],
                  'synthesis_queue_seconds': job['started_at']-job['created_at'],
                  'first_block_seconds': job['audio_ready_at']-job['started_at'],
                  'ready_to_play_seconds': job['playback_started_at']-job['audio_ready_at']}
        total = job['playback_started_at']-job['source_emitted_at']
        difference = abs(total-archived_total)
        if difference > TIMING_TOLERANCE_SECONDS:
            raise ValueError('任务时间戳与归档总等待不一致')
        accounting_deltas.append(difference)
        for key, value in stages.items():
            metrics[key].append(value)
        metrics['total_seconds'].append(total)
        metrics['synthesis_rtf'].append(job['synthesis_seconds']/job['duration_seconds'])
    cohort = [p for p in parents if p['cohort']]
    source = sum(p['parent_source_seconds'] for p in cohort)
    raw = sum(p['raw_audio_seconds'] for p in cohort)
    pcm = sum(p['actual_playback_pcm_seconds'] for p in cohort)
    result = {'phase': PHASE, 'source_segments': len(rows), 'parents': len(parents),
              'final_parents': sum(p['final'] for p in parents),
              'cohort': {'parents': len(cohort), 'segments': sum(len(p['parts']) for p in cohort),
                         'source_seconds': source, 'raw_audio_seconds': raw,
                         'actual_playback_pcm_seconds': pcm, 'raw_source_ratio': raw/source,
                         'playback_source_ratio': pcm/source,
                         'pcm_excess_seconds': pcm-source,
                         'playback_tempo_max': tempo_max,
                         'raw_exceeds_playback_tempo_max_source': sum(p['raw_audio_seconds'] > tempo_max*p['parent_source_seconds'] for p in cohort),
                         'pcm_exceeds_source': sum(p['actual_playback_pcm_seconds'] > p['parent_source_seconds'] for p in cohort)},
              'early_boundary_reasons': dict(boundary_reasons), 'adjacent_pairs': pairs,
              'overlap_screen_words': OVERLAP_WORDS, 'overlap_candidates': overlaps,
              'wait_stages': {key: summary(values) for key, values in metrics.items()},
              'maximum_wait_accounting_delta_seconds': max(accounting_deltas),
              'parent_rows': parents, 'input_sha256': inputs,
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    output = ROOT/'parent-duration-audit.json'
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({key: result[key] for key in (
        'cohort', 'early_boundary_reasons', 'adjacent_pairs', 'overlap_candidates',
        'wait_stages', 'maximum_wait_accounting_delta_seconds')}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
