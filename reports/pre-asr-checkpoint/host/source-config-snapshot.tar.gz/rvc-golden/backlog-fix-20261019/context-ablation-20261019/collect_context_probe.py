"""在板端核对短对照音频，并打包原始记录。"""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import wave


BASE = Path.home()/'mozart-backlog-fix-20261019'
ROOT = BASE/'context-ablation-20261019'
VARIANTS = ('split-history', 'split-isolated', 'joined')


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')


def pcm(path):
    with wave.open(str(path), 'rb') as source:
        channels, width, rate, frames = source.getparams()[:4]
        data = source.readframes(frames)
    if (channels, width) != (1, 2) or not frames or len(data) != frames*channels*width:
        raise ValueError('短对照 WAV 格式错误或 PCM 不完整：'+str(path))
    return data, rate


def main():
    if (ROOT/'controller-exit-code').read_text().strip() != '0':
        raise ValueError('短对照控制器执行失败')
    summaries, paths, verifier_failed = [], set(), False
    for variant in VARIANTS:
        phase = 'context-20261019-'+variant+'-paced'
        folder = BASE/phase
        result = json.loads((folder/'result.json').read_text())
        cases = json.loads((ROOT/(variant+'.json')).read_text())
        rows = json.loads((folder/'rows.json').read_text())
        status = json.loads((folder/'status.json').read_text())
        if not result['execution_complete'] or status['unfinished_jobs'] or [r['case'] for r in rows] != cases:
            raise ValueError('短对照源分母或排空状态不一致：'+variant)
        jobs = {job['id']: job for job in status['jobs']}
        records = []
        for number, row in enumerate(rows, 1):
            update = row['updates'][-1]
            record = {'case': row['case'], 'translation_status': update['translation_status'],
                      'translation': update['en'], 'translation_error': update.get('translation_error'),
                      'translation_audit': update.get('translation_audit')}
            if update.get('speech'):
                job = jobs[update['speech']]
                if job['utterance_id'] != f'{phase}:{number}' or job['source_text'] != row['case']['source_text']:
                    raise ValueError('短对照任务映射错误：'+variant)
                record.update(job_status=job['status'], job_error=job.get('error'), job_id=job['id'])
                if job['status'] == 'completed':
                    data, rate = pcm(folder/'speech/results'/f"{job['id']}.wav")
                    chunks = []
                    for index, chunk in enumerate(job['chunks']):
                        if chunk['index'] != index:
                            raise ValueError('短对照音频块序号错误')
                        chunk_data, chunk_rate = pcm(folder/'speech/results'/chunk['filename'])
                        if rate != chunk_rate:
                            raise ValueError('短对照音频块采样率错误')
                        chunks.append(chunk_data)
                    if b''.join(chunks) != data:
                        raise ValueError('短对照音频块与完整输出不同')
                    playback = folder/'speech/results'/job['playback_audio_filename'] if job.get('playback_audio_filename') else folder/'speech/results'/f"{job['id']}.wav"
                    played, played_rate = pcm(playback)
                    if rate != played_rate:
                        raise ValueError('短对照播放采样率错误')
                    record.update(raw_seconds=len(data)/2/rate, playback_seconds=len(played)/2/rate,
                                  playback_tempo=job['playback_tempo'])
            records.append(record)
        verification = ROOT/('verify-'+variant)
        verification.mkdir(exist_ok=False)
        (verification/'speech').mkdir()
        (verification/'speech/results').symlink_to(folder/'speech/results', target_is_directory=True)
        completed = [job for job in jobs.values() if job['status'] == 'completed']
        save(verification/'jobs.json', completed)
        with (verification/'console.log').open('w') as log:
            code = subprocess.run([sys.executable, str(BASE/'verify_tempo_playback.py'),
                                   '--replay', str(verification), '--output', str(verification/'verification.json')],
                                  stdout=log, stderr=subprocess.STDOUT).returncode
        save(verification/'exit-code.json', {'exit_code': code})
        verifier_failed = verifier_failed or bool(code)
        summaries.append({'variant': variant, 'phase': phase, 'result': result, 'rows': records,
                          'ffmpeg_verifier_exit_code': code,
                          'raw_seconds': sum(r.get('raw_seconds', 0) for r in records),
                          'playback_seconds': sum(r.get('playback_seconds', 0) for r in records)})
        paths.update(p for p in folder.rglob('*') if p.is_file() and p.parent.name != 'voices')
        for prefix, suffix in [('translator-', '.log'), ('cleanup-', '.json')]:
            paths.add(BASE/(prefix+phase+suffix))
    save(ROOT/'summary.json', summaries)
    paths.update(p for p in ROOT.rglob('*') if p.is_file() and not p.is_symlink()
                 and 'speech' not in p.relative_to(ROOT).parts and p.name != 'archive-sha256.json')
    save(ROOT/'archive-sha256.json', {str(p.relative_to(BASE)): hashlib.sha256(p.read_bytes()).hexdigest()
                                    for p in sorted(paths)})
    paths.add(ROOT/'archive-sha256.json')
    with tarfile.open(BASE/'context-ablation-20261019.tar.gz', 'x:gz') as archive:
        for path in sorted(paths):
            archive.add(path, arcname=str(path.relative_to(BASE)), recursive=False)
    print(json.dumps([{k: v for k, v in s.items() if k != 'rows'} for s in summaries], indent=2))
    if verifier_failed:
        raise ValueError('独立 FFmpeg 核验失败，原始记录已打包')


if __name__ == '__main__':
    main()
