#!/usr/bin/env bash
set -u
cd /home/moyamryia/mozart-backlog-fix-20261019
probe_code=0
for variant in split-history split-isolated joined; do
    /home/moyamryia/Mozart/.venv/bin/python trace_probe_numeric.py --base /home/moyamryia/mozart-backlog-fix-20261019 --repo /home/moyamryia/mozart-backlog-fix-20261019/candidate-numeric --cases "/home/moyamryia/mozart-backlog-fix-20261019/context-ablation-20261019/${variant}.json" --only-after --after-name "context-20261019-${variant}" --paced > "context-ablation-20261019/${variant}.log" 2>&1
    probe_code=$?
    printf '%s\n' "$probe_code" > "context-ablation-20261019/${variant}-exit-code"
    if [ "$probe_code" -ne 0 ]; then
        break
    fi
done
printf '%s\n' "$probe_code" > context-ablation-20261019/controller-exit-code
exit "$probe_code"
