"""在隔离目录对照原版和修复版翻译及实际早期播报链路。"""
import argparse
import fcntl
from http.server import ThreadingHTTPServer
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
import urllib.request


def save(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
    temp.replace(path)


def worker(args):
    sys.path.insert(0, str(args.repo/'tools'))
    from subtitle_bridge import caption_updates
    from speech_service import SpeechService, handler_for, TERMINAL
    root = args.output
    root.mkdir(exist_ok=False)
    voices = Path.home()/'mozart-full-soak-20261019/full/service-data/voices'
    shutil.copytree(voices, root/'speech/voices')
    model = Path.home()/'models/sherpa-onnx/clone-test-downloads/sherpa-onnx-pocket-tts-int8-2026-01-26'
    command = [sys.executable, str(args.repo/'tools/clone_worker.py'), '--engine', 'pocket',
        '--model', str(model), '--threads', '2', '--early-audio', '--audio-chunk-frames', '3']
    service = SpeechService(root/'speech', command, playback_device='null',
        preload=True, delivery_policy='coverage', playback_tempo='normal')
    server = None
    rows, samples = [], []
    began = time.monotonic()
    def snapshot():
        status = service.status()
        samples.append({'elapsed_seconds': time.monotonic()-began,
            'backlog_seconds': status['audio_backlog_seconds'], 'pending_jobs': status['pending_jobs']})
        return status
    try:
        deadline = time.monotonic()+90
        while service.runtime is None:
            if service.warmup_error:
                raise RuntimeError(service.warmup_error)
            if time.monotonic() >= deadline:
                raise TimeoutError('Speech warmup timed out')
            time.sleep(.1)
        voice_id = next(iter(service.voices))
        service.route('POST', '/api/speech/session', {'enabled': True, 'voice_id': voice_id, 'playback': True})
        server = ThreadingHTTPServer(('127.0.0.1', 18581), handler_for(service))
        threading.Thread(target=server.serve_forever, daemon=True).start()
        for index, case in enumerate(json.loads(args.cases.read_text())):
            event = {'seq': index+1, 'text': case['source_text'],
                'source_duration_seconds': case['source_seconds'], 'emitted_at': time.time()}
            updates = list(caption_updates(event, index+1, root.name, args.url, 'http://127.0.0.1:18581'))
            rows.append({'case': case, 'updates': updates})
            save(root/'rows.json', rows)
            snapshot()
        deadline = time.monotonic()+600
        while any(j['status'] not in TERMINAL for j in snapshot()['jobs']):
            if time.monotonic() >= deadline:
                raise TimeoutError('Speech drain timed out')
            time.sleep(.25)
        status = snapshot()
        save(root/'status.json', status)
        save(root/'telemetry.json', samples)
        save(root/'result.json', {'execution_complete': True, 'strict_acceptance_passed': False,
            'source_cases': len(rows), 'translation_completed': sum(r['updates'][-1]['translation_status']=='completed' for r in rows),
            'speech_jobs': len(status['jobs']), 'completed_jobs': sum(j['status']=='completed' for j in status['jobs']),
            'failed_jobs': sum(j['status']=='failed' for j in status['jobs']),
            'generated_seconds': sum(j.get('duration_seconds',0) for j in status['jobs']),
            'played_seconds': sum(j.get('played_duration_seconds',0) for j in status['jobs']),
            'maximum_backlog_seconds': max(s['backlog_seconds'] for s in samples),
            'elapsed_seconds': time.monotonic()-began, 'playback_tempo': 'normal',
            'input_schedule': 'Seven saved source windows submitted as translation completes; not a paced source replay.'})
    finally:
        if server is not None:
            server.shutdown()
            server.server_close()
        service.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', type=Path)
    parser.add_argument('--repo', type=Path)
    parser.add_argument('--cases', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--url', default='http://127.0.0.1:18200')
    parser.add_argument('--worker', action='store_true')
    args = parser.parse_args()
    if args.worker:
        worker(args)
        return
    base, home = args.base.resolve(), Path.home()
    sys.path.insert(0, str(base/'candidate/tools'))
    from run_translated_speech import assert_ports_available
    assert_ports_available([(18200, socket.SOCK_STREAM), (18581, socket.SOCK_STREAM)])
    lock = (home/'Mozart/rvc-golden/reliability-20261006/active-test.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    binary = home/'mozart-archive/qwen35/llama.cpp/build-cuda-bin/llama-server'
    env = dict(os.environ, LD_LIBRARY_PATH=str(binary.parent)+':'+os.environ.get('LD_LIBRARY_PATH', ''),
        PYTHONPATH=str(home/'mozart-realtime-patches-20261008/early-audio-runtime-20261009/python'))
    log = (base/'translator.log').open('w')
    translator = subprocess.Popen([str(binary), '-m', str(home/'mozart-archive/qwen35/gguf/qwen35-0.8b-text-Q4_K_M.gguf'),
        '-c','2048','-b','256','-ub','128','--cache-ram','128','-ngl','99','-np','1','-t','2','-tb','2',
        '--host','127.0.0.1','--port','18200','--jinja'], stdout=log, stderr=subprocess.STDOUT, env=env)
    try:
        deadline = time.monotonic()+90
        while True:
            if translator.poll() is not None:
                raise RuntimeError('Translator startup failed')
            try:
                with urllib.request.urlopen(args.url+'/health', timeout=3):
                    break
            except OSError:
                if time.monotonic() >= deadline:
                    raise TimeoutError('Translator warmup timed out')
                time.sleep(.2)
        for name, repo in [('before', home/'mozart-efficiency-20261014/candidate'), ('after', base/'candidate')]:
            print('Starting '+name, flush=True)
            helper = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), '--worker', '--repo', str(repo),
                '--cases', str(args.cases.resolve()), '--output', str(base/name), '--url', args.url],
                env=env, start_new_session=True)
            try:
                code = helper.wait(timeout=750)
            finally:
                if helper.poll() is None:
                    os.killpg(helper.pid, signal.SIGTERM)
                    try:
                        helper.wait(timeout=20)
                    except subprocess.TimeoutExpired:
                        os.killpg(helper.pid, signal.SIGKILL)
                        helper.wait()
            if code:
                raise subprocess.CalledProcessError(code, helper.args)
            print('Finished '+name, flush=True)
    finally:
        translator.terminate()
        try:
            translator.wait(timeout=20)
        except subprocess.TimeoutExpired:
            translator.kill()
            translator.wait()
        log.close()


if __name__ == '__main__':
    main()
