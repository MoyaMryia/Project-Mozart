#!/usr/bin/env bash
set -u
cd /home/moyamryia/mozart-backlog-fix-20261019
while [ ! -f numeric-controller-exit-code ]; do
    sleep 5
done
numeric_code=$(cat numeric-controller-exit-code)
if [ "$numeric_code" -ne 0 ]; then
    printf 'Numeric replay failed with exit %s\n' "$numeric_code" > trace-analysis-console.log
    exit "$numeric_code"
fi
/home/moyamryia/Mozart/.venv/bin/python analyze_trace.py > trace-analysis-console.log 2>&1
analysis_code=$?
printf '%s\n' "$analysis_code" > trace-analysis-exit-code
tar -czf candidate-numeric-tools.tar.gz -C candidate-numeric tools
/home/moyamryia/Mozart/.venv/bin/python package_trace.py > trace-package.log 2>&1
package_code=$?
printf '%s\n' "$package_code" > trace-package-exit-code
if [ "$analysis_code" -ne 0 ]; then
    exit "$analysis_code"
fi
exit "$package_code"
