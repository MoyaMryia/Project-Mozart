"""归档字幕时序重放证据并生成实际播放音频试听。"""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import tarfile
import wave

ROOT=Path('/home/moyamryia/mozart-backlog-fix-20261019')
PHASES=['before-trace-v2-paced','after-trace-v2-paced', 'after-numeric-trace-paced']


def main():
    spec=importlib.util.spec_from_file_location('collector',ROOT/'collect-reviewed.py')
    collector=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(collector)
    output=ROOT/'trace-previews'
    output.mkdir(exist_ok=False)
    manifest=[]
    for phase in PHASES:
        root=ROOT/phase
        jobs=json.loads((root/'status.json').read_text())['jobs']
        jobs=sorted(jobs,key=lambda j:int(j['utterance_id'].rsplit(':',1)[1]))
        merged=output/(phase+'-completed.wav')
        count=0
        with wave.open(str(merged),'wb') as stream:
            for job in jobs:
                if job['status']!='completed':
                    continue
                name=job.get('playback_audio_filename',job['id']+'.wav')
                path=root/'speech/results'/name
                params,data,seconds=collector.read_audio(path)
                if count==0:
                    stream.setparams(params)
                else:
                    assert params[:3]==(stream.getnchannels(),stream.getsampwidth(),stream.getframerate())
                stream.writeframes(data)
                count+=1
                manifest.append({'phase':phase,'utterance_id':job['utterance_id'],
                    'source_text':job['source_text'],'translation':job['text'],
                    'job_status':job['status'],'seconds':seconds,'tempo':job.get('playback_tempo'),
                    'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
        subprocess.run(['ffmpeg','-v','error','-n','-i',str(merged),'-c:a','libmp3lame','-b:a','96k',str(merged.with_suffix('.mp3'))],check=True)
        merged.unlink()
        for job in jobs:
            if '马就你记马最几分七四往代最大的麻醉剂' != job['source_text']:
                continue
            path=root/'speech/results'/(job['id']+'-playback.wav')
            if not path.exists():
                path=root/'speech/results'/(job['id']+'.wav')
            params,data,seconds=collector.read_audio(path)
            subprocess.run(['ffmpeg','-v','error','-n','-i',str(path),'-c:a','libmp3lame','-b:a','96k',str(output/(phase+'-pinyin.mp3'))],check=True)
    (ROOT/'trace-analysis/merged-manifest.json').write_text(json.dumps({'policy':'Concatenate completed jobs in source order; use captured filtered PCM when tempo > 1; omit original gaps and failed or rejected audio.','rows':manifest},ensure_ascii=False,indent=2)+'\n')
    wave_hashes=[]
    for phase in PHASES+['before-trace-paced']:
        for path in (ROOT/phase/'speech/results').glob('*.wav'):
            wave_hashes.append({'phase':phase,'path':str(path),
                'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    (ROOT/'trace-analysis/raw-wave-hashes.json').write_text(json.dumps(wave_hashes,indent=2)+'\n')
    included=[]
    for directory in PHASES+['before-trace-paced','trace-analysis','trace-previews']:
        for path in (ROOT/directory).rglob('*'):
            if path.is_file() and path.suffix in ['.json','.jsonl','.log','.mp3']:
                included.append(path)
    names=['trace-cases.json','trace_probe.py','trace-probe-fixture-v1.py','launch_trace.sh',
        'analyze_trace.py','collect-reviewed.py','package_trace.py','verify_tempo_playback.py',
        'pcm-byte-audit.json','short-utterance-boundary-audit.json',
        'trace-fixture-history-error.json','cleanup-trace-comparison-paced.json',
        'cleanup-trace-comparison-v2-paced.json','console-trace-paced.log','console-trace-v2-paced.log',
        'trace-controller-exit-code','trace-analysis-exit-code','trace_probe_numeric.py',
        'launch_numeric.sh','numeric-controller-exit-code','console-numeric-trace.log',
        'python-regression-numeric.log','python-regression-numeric-reviewed.log','cleanup-after-numeric-trace-paced.json',
        'translator-after-numeric-trace-paced.log','source-pinyin-context.mp3',
        'candidate-numeric-tools.tar.gz','trace-analysis-console.log']
    included += [ROOT/name for name in names]
    hashes=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in included]
    hash_path=ROOT/'trace-evidence-hashes.json'
    hash_path.write_text(json.dumps(hashes,indent=2)+'\n')
    with tarfile.open(ROOT/'trace-small-records.tar.gz','w:gz') as archive:
        for path in included+[hash_path]:
            archive.add(path,arcname=str(path.relative_to(ROOT)))
    print('Archived',len(included),'evidence files')


if __name__=='__main__':
    main()
