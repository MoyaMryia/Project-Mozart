"""在隔离目录对照原版和修复版翻译及实际早期播报链路。"""
import argparse
import fcntl
import hashlib
from http.server import ThreadingHTTPServer
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
import urllib.request

SAMPLE_INTERVAL = .25


def save(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
    temp.replace(path)


def group_members(pgid):
    rows = subprocess.check_output(['ps', '-eo', 'pid=,pgid=,stat='], text=True).splitlines()
    return [int(fields[0]) for line in rows if (fields := line.split())
            and int(fields[1]) == pgid and not fields[2].startswith('Z')]


def close_group(process):
    before = group_members(process.pid)
    if before:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    deadline = time.monotonic()+3
    while group_members(process.pid) and time.monotonic() < deadline:
        time.sleep(.1)
    forced = bool(group_members(process.pid))
    if forced:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    process.wait(timeout=20)
    deadline = time.monotonic()+3
    while group_members(process.pid) and time.monotonic() < deadline:
        time.sleep(.1)
    remaining = group_members(process.pid)
    if remaining:
        raise RuntimeError('Owned process group remains: '+str(remaining))
    return {'pgid': process.pid, 'members_before_cleanup': before, 'forced_kill': forced, 'remaining': remaining}


def worker(args):
    sys.path.insert(0, str(args.repo/'tools'))
    from subtitle_bridge import caption_updates
    from speech_service import SpeechService, handler_for, TERMINAL
    root = args.output
    cases = json.loads(args.cases.read_text())
    root.mkdir(exist_ok=False)
    voices = Path.home()/'mozart-full-soak-20261019/full/service-data/voices'
    shutil.copytree(voices, root/'speech/voices')
    model = Path.home()/'models/sherpa-onnx/clone-test-downloads/sherpa-onnx-pocket-tts-int8-2026-01-26'
    command = [sys.executable, str(args.repo/'tools/clone_worker.py'), '--engine', 'pocket',
        '--model', str(model), '--threads', '2', '--early-audio', '--audio-chunk-frames', '3']
    service = SpeechService(root/'speech', command, playback_device='null',
        preload=True, delivery_policy='coverage', playback_tempo='flexible', capture_playback=True)
    server = None
    rows, samples = [], []
    complete = False
    sampler_stop = threading.Event()
    sampler = None
    began = time.monotonic()
    def snapshot():
        with service.lock:
            samples.append({'elapsed_seconds': time.monotonic()-began,
                'backlog_seconds': service.audio_backlog_seconds(), 'pending_jobs': len(service.pending)})
    def sample_loop():
        while not sampler_stop.is_set():
            snapshot()
            sampler_stop.wait(SAMPLE_INTERVAL)
    try:
        deadline = time.monotonic()+90
        while service.runtime is None:
            if service.warmup_error:
                raise RuntimeError(service.warmup_error)
            if time.monotonic() >= deadline:
                raise TimeoutError('Speech warmup timed out')
            time.sleep(.1)
        voice_id = next(iter(service.voices))
        service.route('POST', '/api/speech/session', {'enabled': True, 'voice_id': voice_id, 'playback': True})
        server = ThreadingHTTPServer(('127.0.0.1', 18581), handler_for(service))
        threading.Thread(target=server.serve_forever, daemon=True).start()
        save(root/'protocol.json', {'repo': str(args.repo), 'runtime': service.runtime,
            'cases_sha256': hashlib.sha256(args.cases.read_bytes()).hexdigest(),
            'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'source_sha256': {name: hashlib.sha256((args.repo/'tools'/name).read_bytes()).hexdigest()
                for name in ['subtitle_bridge.py','translation_checks.py','speech_service.py','clone_worker.py','speech_chunks.py','speech_duration.py','tempo_control.py']},
            'voice_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'speech/voices').iterdir()}})
        sampler = threading.Thread(target=sample_loop, daemon=True)
        sampler.start()
        source_position = 0.0
        history = {}
        input_start, input_wall = time.monotonic(), time.time()
        for index, case in enumerate(cases):
            source_position = case['arrival_offset_seconds']
            if args.paced:
                while time.monotonic() < input_start+source_position:
                    time.sleep(min(.1, max(0, input_start+source_position-time.monotonic())))
            event = {'seq': index+1, 'text': case['source_text'],
                'source_duration_seconds': case['source_seconds'],
                'emitted_at': input_wall+source_position if args.paced else time.time(),
                'source_correction': case['source_correction'],
                'translation_context': history.get(case['parent_id'], [])[-2:],
                **case['asr_audits']}
            updates = list(caption_updates(event, index+1, root.name, args.url, 'http://127.0.0.1:18581'))
            if updates[-1]['translation_status'] == 'completed':
                history.setdefault(case['parent_id'], []).append({
                    'source': case['source_text'][:256], 'translation': updates[-1]['en'][:512]})
            rows.append({'case': case, 'updates': updates})
            save(root/'rows.json', rows)
            snapshot()
        deadline = time.monotonic()+600
        while any(j['status'] not in TERMINAL for j in service.status()['jobs']):
            if time.monotonic() >= deadline:
                raise TimeoutError('Speech drain timed out')
            time.sleep(SAMPLE_INTERVAL)
        complete = True
    finally:
        if sampler is not None:
            sampler_stop.set()
            sampler.join(timeout=5)
        try:
            snapshot()
            status = service.status()
            save(root/'rows.json', rows)
            save(root/'status.json', status)
            save(root/'telemetry.json', samples)
            save(root/'result.json', {'execution_complete': complete, 'strict_acceptance_passed': False,
                'failure': str(sys.exc_info()[1]) if sys.exc_info()[1] else None,
                'source_cases': len(cases), 'processed_cases': len(rows),
                'translation_completed': sum(r['updates'][-1]['translation_status']=='completed' for r in rows),
                'speech_jobs': len(status['jobs']), 'completed_jobs': sum(j['status']=='completed' for j in status['jobs']),
                'failed_jobs': sum(j['status']=='failed' for j in status['jobs']),
                'generated_seconds': sum(j.get('duration_seconds',0) for j in status['jobs']),
                'played_seconds': sum(j.get('played_duration_seconds',0) for j in status['jobs']),
                'maximum_backlog_seconds': max(s['backlog_seconds'] for s in samples),
                'backlog_metric': 'Maximum sampled observation; fixed sampler interval '+str(SAMPLE_INTERVAL)+' seconds.',
                'elapsed_seconds': time.monotonic()-began, 'playback_tempo': 'flexible', 'playback_tempo_max': 1.15,
                'input_schedule': 'Original streaming segment arrival offsets; within-parent accepted translation context.' if args.paced else 'Burst submission.',
                'source_seconds_total': sum(c['source_seconds'] or 0 for c in cases),
                'input_span_seconds': cases[-1]['arrival_offset_seconds']})
        finally:
            if server is not None:
                server.shutdown()
                server.server_close()
            service.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', type=Path)
    parser.add_argument('--repo', type=Path)
    parser.add_argument('--cases', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--url', default='http://127.0.0.1:18200')
    parser.add_argument('--worker', action='store_true')
    parser.add_argument('--only-after', action='store_true')
    parser.add_argument('--after-name', default='after-v2')
    parser.add_argument('--paced', action='store_true')
    args = parser.parse_args()
    if args.worker:
        worker(args)
        return
    base, home = args.base.resolve(), Path.home()
    sys.path.insert(0, str(base/'candidate/tools'))
    from run_translated_speech import assert_ports_available
    assert_ports_available([(18200, socket.SOCK_STREAM), (18581, socket.SOCK_STREAM)])
    lock = (home/'Mozart/rvc-golden/reliability-20261006/active-test.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    binary = home/'mozart-archive/qwen35/llama.cpp/build-cuda-bin/llama-server'
    env = dict(os.environ, LD_LIBRARY_PATH=str(binary.parent)+':'+os.environ.get('LD_LIBRARY_PATH', ''),
        PYTHONPATH=str(home/'mozart-realtime-patches-20261008/early-audio-runtime-20261009/python'))
    run_name = args.after_name if args.only_after else 'trace-comparison'
    if args.paced:
        run_name += '-paced'
    log = (base/('translator-'+run_name+'.log')).open('x')
    translator = subprocess.Popen([str(binary), '-m', str(home/'mozart-archive/qwen35/gguf/qwen35-0.8b-text-Q4_K_M.gguf'),
        '-c','2048','-b','256','-ub','128','--cache-ram','128','-ngl','99','-np','1','-t','2','-tb','2',
        '--host','127.0.0.1','--port','18200','--jinja'], stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
    cleanup = []
    try:
        deadline = time.monotonic()+90
        while True:
            if translator.poll() is not None:
                raise RuntimeError('Translator startup failed')
            try:
                with urllib.request.urlopen(args.url+'/health', timeout=3):
                    break
            except OSError:
                if time.monotonic() >= deadline:
                    raise TimeoutError('Translator warmup timed out')
                time.sleep(.2)
        variants = [(args.after_name, base/'candidate')] if args.only_after else [
            ('before-trace', home/'mozart-efficiency-20261014/candidate'), ('after-trace', base/'candidate')]
        for name, repo in variants:
            if args.paced:
                name += '-paced'
            print('Starting '+name, flush=True)
            helper_command = [sys.executable, str(Path(__file__).resolve()), '--worker', '--repo', str(repo),
                '--cases', str(args.cases.resolve()), '--output', str(base/name), '--url', args.url]
            if args.paced:
                helper_command.append('--paced')
            helper = subprocess.Popen(helper_command,
                env=env, start_new_session=True)
            try:
                code = helper.wait(timeout=750)
            finally:
                cleanup.append(close_group(helper))
            if code:
                raise subprocess.CalledProcessError(code, helper.args)
            print('Finished '+name, flush=True)
    finally:
        cleanup.append(close_group(translator))
        save(base/('cleanup-'+run_name+'.json'), cleanup)
        log.close()


if __name__ == '__main__':
    main()
