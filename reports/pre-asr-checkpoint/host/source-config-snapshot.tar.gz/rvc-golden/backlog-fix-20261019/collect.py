"""收集固定节奏对照的原始记录、时长、等待与试听。"""
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import tarfile
import wave

ROOT = Path('/home/moyamryia/mozart-backlog-fix-20261019')

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')

def summary(values):
    return {'count': len(values), 'median': statistics.median(values), 'max': max(values)} if values else {'count': 0}


def main():
    import sys
    sys.path.insert(0, str(ROOT/'candidate/tools'))
    from translation_checks import repeated_source_terms
    replay = []
    for row in json.loads((ROOT/'after-final-paced/rows.json').read_text()):
        for a in row['updates'][-1].get('translation_audit', []):
            issues = repeated_source_terms(row['case']['source_text'], a['content'])
            assert issues == a.get('repeated_source_terms', []), (row['case']['id'], issues)
        replay.append({'case': row['case']['id'], 'guard_results_unchanged': True})
    save(ROOT/'reviewed-guard-replay.json', {'sha256': hashlib.sha256((ROOT/'candidate/tools/translation_checks.py').read_bytes()).hexdigest(), 'rows': replay})
    save(ROOT/'reviewed-guard-replay-first-error.json', {'error': "AssertionError: ('before-paced', 'static-108', [{'term': 'PF', 'source_count': 4, 'longest_run': 46}])", 'cause': 'The original baseline has no term-loop guard. Comparing its audit with the new guard was an incorrect fixture assertion.', 'resolution': 'Compare the measured candidate audits only; retain baseline findings separately.'})
    preview = ROOT/'previews'
    preview.mkdir(exist_ok=False)
    derived = {}
    manifest = []
    cases = json.loads((ROOT/'cases.json').read_text())
    for phase in ['before-paced', 'after-final-paced']:
        root = ROOT/phase
        rows = json.loads((root/'rows.json').read_text())
        status = json.loads((root/'status.json').read_text())
        jobs = {int(j['utterance_id'].rsplit(':',1)[1])-1: j for j in status['jobs']}
        outrows = []
        complete_audio = []
        for i, row in enumerate(rows):
            case, u = row['case'], row['updates'][-1]
            job = jobs.get(i)
            out = {**case, 'translation_status': u['translation_status'], 'translation': u['en'], 'translation_error': u.get('translation_error'), 'speech_skipped_reason': u.get('speech_skipped_reason'), 'speech_request_error': u.get('speech_error')}
            if job:
                out.update(job_id=job['id'], job_status=job['status'], job_error=job.get('error'), generated_seconds=job.get('duration_seconds',0), played_seconds=job.get('played_duration_seconds',0), queue_seconds=job.get('queue_seconds'), first_callback_seconds=job.get('first_callback_seconds'))
                if 'playback_started_at' in job:
                    out['source_final_to_first_pcm_seconds'] = job['playback_started_at']-job['source_emitted_at']
                if job['status']=='completed':
                    path = root/'speech/results'/f"{job['id']}.wav"
                    with wave.open(str(path),'rb') as audio:
                        data = audio.readframes(audio.getnframes())
                        params = audio.getparams()
                        seconds = audio.getnframes()/audio.getframerate()
                    assert abs(seconds-job['duration_seconds'])<1e-6
                    complete_audio.append((path, params, data, case['id']))
                    manifest.append({'phase':phase,'case':case['id'],'path':str(path),'seconds':seconds,'channels':params.nchannels,'sample_rate':params.framerate,'sample_width':params.sampwidth,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
                    if case['id'] in ['static-36','static-108','failed-pinyin']:
                        subprocess.run(['ffmpeg','-v','error','-n','-i',str(path),'-c:a','libmp3lame','-b:a','96k',str(preview/f"{phase}-{case['id']}.mp3")],check=True)
            outrows.append(out)
        joined = preview/f'{phase}-completed.wav'
        with wave.open(str(joined),'wb') as output:
            output.setparams(complete_audio[0][1])
            for path, params, data, case_id in complete_audio:
                assert params[:3] == complete_audio[0][1][:3]
                output.writeframes(data)
        subprocess.run(['ffmpeg','-v','error','-n','-i',str(joined),'-c:a','libmp3lame','-b:a','96k',str(joined.with_suffix('.mp3'))],check=True)
        joined.unlink()
        derived[phase] = {'rows':outrows,'source_final_to_first_pcm_seconds':summary([r['source_final_to_first_pcm_seconds'] for r in outrows if 'source_final_to_first_pcm_seconds' in r]),'queue_seconds':summary([r['queue_seconds'] for r in outrows if r.get('queue_seconds') is not None]),'first_callback_seconds':summary([r['first_callback_seconds'] for r in outrows if r.get('first_callback_seconds') is not None]),'merged_cases':[a[3] for a in complete_audio], 'merge_policy':'Concatenate completed job WAVs in source case order; omit source gaps and failed or rejected audio.'}
    common = [i for i in range(len(cases)) if all(derived[p]['rows'][i].get('job_status')=='completed' for p in derived)]
    paired = {'cases':[cases[i]['id'] for i in common]}
    for phase in derived:
        rows = derived[phase]['rows']
        paired[phase] = {'generated_seconds':sum(rows[i]['generated_seconds'] for i in common),'source_seconds':sum(cases[i]['source_seconds'] for i in common),'source_final_to_first_pcm_seconds':summary([rows[i]['source_final_to_first_pcm_seconds'] for i in common])}
    save(ROOT/'comparison.json', {'phases':derived,'common_completed':paired})
    save(ROOT/'audio-manifest.json',manifest)
    included = []
    for path in ROOT.rglob('*'):
        if not path.is_file(): continue
        rel = path.relative_to(ROOT)
        if rel.parts[0]=='candidate' or '__pycache__' in rel.parts: continue
        if path.suffix in ['.json','.jsonl','.log','.py','.mp3'] or (path.name.startswith('candidate-') and path.suffix=='.gz'):
            included.append(path)
    save(ROOT/'evidence-hashes.json',[{'path':str(p.relative_to(ROOT)), 'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in included])
    with tarfile.open(ROOT/'small-records-final.tar.gz','w:gz') as archive:
        for path in included+[ROOT/'evidence-hashes.json']:
            archive.add(path,arcname=str(path.relative_to(ROOT)))
    print(json.dumps({'paired':paired,'phase_wait':{p:derived[p]['source_final_to_first_pcm_seconds'] for p in derived}},ensure_ascii=False))

if __name__=='__main__':
    main()
