# 2026-10-19 积压修复状态

## 最新优先级：十一月初现场演示

用户在完整交付审核后明确：近期准备有吸引力的 demo，并利用剩余时间打磨已有功能的关键细节。
用户认为时间允许较完整的收尾；不要将任务缩为只保住固定两分钟流程。
形式为现场演示，暂定十一月初，具体日期未知。
最新计划：reports/product-readiness-20261019/DEMO.md。
完整审核：reports/product-readiness-20261019/RESULTS.md，共 16 组问题及 5 个本机探针。
下一次“继续”按审核全部 16 组问题推进收尾，优先物理出声与就绪、无声故障和客户端重连。
随后处理内容和积压、英文播报实时变声、完整界面操作、任务与存储、部署和联合测试；演示前预留 2–3 天冻结和彩排。
原积压修复和全部失败证据继续保留。不要重复启动旧负载。
本轮审核没有修改生产代码，也没有启动新 Jetson 负载。
用户设置的 mozart-2 单次四点“继续”任务保持有效。

用户最新授权为处理积压。源术语 PF 保持原样。
当前修改为失败译文停止入队、源术语超量连续循环检查、源文特定词义提示及收窄请求异常捕获。
没有修改生产默认播放速度、音频验收、RVC 路由或旧长测证据。

板端隔离目录：`/home/moyamryia/mozart-backlog-fix-20261019`。
连接：`ssh jetson-wg`。
实际运行和进程组清理均已结束，无常驻负载。

最终对照为 `before-paced` 与 `after-final-paced`，各 7 个源窗口，共 112.280 s。
原版 7 个入队、6 个完成、1 个失败；修复版 6 个入队且全部完成，1 个译文残留中文而保留字幕、不入队。
采样峰值 24.545 s → 25.566 s，相同 5 个完成任务的首 PCM 等待中位数 2.218 s → 2.923 s。
整体积压没有改善。语义错误例子见最终报告，不把执行完成称为严格通过。

各个实验目录及代码快照保持原样。时长压缩和较多全局提示曾导致语义遗漏或额外内容，已撤回。
最终实测后修复型号数字打断循环的误拒；重放最终 7 段候选审计结果相同。
`protocol.json` 保存实际执行代码哈希；`reviewed-guard-replay.json` 保存最后检查模块哈希。
最终源码及测试哈希保存在 `final-source-hashes.json`。

板端最终完整 Python 回归 223/223 通过，日志 `python-regression-reviewed.log`。
本机桥接29项、术语20项通过；完整回归遇到本机缺少 libavfilter.so.11，板端已完成同阶段。
证据归档141文件已逐一核对哈希，原始WAV保留板端，试听副本保存在 previews。
传输提前解包、初始缺模块及第一次审计重放断言错误均单独保留。

报告：`reports/backlog-fix-20261019/RESULTS.md`。
不提交、推送或合并。旧心跳 mozart 已暂停；本轮没有新增自动监控。

## 用户要求继续后的流式字幕时序对照

用户再次说“继续处理”，任务仍在进行。不要把前述7段报告当作本轮最后答复。
当前新负载 tmux `mozart_backlog_trace_20261019`，脚本 `launch_trace.sh`。
串行执行 `before-trace-v2-paced` 和 `after-trace-v2-paced`。
输入 `trace-cases.json` 包含原组合长测175个唯一分段；到达跨度534.403520107s；源观测区间合计537.060s。
保留源文/时长/PF/原始到达节奏及父段最近2个通过的翻译上下文。
本轮使用实际翻译与早期TTS，flexible最高1.15，capture_playback=true；不重做ASR或加入RVC负载。
预计两轮合计20分钟。正常运行不要重复启动或中断。

第1版夹具默认历史128会造成漏计，已在第26段时SIGINT自有helper，保存现场并清理，无任务prune丢失。
证据目录 `before-trace-paced`，错误说明 `trace-fixture-history-error.json`，旧脚本冻结 `trace-probe-fixture-v1.py`。
第2版夹具history_limit=len(cases)=175，排空依靠unfinished_jobs。
预热90秒、输入跨度、排空600秒及收尾30秒统一计算helper外层预算。
result.played_source_audio_seconds是原始片段时长计数，实际变速播放长度要另读capture WAV，禁止混称。

已审核固定7段的902个WAV实际PCM字节数，全部匹配；构造少2字节WAV正确拒绝。
审核脚本 `collect-reviewed.py`，证据 `pcm-byte-audit.json`。
旧collect.py及141文件保持原hash，不改历史执行版本。
原完整流式的160完成任务中156已达1.15；现存122音频边界能量审计没有足够尾静音来解释几十秒积压。
这些新证据目前还在板端，收尾时同步。

下一步：等待两轮退出，读trace-controller-exit-code、各result/status/rows/telemetry/protocol及controller日志。
收齐全部175分母、失败译文、晚失败、队列峰值及同完成任务配对的首PCM等待。
统计实际captured WAV输出秒数，运行rvc-golden/verify_tempo_playback.py对完成任务独立FFmpeg逐样本核验；失败必须保留。
原始PCM保留板端；用read_audio校验头部声明与实际字节，收集hash与试听。
更新reports/backlog-fix-20261019/RESULTS.md，把7窗与175分段分开，明确不是原始ASR/RVC联合测试。
报告后请reviewer复查最终数据，运行lint和必要测试后再交付。不要提交/推送/合并。
旧mozart心跳仍暂停，新负载没有自动监控，当前turn继续等待和执行收尾。

## 数字检查新修正与第3轮175段

前2轮均已退出0：before-trace-v2-paced有175job/174完成/1失败，峰47.550610s；after-trace-v2-paced有165job/164完成/1失败，峰26.301617s。
失败均为同一拼音候选导致TTS无EOS，前述词表没有解决该输入的真实失败；保留原错误。

进一步发现旧数字检查误拒10候选中6个等值英文数字表达（seven thousand、one or two thousand、between...、one hundred）。
生产新修改 english_quantity_digits/_english_integer/_range_values 仅在检查计数里展开英文整数/范围，保留原字幕字符串。
商品数量守卫也复用该展开，避免拼写金额绕过原验收；原漏数/重复/新增数量均保留。
reviewer发现并修复共享范围数量级误算、并列整额漏计、退化范围端点被压同值的问题。
最新27数字+30桥接=57项通过，reviewer独立复核通过，未报告剩余问题。
新增测试包含one or two hundred thousand正确与错误source正反例、between one and two thousand five hundred、完整并列金额、between one and one thousand端点正反例。
没有推断/放行两万七、一千五等原有中文模糊金额；这些错误保留原文与理由。

第3轮tmux：mozart_backlog_numeric_20261019，控制器launch_numeric.sh。
候选目录candidate-numeric，独立于前2轮candidate；trace_probe_numeric.py --only-after --after-name after-numeric-trace --repo candidate-numeric。
先跑最终完整Python回归，再按原175段相同时间轴单次运行after-numeric-trace-paced。
输入仍为trace-cases.json，flexible<=1.15，capture_playback=true，history175，排空600s。
读取numeric-controller-exit-code、python-regression-numeric-reviewed.log、console-numeric-trace.log、after-numeric-trace-paced/*。
2026-10-19本机启动，预计约10分钟（2026-10-19T用户本地无需根据板端时区推断）。不要重复启动或中断正常进展。

analyze_trace.py已扩展3轮，但paired比较只用baseline与最后numeric轮，避免中间165job缩小最终配对集合。
分析器已补speech ID/序号/源段范围映射验证，5个构造缺失/错ID/范围/前缀/重复映射均拒绝；时间容差保持1e-6。
收尾脚本package_trace.py生成3轮实际变速完成音频合并试听，失败拼音捕获单独提供，原始PCM留板端。
注意：package脚本仍需审查并将source-pinyin-context.mp3加入归档（该源22.5s WAV已编码为MP3）。
175轮post分析尚未启动，等待第3轮结束后再运行analyze_trace.py，避免FFmpeg分析竞争正常负载。
把分析退出码写trace-analysis-exit-code；失败留证据，不改验收。随后package_trace.py。

同录音static-full第6窗(121.2..143.7s)识别为“麻醉剂麻醉剂分期是网贷最大的麻醉剂”，直播源却为“马就你记马最几分七四往代最大的麻醉剂”。
源试听source-pinyin-context.mp3位于板端root。该差异是后续ASR调查入口；本轮没有为拼音输入引入任意丢弃或启发式掩盖失败。

已启用原mozart心跳跟踪本轮收尾，正常推进静默，最终报告后暂停。
finish_trace.sh已在tmux mozart_backlog_finish_20261019等待；numeric完成后自动运行严格PCM分析和打包。
当前数字版完整回归231/231通过，日志python-regression-numeric-reviewed.log。
reviewer已在最新共享尺度不合并退化端点修正后独立57项测试通过，没有新增问题。

## 本轮最终完成

数字版175/175退出0：167入队、166完成、8翻译失败、1拼音候选TTS失败。
峰值23.200549s（baseline47.550610s）；166共同完成任务首PCM median17.104244→8.751810s，P9531.905983→14.094314s。
原正确英文数值误拒恢复ID {30,102,122,128,130,172}；新增正确拦截拼写数值ID {43,45,72,127}。
所有业务失败与175分母保留，strict_acceptance_passed=false。
三轮变速171/161/162捕获均独立FFmpeg逐采样通过，analysis/package退出0。
trace-small-records.tar.gz已完整同步，618文件哈希全部核对；10005 WAV哈希留trace-analysis/raw-wave-hashes.json。
最终报告RESULTS.md，7窗历史另存SEVEN-WINDOWS.md。
reviewer最终审查无新增问题，独立67项针对回归及lint通过；本机最终重跑67项、lint/diff检查通过。
最终源7模块与numeric协议SHA一致；旧final-source-hashes移为seven-window-source-hashes，最终模块及测试另存final-source-hashes.json。
所有自有负载结束。mozart心跳已暂停。不提交推送合并。
剩余业务错误：8段数值/识别失败与1段拼音ASR→TTS晚失败，详见报告。后续按用户最新指令处理，不用重复运行原样负载。

## 父段复核与上下文短对照

用户随后要求先检查下阶段问题，并继续调查分段时长和译文重复。
新增报告为 reports/backlog-fix-20261019/PARENT-DURATION-AUDIT.md。
本轮保持生产代码和原长测证据原样，增加归档分析及三个不同输入的短对照。

175 个源分段对应 115 个父段；114 个已 final。
完整且全部播报成功的 106 个父段含 156 个子段：中文 478.180 s，英文原速 563.200 s，实际播放 493.730333 s。
父段 115 仅有 partial，已提交 5.760 s，最后观测 7.680 s，从完整时长集合排除。
父段 74 后半句仅分配 0.640 s；原分段按观测终点递增分配，汇总父段后比例明显回落。
166 个完成任务的等待中位数依次为：源事件至任务创建 0.4066 s，合成排队 2.4120 s，首块生成 0.2821 s，首块就绪至播放 5.6204 s。

父段 22 的第 27、28 段重复了 my high school classmate asked。
相邻候选 60 对，连续 5 词重叠筛选命中该 1 对，文本复核确认重复。
当前重复前文检查只比较整条候选是否相同，局部重复会通过。
audit_parent_duration.py 和 parent-duration-audit.json 保存完整分母与输入哈希。
计时核对已按 reviewer 意见改为有限、有序、与归档总等待差异超过 1e-6 s 则失败。
4 项故障注入均被拒绝，见 parent-duration-fault-checks.json。

板端 /home/moyamryia/mozart-backlog-fix-20261019/context-ablation-20261019/launch.sh 串行执行三个短对照，每种只执行一次。
结果目录分别为 context-20261019-split-history-paced、context-20261019-split-isolated-paced、context-20261019-joined-paced。
三组共 5 任务，全部完成，无程序运行失败；严格状态保持 false。
原父段源音频 7.360 s，带前文英文原速 13.040 s，独立翻译 10.240 s，合并父段 10.240 s。
带前文复现原重复；独立翻译第二句不再重复前段，原速少 2.800 s。
合并候选漏“刚成年”，并把异常源词“三叉零”译为 zero-interest，保留该缺陷。
三个实际播放总长为 11.8105、9.3770、8.917292 s，各任务自行选速，文本变化比较使用原速。
5 个捕获均通过原 FFmpeg 逐采样核验，完整 PCM 与音频块逐字节一致。
全部原始短 WAV 已拉回本机，226 个文件哈希匹配，3 个清理记录均无遗留自有进程。
原中文 WAV 哈希与原字幕一致；context-ablation-20261019 下有原文与三种英文 MP3 试听。
本轮没有更改全局上下文策略；下一步扩展不同父段的对照，再确定上下文和断句方案。

用户最新另设单次定时任务：新加坡时间 2026-10-20 04:00，在本对话发送“继续”。
新任务 id 为 mozart-2，ACTIVE，COUNT=1，prompt 精确为“继续”；不要暂停或删除该新任务。
旧 mozart 心跳继续保持 PAUSED。
最终 audit_reviewer 六项复核无新增问题，独立核对 226 个文件哈希及全部新分母。
终审后本机再次复算，结果哈希保持一致；写作 lint、语法和 diff 空白检查通过。
不提交、推送或合并 PR。
