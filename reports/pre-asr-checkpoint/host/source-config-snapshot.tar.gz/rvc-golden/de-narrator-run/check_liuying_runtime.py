"""Compare Mozart's TensorRT stages with the captured liuying Golden call."""
from pathlib import Path
import json
import sys
import numpy as np
import onnxruntime as ort
import torch
ROOT=Path('/home/moyamryia/Mozart')
sys.path.insert(0,str(ROOT/'tools'))
from export_generator_onnx import load_generator
from export_generator_split_onnx import RealtimeGeneratorFront, GeneratorDecoder
run=ROOT/'rvc-golden/de-narrator-run'
out=run/'liuying-split-check'
assets=ROOT/'rvc-backend/models/liuying'
torch.set_num_threads(2)
wrapper,_=load_generator(assets/'liuying.pth',Path('/home/moyamryia/mozart-archive/RVC'))
report=[]
def feeds(path,prefix):
    options=ort.SessionOptions();options.intra_op_num_threads=2
    session=ort.InferenceSession(str(path), options, providers=['CPUExecutionProvider'])
    return {i.name:np.fromfile(out/f'{prefix}-{i.name}.bin',dtype=np.float32).reshape(i.shape).astype(np.int64 if i.type=='tensor(int64)' else np.float32) for i in session.get_inputs()}
def pt(module,values):
    with torch.inference_mode():return module(*(torch.from_numpy(a) for a in values.values())).numpy()
def stage(name,path,output,values,expected):
    inputs=[]
    for key,a in values.items():
        dst=f'{name}-{key}-typed.bin';np.ascontiguousarray(a).tofile(out/dst)
        inputs.append(dict(name=key,path=dst,shape=list(a.shape),dtype=str(a.dtype)))
    dst=f'{name}-expected.bin';np.ascontiguousarray(expected).tofile(out/dst)
    report.append(dict(name=name,model=str(path),backend='tensorrt',output=output,cases=[dict(name='captured-liuying-golden',inputs=inputs,expected=dst,elements=expected.size)]))
f=feeds(assets/'liuying-front.onnx','front')
z=pt(RealtimeGeneratorFront(wrapper.generator,250,30),f)
d=feeds(assets/'liuying-decoder.onnx','decoder');d['z']=z
y=pt(GeneratorDecoder(wrapper.generator),d)
stage('liuying-front',assets/'liuying-front.onnx','z',f,z)
stage('liuying-decoder',assets/'liuying-decoder.onnx','audio',d,y)
(out/'runtime-manifest.json').write_text(json.dumps(report,indent=2)+'\n')
