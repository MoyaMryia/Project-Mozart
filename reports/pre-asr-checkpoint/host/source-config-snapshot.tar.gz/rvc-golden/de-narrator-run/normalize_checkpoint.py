"""Convert a clean checkpoint to the upstream weight-norm storage format."""
from pathlib import Path
import sys
import json
import torch

ROOT = Path('/home/moyamryia/Mozart')
sys.path[:0] = [str(ROOT), '/home/moyamryia/mozart-archive/RVC']
from infer.module.models import SynthesizerTrnMs768NSFsid
from tools.export_generator_onnx import load_inference_weights, load_generator

torch.set_num_threads(2)
p = torch.load('/home/moyamryia/models/de_narrator_clean.pth', map_location='cpu', weights_only=False)
config = list(p['config'])
config[-3] = p['weight']['emb_g.weight'].shape[0]
g = SynthesizerTrnMs768NSFsid(*config, is_half=False)
names = [name for name, module in g.named_modules() if hasattr(module, 'weight_g')]
load_inference_weights(g, p['weight'])
for name, module in g.named_modules():
    if name in names:
        torch.nn.utils.weight_norm(module)
        # A zero channel needs a nonzero direction with zero magnitude.
        with torch.no_grad():
            rows = module.weight_v.reshape(module.weight_v.shape[0], -1)
            zero = torch.linalg.vector_norm(rows, dim=1) == 0
            rows[zero, 0] = 1
p['weight'] = {name: value for name, value in g.state_dict().items() if not name.startswith('enc_q.')}
p['config'] = config
out = ROOT/'rvc-golden/de-narrator-run/de_narrator-weightnorm.pth'
torch.save(p, out)
a, _ = load_generator('/home/moyamryia/models/de_narrator_clean.pth', Path('/home/moyamryia/mozart-archive/RVC'))
b, _ = load_generator(out, Path('/home/moyamryia/mozart-archive/RVC'))
assert all(torch.isfinite(v).all() for v in b.generator.state_dict().values())
errors = {k: float((v-b.generator.state_dict()[k]).abs().max()) for k,v in a.generator.state_dict().items()}
report = {'max_abs': max(errors.values()), 'weights': len(errors), 'output': str(out)}
assert report['max_abs'] < 1e-6, report
out.with_suffix('.json').write_text(json.dumps(report, indent=2)+'\n')
print(report)
