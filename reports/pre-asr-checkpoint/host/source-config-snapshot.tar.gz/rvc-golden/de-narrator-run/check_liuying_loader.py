"""Compare the unchanged liuying model before and after the loader fix."""
from pathlib import Path
import json
import subprocess
import sys
import types
import torch
import numpy as np

ROOT = Path('/home/moyamryia/Mozart')
sys.path.insert(0, str(ROOT/'tools'))
from export_generator_onnx import load_generator

torch.set_num_threads(2)
baseline = types.ModuleType('baseline_exporter')
code = subprocess.check_output(['git', 'show', 'HEAD:tools/export_generator_onnx.py'], cwd=ROOT, text=True)
exec(compile(code, 'HEAD:tools/export_generator_onnx.py', 'exec'), baseline.__dict__)
model = ROOT/'rvc-golden/liuying-run/流萤/流萤.pth'
source = Path('/home/moyamryia/mozart-archive/RVC')
a, rate_a = baseline.load_generator(model, source)
b, rate_b = load_generator(model, source)
wa, wb = a.state_dict(), b.state_dict()
assert rate_a == rate_b and wa.keys() == wb.keys()
assert all(torch.equal(wa[k], wb[k]) for k in wa)
run = ROOT/'rvc-golden/de-narrator-run'
def captured(name):
    return np.load(run/'tensors'/f'generator_00_{name}.npy')
inputs = (captured('feats')[:,:200].astype(np.float32), np.array([200],np.float32),
    captured('pitch')[:,:200].astype(np.float32),captured('pitchf')[:,:200],captured('sid'),
    captured('latent_noise')[:,:,:200],captured('source_phase'),captured('source_noise')[:,:96000])
with torch.inference_mode():
    ya=a(*(torch.from_numpy(x) for x in inputs)).numpy()
    yb=b(*(torch.from_numpy(x) for x in inputs)).numpy()
assert np.isfinite(yb).all()
assert np.array_equal(ya,yb)
report=dict(weights=len(wa), all_weights_equal=True, samples=int(yb.size), all_samples_equal=True,
    max_abs=float(np.max(np.abs(ya-yb))), comparison='HEAD exporter versus updated exporter; identical captured inputs and synthesis noise')
(run/'liuying-loader-regression.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
