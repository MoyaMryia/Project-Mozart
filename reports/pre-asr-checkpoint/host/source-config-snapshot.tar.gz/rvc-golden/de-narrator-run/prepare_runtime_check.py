"""Prepare captured Golden inputs for Mozart's C++ runtime verifier."""
from pathlib import Path
import sys
import json
import numpy as np
import onnxruntime as ort
import torch

ROOT = Path('/home/moyamryia/Mozart')
sys.path[:0] = [str(ROOT/'tools'), str(ROOT/'rvc-golden')]
from export_generator_onnx import load_generator
from export_generator_split_onnx import RealtimeGeneratorFront, GeneratorDecoder
from verify_realtime_split import metrics

torch.set_num_threads(2)
run = ROOT/'rvc-golden/de-narrator-run'
out = run/'split-check'
g, sr = load_generator('/home/moyamryia/models/de_narrator_clean.pth', Path('/home/moyamryia/mozart-archive/RVC'))
g = g.generator
stages = []
def values(path, prefix):
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    session = ort.InferenceSession(str(path), options, providers=['CPUExecutionProvider'])
    result = {}
    for inp in session.get_inputs():
        raw = np.fromfile(out/f'{prefix}-{inp.name}.bin', dtype=np.float32).reshape(inp.shape)
        result[inp.name] = raw.astype(np.int64 if inp.type=='tensor(int64)' else np.float32)
    return result

def save_stage(name, path, output, feeds, expected):
    inputs = []
    for key, a in feeds.items():
        dst = f'{name}-{key}-typed.bin'
        np.ascontiguousarray(a).tofile(out/dst)
        inputs.append(dict(name=key, path=dst, shape=list(a.shape), dtype=str(a.dtype)))
    dst = f'{name}-expected.bin'
    np.ascontiguousarray(expected).tofile(out/dst)
    stages.append(dict(name=name, model=str(path), backend='tensorrt', output=output,
        cases=[dict(name='captured-golden', inputs=inputs, expected=dst, elements=expected.size)]))

def pt(module, feeds):
    with torch.inference_mode():
        return module(*(torch.from_numpy(a) for a in feeds.values())).numpy()
front_path = run/'de_narrator-front.onnx'
decoder_path = run/'de_narrator-decoder.onnx'
f = values(front_path, 'front')
z = pt(RealtimeGeneratorFront(g, 250, 30), f)
d = values(decoder_path, 'decoder')
d['z'] = z
y = pt(GeneratorDecoder(g), d)
save_stage('front', front_path, 'z', f, z)
save_stage('decoder', decoder_path, 'audio', d, y)
for name, inp, output in [('hubert','audio','features'), ('rmvpe','mel','f0')]:
    save_stage(name, ROOT/f'rvc-golden/qiqi-zh-run/{name}-realtime.onnx', output,
        {inp: np.load(out/f'{name}-input.npy')}, np.load(out/f'{name}-python.npy'))
(out/'runtime-manifest.json').write_text(json.dumps(stages, indent=2)+'\n')
print(out/'runtime-manifest.json')
# Also compare the fixed T=200 Generator with the same captured tensors.
full, _ = load_generator('/home/moyamryia/models/de_narrator_clean.pth', Path('/home/moyamryia/mozart-archive/RVC'))
capture = run/'tensors'
def captured(name):
    return np.load(capture/f'generator_00_{name}.npy')
feeds = dict(feats=captured('feats')[:, :200].astype(np.float32),
    p_len=np.array([200], np.float32), pitch=captured('pitch')[:, :200].astype(np.float32),
    pitchf=captured('pitchf')[:, :200].astype(np.float32), sid=captured('sid').astype(np.int64),
    latent_noise=captured('latent_noise')[:, :, :200], source_phase=captured('source_phase'),
    source_noise=captured('source_noise')[:, :200*480])
expected = pt(full, feeds)
options = ort.SessionOptions(); options.intra_op_num_threads = 2
session = ort.InferenceSession(str(run/'de_narrator.onnx'), options, providers=['CPUExecutionProvider'])
actual = session.run(['audio'], feeds)[0]
report = metrics(expected, actual)
(run/'fixed-generator-check.json').write_text(json.dumps(report, indent=2)+'\n')
print(report)
