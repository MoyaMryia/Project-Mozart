"""Collect the two-model regression evidence without changing acceptance rules."""
from pathlib import Path
import hashlib
import json
import numpy as np
import soundfile as sf
run=Path('/home/moyamryia/Mozart/rvc-golden/de-narrator-run')
def read(name): return json.loads((run/name).read_text())
def comparison(name):
    text=(run/name).read_text()
    return json.loads(text[text.index('{'):])
def stage_report(name):
    result=read(name)
    for item in result:
        assert item['relative_rmse'] <= .001 and item['cosine'] >= .99999
        assert item['runtime']['backend']=='tensorrt'
    return result
models={}
for key,prefix,split,runtime in [
    ('de_narrator','', 'split-check/split-verification.json','runtime-check.json'),
    ('liuying','liuying-', 'liuying-split-check/split-verification.json','liuying-runtime-check.json')]:
    stream=read(prefix+'stream-check.json')
    assert stream['received_frames']==stream['input_frames']+stream['flush_frames']
    assert not stream['missing_frames']
    stats=stream['stream']
    for name in ['inference_errors','late_blocks','input_overruns','output_overruns','packets_dropped','rejected_clients','resets']:
        assert stats[name]==0, (key,name,stats[name])
    assert stats['output_underruns']==stats['startup_output_underruns']
    component=read(split)
    for name in ['front','decoder','pipeline']:
        assert component[name]['relative_rmse']<=.001 and component[name]['cosine']>=.99999
    models[key]=dict(onnx=component,tensorrt=stage_report(runtime),stream=stream,
        realtime_quality=comparison(prefix+'realtime-comparison.txt'),
        runtime=read(prefix+'backend-status.json')['model'])
wave_stats={}
for path in sorted(run.glob('*espeak*.wav')):
    audio,sr=sf.read(path)
    assert np.isfinite(audio).all(), path
    wave_stats[path.name]=dict(sample_rate=sr,samples=len(audio),rms=float(np.sqrt(np.mean(audio**2))),peak=float(np.max(np.abs(audio))),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
legacy=read('legacy-weight-audit.json')
legacy.pop('differences')
report=dict(checkpoint_metadata=dict(version='v2',f0=True,sample_rate=48000,speakers=109,feature_dimension=768,speaker_id=0),
    base_revision='a793e30c46d008135dc7efdc080a5986ba04ae71',
    configuration=dict(platform='Jetson Orin Nano Super 8GB',input_rate=16000,output_rate=48000,block_samples=3840,past_samples=40000,analysis_samples=44800,crossfade_samples=2400,sola_search_samples=480,pitch_shift=0,index_rate=0,rms_mix_rate=1,protect=.33,denoise=False,seed=114514),
    legacy_weights=legacy,full_captured_generator=read('full-capture-check.json'),
    models=models,liuying_loader_regression=read('liuying-loader-regression.json'),
    liuying_file_regression=read('liuying-file-regression.json'),
    de_narrator_file_quality=comparison('file-dynamic-comparison.txt'),
    wave_stats=wave_stats)
assert report['liuying_loader_regression']['all_weights_equal']
assert report['liuying_loader_regression']['all_samples_equal']
assert report['liuying_file_regression']['same_samples']
(run/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
print('Two-model component, transport, and liuying non-regression checks passed.')
