"""Run the dynamic ONNX Generator on the complete captured Golden call."""
from pathlib import Path
import sys
import json
import numpy as np
import onnxruntime as ort
import soundfile as sf
ROOT=Path('/home/moyamryia/Mozart')
sys.path.insert(0, str(ROOT/'rvc-golden'))
from verify_realtime_split import metrics
run=ROOT/'rvc-golden/de-narrator-run'
tensors=run/'tensors'
options=ort.SessionOptions(); options.intra_op_num_threads=2
session=ort.InferenceSession(str(run/'de_narrator-dynamic.onnx'), options, providers=['CPUExecutionProvider'])
feeds={}
for inp in session.get_inputs():
    feeds[inp.name]=np.load(tensors/f'generator_00_{inp.name}.npy').astype(np.int64 if inp.type=='tensor(int64)' else np.float32)
actual=session.run(['audio'], feeds)[0]
expected=np.load(tensors/'generator_00_audio.npy')
report=metrics(expected,actual)
report['frames']=int(feeds['feats'].shape[1])
report['input_origin']='Entire captured Golden Generator call, including all three synthesis noise tensors'
(run/'full-capture-check.json').write_text(json.dumps(report,indent=2)+'\n')
sf.write(run/'de-narrator-espeak-onnx-generator.wav', actual.ravel()[48000:-48000], 48000, subtype='FLOAT')
print(json.dumps(report,indent=2))
