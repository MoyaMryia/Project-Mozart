#!/bin/bash
set -u
cd /home/moyamryia/mozart-demo-20261020
run() {
  cmake -S rvc-backend -B build-host -G Ninja -DCMAKE_BUILD_TYPE=Debug -DUSE_ONNX=OFF -DUSE_TENSORRT=OFF -DMOZART_USE_RNNOISE=OFF -DBUILD_TESTS=ON -DMOZART_BUILD_TESTS=ON &&
  cmake --build build-host -j2 &&
  ctest --test-dir build-host --output-on-failure &&
  ctest --test-dir build-host -R '^state_' --repeat until-fail:10 --output-on-failure
}
run > native-check-v2.log 2>&1
code=$?
printf '%s\n' "$code" > native-exit-code-v2
exit "$code"
