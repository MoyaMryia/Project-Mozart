#!/bin/bash
set -u
cd /home/moyamryia/mozart-demo-20261020
/home/moyamryia/Mozart/.venv/bin/python -m unittest discover -s tools/tests -p test_tempo_player.py -v > tempo-native-tests.log 2>&1
first=$?
/home/moyamryia/Mozart/.venv/bin/python -m unittest discover -s tools/tests -p test_early_audio.py -v > early-audio-native-tests.log 2>&1
second=$?
printf '%s %s\n' "$first" "$second" > tempo-check-exit-codes
if [ "$first" -ne 0 ] || [ "$second" -ne 0 ]; then exit 1; fi
