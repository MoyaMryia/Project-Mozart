#!/bin/bash
set -u
cd /home/moyamryia/mozart-demo-20261020
run() {
  cmake -S . -B build-gpu -G Ninja -DCMAKE_BUILD_TYPE=Release -DUSE_ONNX=ON -DUSE_TENSORRT=ON -DUSE_CUDA_EP=OFF -DBUILD_TESTS=OFF -DONNX_RUNTIME_PATH=/home/moyamryia/Mozart/third_party/onnxruntime-gpu-1.29.0/lib -DONNX_RUNTIME_INCLUDE_DIR=/home/moyamryia/Mozart/third_party/onnxruntime-gpu-1.29.0/include -DMOZART_RNNOISE_DEFAULT_MODEL=/home/moyamryia/Mozart/preprocessor/assets/rnnoise_default.rnnb &&
  cmake --build build-gpu -j2
}
run > gpu-build.log 2>&1
code=$?
printf '%s\n' "$code" > gpu-build-exit-code
exit "$code"
