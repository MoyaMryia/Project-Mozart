#!/bin/bash
set -u
cd /home/moyamryia/mozart-demo-20261020
/home/moyamryia/Mozart/.venv/bin/python -u /home/moyamryia/mozart-full-soak-20261019/run_rvc_only.py --repo /home/moyamryia/mozart-demo-20261020 --previous /home/moyamryia/mozart-full-soak-20261019/full --output /home/moyamryia/mozart-demo-20261020/rvc-smoke --frames 1000 > rvc-smoke-controller.log 2>&1
code=$?
printf '%s\n' "$code" > rvc-smoke-controller-exit-code
exit "$code"
