import hashlib,json,re,struct,tarfile
from pathlib import Path
import numpy as np
root=Path('/home/moyamryia/mozart-demo-20261020')
phase=root/'rvc-smoke'
status=json.loads((phase/'status.json').read_text())
rows=[json.loads(line) for line in (phase/'telemetry.jsonl').read_text().splitlines()]
values=[float(v) for v in re.findall(r'\[profile\]\[realtime\].*?total=([0-9.]+)ms',(phase/'rvc.log').read_text())]
def digest(path):
    with path.open('rb') as handle: return hashlib.file_digest(handle,'sha256').hexdigest()
def float_wave(path):
    blob=path.read_bytes()
    assert blob[:4]==b'RIFF' and blob[8:12]==b'WAVE'
    offset=12
    fmt=data=None
    while offset+8<=len(blob):
        kind,size=struct.unpack_from('<4sI',blob,offset)
        start=offset+8
        assert start+size<=len(blob)
        if kind==b'fmt ': fmt=struct.unpack_from('<HHIIHH',blob,start)
        if kind==b'data': data=blob[start:start+size]
        offset=start+size+(size%2)
    assert fmt is not None and data is not None
    tag,channels,rate,byte_rate,alignment,bits=fmt
    assert tag==3 and bits==32 and alignment==channels*4 and byte_rate==rate*alignment
    assert len(data)%alignment==0
    return np.frombuffer(data,dtype='<f4'),rate,channels,len(data)//alignment
metrics={'profile_blocks':len(values),'status_blocks':status['stream']['blocks'],
         'block_total_ms':{'median':float(np.median(values)),'p95':float(np.percentile(values,95)),'max':max(values)},
         'available_GiB_min':min(r['available_bytes'] for r in rows)/1024**3,
         'swap_used_bytes_first':rows[0]['swap_used_bytes'],'swap_used_bytes_last':rows[-1]['swap_used_bytes'],
         'pswpin_delta':rows[-1]['pswpin']-rows[0]['pswpin'],'pswpout_delta':rows[-1]['pswpout']-rows[0]['pswpout'],
         'audio':[]}
assert len(values)==status['stream']['blocks']
for filename in ['processed-input.wav','qiqi-mozart-backend.wav']:
    path=phase/filename
    data,rate,channels,frames=float_wave(path)
    metrics['audio'].append({'path':filename,'rate':rate,'channels':channels,'frames':frames,'seconds':frames/rate,
      'peak':float(np.max(np.abs(data))),'rms':float(np.sqrt(np.mean(data.astype(np.float64)**2))),
      'nonfinite_samples':int(np.count_nonzero(~np.isfinite(data))),
      'above_full_scale_samples':int(np.count_nonzero(np.abs(data)>1)),'sha256':digest(path)})
(phase/'metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
manifest=[]
paths=[root/'build-gpu/state/mozart_stated',root/'build-gpu/preprocessor/mozart-pre',root/'build-gpu/preprocessor/libmozart-tempo.so']
paths += [Path(value) for key,value in status['model'].items() if key.endswith('_asset') and value]
for path in sorted(set(paths)):
    manifest.append({'path':str(path),'bytes':path.stat().st_size,'sha256':digest(path)})
(root/'actual-runtime-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
selected=[p for p in root.iterdir() if p.is_file() and p.suffix in ['.json','.log','.sh','.py']]
for directory in ['rvc-smoke','usb-smoke','usb-smoke-gpu']:
    selected += [p for p in (root/directory).rglob('*') if p.is_file() and 'temp' not in p.relative_to(root).parts]
selected.append(root/'rvc-golden/tempo-frame-boundary-pocket.wav')
records=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(set(selected))]
(root/'evidence-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
with tarfile.open('/tmp/mozart-stability-evidence-20261020.tar.gz','w:gz') as archive:
    for p in sorted(set(selected)): archive.add(p,arcname=str(p.relative_to(root)))
    archive.add(root/'evidence-manifest.json',arcname='evidence-manifest.json')
print(json.dumps(metrics,indent=2))
