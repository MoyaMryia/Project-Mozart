#!/bin/bash
set -u
cd /home/moyamryia/mozart-demo-20261020
run() {
  cmake --build build-host --clean-first -j2 &&
  ctest --test-dir build-host --output-on-failure &&
  ctest --test-dir build-host -R '^state_' --repeat until-fail:10 --output-on-failure
}
run > native-check-v3.log 2>&1
code=$?
printf '%s\n' "$code" > native-exit-code-v3
exit "$code"
