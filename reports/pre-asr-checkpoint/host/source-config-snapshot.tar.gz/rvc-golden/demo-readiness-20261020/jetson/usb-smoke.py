import array
import json
from pathlib import Path
import socket
import subprocess
import threading
import time
import wave
root=Path('/home/moyamryia/mozart-demo-20261020')
out=root/'usb-smoke'
out.mkdir(exist_ok=True)
wav=out/'silence-500ms.wav'
with wave.open(str(wav),'wb') as audio:
    audio.setparams((2,2,48000,0,'NONE','not compressed'))
    audio.writeframes(bytes(24000*4))
results=[]
for name,device,expected in [('invalid-output','mozart_nonexistent_output',False),('usb-first','plughw:CARD=Device,DEV=0',True),('usb-restart','plughw:CARD=Device,DEV=0',True)]:
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as server:
        server.bind(('127.0.0.1',0))
        server.settimeout(.1)
        stopping=threading.Event()
        frames=[]
        errors=[]
        def reply():
            while not stopping.is_set():
                try: packet,client=server.recvfrom(8192)
                except socket.timeout: continue
                if len(packet)!=1300:
                    errors.append('invalid input packet length')
                    continue
                frames.append(int.from_bytes(packet[12:16],'little'))
                server.sendto(packet[:20]+bytes(960*4),client)
        worker=threading.Thread(target=reply)
        worker.start()
        command=[str(root/'build-host/mozart_pre/mozart-pre'),'-i',str(wav),'--pace','--no-rnnoise','-n','25','-a','127.0.0.1','-p',str(server.getsockname()[1]),'-o',device]
        start=time.monotonic()
        try:
            result=subprocess.run(command,capture_output=True,text=True,timeout=8)
        finally:
            stopping.set()
            worker.join(timeout=1)
        (out/(name+'.log')).write_text(result.stdout+result.stderr)
        passed=(result.returncode==0 and frames==list(range(25)) and 'played=25' in result.stderr) if expected else result.returncode!=0 and not frames
        results.append({'name':name,'device':device,'returncode':result.returncode,'input_frames':frames,'elapsed_seconds':time.monotonic()-start,'errors':errors,'passed':passed,'command':command})
(out/'results.json').write_text(json.dumps({'configuration':'48 kHz stereo silence input; 16 kHz 320-sample UDP input; 48 kHz 960-sample silent reply','physical_scope':'USB ALSA open and write; silence does not assess audible quality','cases':results},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(results,ensure_ascii=False,indent=2))
raise SystemExit(not all(row['passed'] for row in results))
