# D10 配置入口修复

日期：2026-10-20，新加坡时间。

当前配置缺失字段继续使用默认值。已配置的错误类型、空值、非法中间结构和非有限数字明确失败。
守护进程在创建模型、存储目录、工作线程和 HTTP 监听之前完成读取与校验。

## 修改文件

- `rvc-backend/include/utils/config.hpp`
- `rvc-backend/src/utils/config.cpp`
- `state/src/daemon.cpp`
- `state/tests/test_config.py`
- `rvc-backend/CMakeLists.txt`
- `rvc-backend/include/rvc/pipeline.hpp`
- `rvc-backend/src/rvc/pipeline.cpp`
- `rvc-backend/src/state/mode_controller.cpp`，仅参数设置与预设的共享校验调用由本代理修改；状态统计由主代理修改。

## 行为

Config 区分 Undefined 与 Null，读取路径遇到非映射父节点时返回键名和值。
整数、浮点、布尔与字符串字段不再将转换失败变成默认值。
显式字符串数字也不作为整数配置接收；可选资产路径保留空字符串禁用语义。
采样率和帧长使用现有 IO 契约常量。
端口、队列、缓存和启动等待在无符号转换前检查范围。
RVC 参数范围由 invalid_rvc_parameter 唯一定义，配置、JSON 参数及预设入口分别调用。
内部 RealRVCPipeline 构造和更新信任入口结果，删除旧 harvest/pm 静默改写。
三个比例字段保留 double 至推理边界，避免先转 float 将非法相邻值舍入为合法值。
默认仍保留原 float 字面值，RVCInferencer 接口仍使用 float。

## 验证

独立构建：`/tmp/mozart-config-build-20261020`。
配置：独立 rvc-backend 构建，USE_ONNX=OFF、USE_TENSORRT=OFF、MOZART_USE_RNNOISE=OFF。
依赖源复用仓库 build/host/_deps，构建产物和其他代理隔离。

生产入口目标 config_daemon_fixture 直接编译 state/src/main.cpp 与 state/src/daemon.cpp。
配置回归包含 7 个方法、106 个实际子例：101 个非法配置、5 个成功启动。
非法配置包括 55 个字段值、4 个中间结构、1 个关闭 RVC 的坏 mock 字段、18 个空值和容器、9 个非有限浮点与5个非法根节点。
显式标签回归包含 8 个标签与字段类型错配，以及 1 个整数标签包含小数的非法值。
成功配置包括缺失字段默认、范围端点、相邻合法浮点值和合法显式标签。
每个子例使用独立临时目录。失败子例核对非零退出、键名和值、无模型/存储/预设创建、无监听日志和端口可重新绑定。
成功子例通过实际 HTTP 状态确认就绪，再发送 SIGTERM 确认正常退出，且 RVC 关闭时不创建模型目录。

- `/tmp/mozart-config-build-20261020/config-test3.log`：显式标签修复前的配置回归 1/1 通过。
- `/tmp/mozart-config-build-20261020/config-tags-test.log`：显式标签修复后的生产入口配置回归 1/1 通过。
- `/tmp/mozart-config-build-20261020/all-tests.log`：显式标签修复前的独立 backend CTest 24/24 通过。
- `/tmp/mozart-config-build-20261020/all-tests-tags.log`：显式标签修复后的独立 backend CTest 24/24 通过，耗时 8.32 s。
- `/tmp/mozart-config-build-20261020/all-build.log`：全部独立 backend 回归目标编译完成。
- git diff --check 通过。
- 显式标签修复后 writing_lint 与 diff 空白检查通过。

初次新增目标未重新生成构建树，以及接口修改期间的旧对象链接失败记录保留在 build.log、rebuild.log、config-test.log。
后续固定源码后重编译，使用新二进制运行上述成功记录；原始失败记录保持原样。

## 适用范围

- 配置和样本见本报告验证部分；本轮未启动真实推理模型或远端负载。
- 本轮直接执行的是独立 backend 24 项，IO 与预处理独立套件由主代理整合回归覆盖。
- Jetson 实际资产启动未执行。阻塞：当前阶段先冻结故障修复候选。解除条件：主代理完成统一审查后，在新隔离目录执行设备冒烟和实际音频验证。
